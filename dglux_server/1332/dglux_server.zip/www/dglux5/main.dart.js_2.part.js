self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,D,{"^":"",
aTH:function(){var z=document
z=z.createElement("div")
z=new D.J2(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.rn()
z.alT()
return z},
arl:{"^":"NH;",
stO:["aJ2",function(a){if(!J.a(this.k4,a)){this.k4=a
this.dn()}}],
sLE:function(a){if(!J.a(this.r1,a)){this.r1=a
this.dn()}},
sLF:function(a){if(!J.a(this.rx,a)){this.rx=a
this.dn()}},
sLG:function(a){if(!J.a(this.ry,a)){this.ry=a
this.dn()}},
sLI:function(a){if(!J.a(this.x1,a)){this.x1=a
this.dn()}},
sLH:function(a){if(!J.a(this.x2,a)){this.x2=a
this.dn()}},
sb8B:function(a){if(!J.a(this.y1,a)){if(J.x(a,180))a=180
this.y1=J.Q(a,-180)?-180:a
this.dn()}},
sb8A:function(a){if(J.a(this.y2,a))return
this.y2=a
this.dn()},
gjw:function(a){return this.A},
sjw:function(a,b){if(b==null)b=0
if(!J.a(this.A,b)){this.A=b
this.dn()}},
gki:function(a){return this.T},
ski:function(a,b){if(b==null)b=100
if(!J.a(this.T,b)){this.T=b
this.dn()}},
sbgx:function(a){if(this.J!==a){this.J=a
this.dn()}},
gxC:function(a){return this.a2},
sxC:function(a,b){if(b==null||J.Q(b,0))b=0
if(J.x(b,4))b=4
if(!J.a(this.a2,b)){this.a2=b
this.dn()}},
saHc:function(a){if(this.P!==a){this.P=a
this.dn()}},
syZ:function(a){this.a8=a
this.dn()},
gta:function(){return this.U},
sta:function(a){if(!J.a(this.U,a)){this.U=a
this.dn()}},
sb8m:function(a){if(!J.a(this.X,a)){this.X=a
this.dn()}},
gwa:function(a){return this.K},
swa:["akn",function(a,b){if(!J.a(this.K,b))this.K=b}],
sM5:["ako",function(a){if(!J.a(this.a9,a))this.a9=a}],
sacM:function(a){this.akq(a)
this.dn()},
jM:function(a,b){this.Jz(a,b)
this.Tp()
if(J.a(this.U,"circular"))this.bgM(a,b)
else this.bgN(a,b)},
Tp:function(){var z,y,x,w,v
z=this.P
y=this.k2
if(z){y.seQ(0,2)
z=this.k2.f
if(0>=z.length)return H.e(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isdv)z.sc0(x,this.a9z(this.A,this.a2))
J.a6(J.ba(x.gaW()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.e(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isdv)z.sc0(x,this.a9z(this.T,this.a2))
J.a6(J.ba(x.gaW()),"text-decoration",this.x1)}else{y.seQ(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.e(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isdv){y=this.A
w=J.k(y,J.B(J.L(J.p(this.T,y),J.p(this.fy,1)),v))
z.sc0(x,this.a9z(w,this.a2))}J.a6(J.ba(x.gaW()),"text-decoration",this.x1);++v}}this.fm(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.b(this.x2)+"px")},
bgM:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.L(J.p(this.fr,this.dy),z-1)
x=P.aC(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.L(a,2)
x=P.aC(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.p(w,x*(50-u)/100)
u=J.L(b,2)
x=P.aC(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.p(u,x*(50-w)/100)
r=C.c.C(this.J,"%")&&!0
x=this.J
if(r){H.cs("")
x=H.e8(x,"%","")}q=P.dH(x,null)
for(x=J.aw(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.e(w,p)
o=w[p]
w=J.k(J.p(this.dy,90),x.bC(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.NP(o)
w=m.b
u=J.F(w)
if(u.bB(w,0)){if(r){l=P.aC(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.L(l,w)}else k=0
l=m.a
j=J.aw(l)
i=J.k(j.bC(l,l),u.bC(w,w))
if(typeof i!=="number")H.ab(H.bn(i))
i=Math.sqrt(i)
h=J.B(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.X){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.B(j.dK(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.B(u.dK(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a6(J.ba(o.gaW()),"transform","")
i=J.n(o)
if(!!i.$isd3)i.jx(o,d,c)
else N.ft(o.gaW(),d,c)
i=J.ba(o.gaW())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," scale ("+H.b(k)+")"))
if(!J.a(this.y1,0))if(!!J.n(o.gaW()).$isnO){i=J.ba(o.gaW())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," rotate("+H.b(this.y1)+" "+H.b(j.dK(l,2))+" "+H.b(J.L(u.fo(w),2))+")"))}else{J.hZ(J.J(o.gaW())," rotate("+H.b(this.y1)+"deg)")
J.pa(J.J(o.gaW()),H.b(J.B(j.dK(l,2),k))+" "+H.b(J.B(u.dK(w,2),k)))}}},
bgN:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.L(J.p(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.e(x,0)
w=this.NP(x[0])
v=C.c.C(this.J,"%")&&!0
x=this.J
if(v){H.cs("")
x=H.e8(x,"%","")}u=P.dH(x,null)
x=w.b
t=J.F(x)
if(t.bB(x,0))s=J.L(v?J.L(J.B(a,u),200):u,x)
else s=0
r=J.L(J.B(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.af(r)))
p=Math.abs(Math.sin(H.af(r)))
this.akn(this,J.B(J.L(J.k(J.B(w.a,q),t.bC(x,p)),2),s))
this.a1J()
x=this.k2.f
if(y<0||y>=x.length)return H.e(x,y)
w=this.NP(x[y])
x=w.b
t=J.F(x)
if(t.bB(x,0))s=J.L(v?J.L(J.B(a,u),200):u,x)
else s=0
this.ako(J.B(J.L(J.k(J.B(w.a,q),t.bC(x,p)),2),s))
this.a1J()
if(!J.a(this.y1,0)){for(x=J.aw(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.e(t,n)
w=this.NP(t[n])
t=w.b
m=J.F(t)
if(m.bB(t,0))J.L(v?J.L(x.bC(a,u),200):u,t)
o=P.aH(J.k(J.B(w.a,p),m.bC(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.F(a)
k=J.L(J.p(x.D(a,this.K),this.a9),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.e(y,n)
j=y[n]
y=this.K
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.k(y,t)
w=this.NP(j)
y=w.b
m=J.F(y)
if(m.bB(y,0))s=J.L(v?J.L(x.bC(a,u),200):u,y)
else s=0
h=w.a
g=J.F(h)
i=J.p(i,J.B(g.dK(h,2),s))
J.a6(J.ba(j.gaW()),"transform","")
if(J.a(this.y1,0)){y=J.B(J.k(g.bC(h,p),m.bC(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.n(j)
if(!!y.$isd3)y.jx(j,i,f)
else N.ft(j.gaW(),i,f)
y=J.ba(j.gaW())
t=J.H(y)
t.l(y,"transform",J.k(t.h(y,"transform")," scale ("+H.b(s)+")"))}else{i=J.p(J.k(this.K,t),g.dK(h,2))
t=J.k(g.bC(h,p),m.bC(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.n(j)
if(!!t.$isd3)t.jx(j,i,e)
else N.ft(j.gaW(),i,e)
d=g.dK(h,2)
c=-y/2
y=J.ba(j.gaW())
t=J.H(y)
m=s-1
t.l(y,"transform",J.k(t.h(y,"transform")," translate("+H.b(J.B(J.bQ(d),m))+" "+H.b(-c*m)+")"))
m=J.ba(j.gaW())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," scale ("+H.b(s)+")"))
m=J.ba(j.gaW())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," rotate("+H.b(this.y1)+" "+H.b(d)+" "+H.b(c)+")"))}}},
NP:function(a){var z,y,x,w
if(!!J.n(a.gaW()).$isf1){z=H.j(a.gaW(),"$isf1").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.bC()
w=x*0.7}else{y=J.d6(a.gaW())
y.toString
w=J.cV(a.gaW())
w.toString}return H.d(new P.G(y,w),[null])},
a9J:[function(){return D.FN()},"$0","gx9",0,0,3],
a9z:function(a,b){var z=this.a8
if(z==null||J.a(z,""))return O.q3(a,"0",null,null)
else return O.q3(a,this.a8,null,null)},
V:[function(){this.akq(0)
this.dn()
var z=this.k2
z.d=!0
z.r=!0
z.seQ(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gdq",0,0,0],
aN9:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.y(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new D.ow(this.gx9(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
NH:{"^":"mv;",
ga5a:function(){return this.cy},
sa_J:["aJ6",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.x(a,100))a=100
if(!J.a(this.db,a)){this.db=a
this.dn()}}],
sa_K:["aJ7",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.x(a,100))a=100
if(!J.a(this.dx,a)){this.dx=a
this.dn()}}],
sXn:["aJ3",function(a){if(J.Q(a,-360))a=-360
if(J.x(a,360))a=360
if(!J.a(this.dy,a)){this.dy=a
this.ey()
this.dn()}}],
saqz:["aJ4",function(a,b){if(J.Q(b,-360))b=-360
if(J.x(b,360))b=360
if(!J.a(this.fr,b)){this.fr=b
this.ey()
this.dn()}}],
sbad:function(a){if(a==null||J.Q(a,0))a=0
if(J.x(a,20))a=20
if(!J.a(this.fx,a)){this.fx=a
this.dn()}},
sacM:["akq",function(a){if(a==null||J.Q(a,2))a=2
if(J.x(a,30))a=30
if(!J.a(this.fy,a)){this.fy=a
this.dn()}}],
sbae:function(a){if(this.go!==a){this.go=a
this.dn()}},
sb9J:function(a){if(this.id!==a){this.id=a
this.dn()}},
sa_L:["aJ8",function(a){if(a==null||J.Q(a,0))a=0
if(J.x(a,200))a=200
if(!J.a(this.k1,a)){this.k1=a
this.dn()}}],
gl7:function(){return this.cy},
fN:["aJ5",function(a,b,c,d){R.qy(a,b,c,d)}],
fm:["akp",function(a,b){R.vu(a,b)}],
Dj:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.i(a)
if(y!=="")J.a6(z.gfG(a),"d",y)
else J.a6(z.gfG(a),"d","M 0,0")}},
arm:{"^":"NH;",
sacL:["aJ9",function(a){if(!J.a(this.k4,a)){this.k4=a
this.dn()}}],
sb9I:function(a){if(!J.a(this.r2,a)){this.r2=a
this.dn()}},
stR:["aJa",function(a){if(!J.a(this.rx,a)){this.rx=a
this.dn()}}],
sM_:function(a){if(!J.a(this.x1,a)){this.x1=a
this.dn()}},
gta:function(){return this.x2},
sta:function(a){if(!J.a(this.x2,a)){this.x2=a
this.dn()}},
gwa:function(a){return this.y1},
swa:function(a,b){if(!J.a(this.y1,b)){this.y1=b
this.dn()}},
sM5:function(a){if(!J.a(this.y2,a)){this.y2=a
this.dn()}},
sbjm:function(a){if(!J.a(this.w,a)){this.w=a
this.dn()}},
sb0J:function(a){var z
if(!J.a(this.A,a)){this.A=a
if(a!=null){z=J.p(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.T=z
this.dn()}},
jM:function(a,b){var z,y
this.Jz(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.fN(this.k2,this.k4,J.aQ(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.fN(this.k3,this.rx,J.aQ(this.x1),this.ry)
if(J.a(this.x2,"circular"))this.b2T(a,b)
else this.b2U(a,b)},
b2T:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.L(J.p(this.fr,this.dy),J.p(J.k(J.B(this.fx,J.p(this.fy,1)),this.fy),1))
x=C.c.C(this.go,"%")&&!0
w=this.go
if(x){H.cs("")
w=H.e8(w,"%","")}v=P.dH(w,null)
if(x){w=P.aC(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.aC(a,b)
w=J.L(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.p(w,t*(50-s)/100)
s=J.L(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.p(s,t*(50-w)/100)
w=P.aC(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.a(this.w,"center"))o=0.5
else o=J.a(this.w,"outside")?1:0
w=o-1
s=J.aw(y)
n=0
while(!0){m=J.k(J.B(this.fx,J.p(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.k(J.p(this.dy,90),s.bC(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.T
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++n}this.Dj(this.k3)
z.a=""
y=J.L(J.p(this.fr,this.dy),J.p(this.fy,1))
h=C.c.C(this.id,"%")&&!0
s=this.id
if(h){H.cs("")
s=H.e8(s,"%","")}g=P.dH(s,null)
if(h){s=P.aC(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.aw(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.k(J.p(this.dy,90),s.bC(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.T
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++f}this.Dj(this.k2)},
b2U:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.c.C(this.go,"%")&&!0
y=this.go
if(z){H.cs("")
y=H.e8(y,"%","")}x=P.dH(y,null)
w=z?J.L(J.B(J.L(a,2),x),100):x
v=C.c.C(this.id,"%")&&!0
y=this.id
if(v){H.cs("")
y=H.e8(y,"%","")}u=P.dH(y,null)
t=v?J.L(J.B(J.L(a,2),u),100):u
y=this.cx
y.a=""
s=J.F(a)
r=J.L(J.p(s.D(a,this.y1),this.y2),J.p(J.k(J.B(this.fx,J.p(this.fy,1)),this.fy),1))
if(J.a(this.w,"center"))q=0.5
else q=J.a(this.w,"outside")?1:0
p=J.F(t)
o=p.D(t,w)
n=1-q
m=0
while(!0){l=J.k(J.B(this.fx,J.p(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.D(t,q*o)
y.a+="M "+H.b(k)+","+H.b(n*o)+" "
y.a+="L "+H.b(k)+","+H.b(j)+" ";++m}this.Dj(this.k3)
y.a=""
r=J.L(J.p(s.D(a,this.y1),this.y2),J.p(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.b(k)+",0 "
y.a+="L "+H.b(k)+","+H.b(t)+" ";++i}this.Dj(this.k2)},
V:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.Dj(z)
this.Dj(this.k3)}},"$0","gdq",0,0,0]},
arn:{"^":"NH;",
sa_J:function(a){this.aJ6(a)
this.r2=!0},
sa_K:function(a){this.aJ7(a)
this.r2=!0},
sXn:function(a){this.aJ3(a)
this.r2=!0},
saqz:function(a,b){this.aJ4(this,b)
this.r2=!0},
sa_L:function(a){this.aJ8(a)
this.r2=!0},
sbgw:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.dn()}},
sbgv:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.dn()}},
saix:function(a){if(this.x2!==a){this.x2=a
this.ey()
this.dn()}},
gkj:function(){return this.y1},
skj:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.a(this.y1,a)){this.y1=a
this.r2=!0
this.dn()}},
gta:function(){return this.y2},
sta:function(a){if(!J.a(this.y2,a)){this.y2=a
this.r2=!0
this.dn()}},
gwa:function(a){return this.w},
swa:function(a,b){if(!J.a(this.w,b)){this.w=b
this.r2=!0
this.dn()}},
sM5:function(a){if(!J.a(this.A,a)){this.A=a
this.r2=!0
this.dn()}},
ku:function(a){var z,y,x,w,v,u,t,s,r
this.CO(this)
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.K)(z),++u){t=z[u]
s=J.i(t)
y.push(s.gic(t))
x.push(s.gGb(t))
w.push(s.gwg(t))}if(J.cg(J.p(this.dy,this.fr))===!0){z=J.aX(J.p(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.f.S(0.5*z)}else r=0
this.k2=this.b_v(y,w,r)
this.k3=this.aXB(x,w,r)
this.r2=!0},
jM:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.Jz(a,b)
z=J.aw(a)
y=J.aw(b)
N.IS(this.k4,z.bC(a,1),y.bC(b,1))
if(J.a(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.aC(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.a(this.y2,"circular")){z=P.aH(0,P.aC(a,b))
this.rx=z
this.b2W(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.b(this.rx)+" "+H.b(this.rx))}else{z=J.B(J.p(z.D(a,this.w),this.A),1)
y.bC(b,1)
v=C.c.C(this.ry,"%")&&!0
y=this.ry
if(v){H.cs("")
y=H.e8(y,"%","")}u=P.dH(y,null)
t=v?J.L(J.B(z,u),100):u
s=C.c.C(this.x1,"%")&&!0
y=this.x1
if(s){H.cs("")
y=H.e8(y,"%","")}r=P.dH(y,null)
q=s?J.L(J.B(z,r),100):r
this.r1.seQ(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.p(q,t)
p=q
o=p
m=0
break
case"cross":y=J.F(q)
x=J.F(t)
o=J.k(y.dK(q,2),x.dK(t,2))
n=J.p(y.dK(q,2),x.dK(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.d(new P.G(this.w,o),[null])
k=H.d(new P.G(this.w,n),[null])
j=H.d(new P.G(J.k(this.w,z),p),[null])
i=H.d(new P.G(J.k(this.w,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.e(y,0)
h=y[0]
this.fm(h.gaW(),this.J)
R.qy(h.gaW(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.b(y)+","+H.b(x)+" "
z.a+="L "+H.b(j.a)+","+H.b(j.b)+" "
z.a+="L "+H.b(i.a)+","+H.b(i.b)+" "
z.a+="L "+H.b(k.a)+","+H.b(k.b)+" "
z.a+="L "+H.b(y)+","+H.b(x)+" "
this.Dj(h.gaW())
x=this.cy
x.toString
new W.e6(x).N(0,"viewBox")}},
b_v:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.la(J.B(J.p(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.e(a,y)
t=J.a_(J.c8(a[y],16),255)
if(y>=a.length)return H.e(a,y)
s=J.a_(J.c8(a[y],8),255)
if(y>=a.length)return H.e(a,y)
r=J.a_(a[y],255)
if(x>=a.length)return H.e(a,x)
q=J.a_(J.c8(a[x],16),255)
if(x>=a.length)return H.e(a,x)
p=J.a_(J.c8(a[x],8),255)
if(x>=a.length)return H.e(a,x)
o=J.a_(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.b.S(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.b.S(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.b.S(w*r+m*o)&255)>>>0)}}return z},
aXB:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.la(J.B(J.p(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.e(a,x)
v=a[x]
if(y>=w)return H.e(a,y)
t=J.L(J.p(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.e(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.k(w,s*t))}}return z},
b2W:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.aC(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.c.C(this.ry,"%")&&!0
z=this.ry
if(v){H.cs("")
z=H.e8(z,"%","")}u=P.dH(z,new D.aro())
if(v){z=P.aC(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.c.C(this.x1,"%")&&!0
z=this.x1
if(s){H.cs("")
z=H.e8(z,"%","")}r=P.dH(z,new D.arp())
if(s){z=P.aC(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.aC(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.aC(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.seQ(0,w)
for(z=J.F(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.p(this.dy,90)
d=J.p(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.k(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.D(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.e(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.e(e,d)
g=J.aV(J.B(e[d],255))
g=J.be(J.a(g,0)?1:g,24)
e=h.gaW()
a3=this.k2
if(d>=a3.length)return H.e(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.fm(e,a3+g)
a3=h.gaW()
e=this.k2
if(d>=e.length)return H.e(e,d)
R.qy(a3,e[d]+g,1,"solid")
y.a+="M "+H.b(l)+","+H.b(k)+" "
y.a+="L "+H.b(a)+","+H.b(a0)+" "
y.a+="L "+H.b(a1)+","+H.b(a2)+" "
y.a+="L "+H.b(j)+","+H.b(i)+" "
y.a+="L "+H.b(l)+","+H.b(k)+" "
this.Dj(h.gaW())}}},
bzp:[function(){var z,y
z=new D.abO(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gbgm",0,0,3],
V:["aJb",function(){var z=this.r1
z.d=!0
z.r=!0
z.seQ(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gdq",0,0,0],
aNa:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.saix([new D.zd(65280,0.5,0),new D.zd(16776960,0.8,0.5),new D.zd(16711680,1,1)])
z=new D.ow(this.gbgm(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
aro:{"^":"c:0;",
$1:function(a){return 0}},
arp:{"^":"c:0;",
$1:function(a){return 0}},
zd:{"^":"t;ic:a*,Gb:b>,wg:c>"}}],["","",,E,{"^":"",
c1o:[function(a){var z=!!J.n(a.gmx().gaW()).$ishe?H.j(a.gmx().gaW(),"$ishe"):null
if(z!=null)if(z.gqa()!=null&&!J.a(z.gqa(),""))return E.ZB(a.gmx(),z.gqa())
else return z.Lj(a)
return""},"$1","bTB",2,0,9,55],
bQs:function(){if($.Vv)return
$.Vv=!0
$.$get$il().l(0,"percentTextSize",E.bTG())
$.$get$il().l(0,"minorTicksPercentLength",E.ajF())
$.$get$il().l(0,"majorTicksPercentLength",E.ajF())
$.$get$il().l(0,"percentStartThickness",E.ajH())
$.$get$il().l(0,"percentEndThickness",E.ajH())
$.$get$im().l(0,"percentTextSize",E.bTH())
$.$get$im().l(0,"minorTicksPercentLength",E.ajG())
$.$get$im().l(0,"majorTicksPercentLength",E.ajG())
$.$get$im().l(0,"percentStartThickness",E.ajI())
$.$get$im().l(0,"percentEndThickness",E.ajI())},
bi8:function(a){var z
switch(a){case"chart":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$G3())
return z
case"scaleTicks":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$Hb())
return z
case"scaleLabels":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$H9())
return z
case"scaleTrack":z=[]
C.a.p(z,$.$get$ec())
C.a.p(z,$.$get$PQ())
return z
case"linearAxis":return $.$get$xY()
case"logAxis":return $.$get$y0()
case"categoryAxis":return $.$get$vi()
case"datetimeAxis":return $.$get$xL()
case"axisRenderer":return $.$get$vb()
case"radialAxisRenderer":return $.$get$PJ()
case"angularAxisRenderer":return $.$get$NS()
case"linearAxisRenderer":return $.$get$vb()
case"logAxisRenderer":return $.$get$vb()
case"categoryAxisRenderer":return $.$get$vb()
case"datetimeAxisRenderer":return $.$get$vb()
case"lineSeries":return $.$get$xW()
case"areaSeries":return $.$get$FK()
case"columnSeries":return $.$get$G5()
case"barSeries":return $.$get$FR()
case"bubbleSeries":return $.$get$FY()
case"pieSeries":return $.$get$Bv()
case"spectrumSeries":return $.$get$Q4()
case"radarSeries":return $.$get$Bz()
case"lineSet":return $.$get$tf()
case"areaSet":return $.$get$FM()
case"columnSet":return $.$get$G7()
case"barSet":return $.$get$FT()
case"gridlines":return $.$get$OR()}return[]},
bi6:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof E.oc)return a
else{z=$.$get$a07()
y=H.d([],[D.ex])
x=H.d([],[N.jY])
w=H.d([],[E.iW])
v=H.d([],[N.jY])
u=H.d([],[E.iW])
t=H.d([],[N.jY])
s=H.d([],[E.AS])
r=H.d([],[N.jY])
q=H.d([],[E.BA])
p=H.d([],[N.jY])
o=$.$get$ao()
n=$.S+1
$.S=n
n=new E.oc(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,null,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a7(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
n.cc(b,"chart")
J.V(J.y(n.b),"absolute")
o=E.atP()
n.v=o
J.bD(n.b,o.cx)
o=n.v
o.bj=n
o.TT()
o=E.aqA()
n.B=o
o.sdh(n.v)
return n}case"scaleTicks":if(a instanceof E.Ha)return a
else{z=$.$get$a3C()
y=$.$get$ao()
x=$.S+1
$.S=x
x=new E.Ha(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a7(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-ticks")
J.V(J.y(x.b),"absolute")
z=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.t,N.cc])),[P.t,N.cc])
z=new E.au3(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.cz(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.cy=P.iu()
x.v=z
J.bD(x.b,z.ga5a())
return x}case"scaleLabels":if(a instanceof E.H8)return a
else{z=$.$get$a3A()
y=$.$get$ao()
x=$.S+1
$.S=x
x=new E.H8(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a7(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-labels")
J.V(J.y(x.b),"absolute")
z=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.t,N.cc])),[P.t,N.cc])
z=new E.au1(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.cz(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.cy=P.iu()
z.aN9()
x.v=z
J.bD(x.b,z.ga5a())
x.v.se8(x)
return x}case"scaleTrack":if(a instanceof E.Hc)return a
else{z=$.$get$a3E()
y=$.$get$ao()
x=$.S+1
$.S=x
x=new E.Hc(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a7(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-track")
J.V(J.y(x.b),"absolute")
J.ld(J.J(x.b),"hidden")
y=E.au5()
x.v=y
J.bD(x.b,y.ga5a())
return x}}return},
c1U:[function(){var z=new E.avf(null,null,null)
z.alH()
return z},"$0","bTC",0,0,3],
atP:function(){var z,y,x,w,v,u,t
z=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.t,N.cc])),[P.t,N.cc])
y=P.bk(0,0,0,0,null)
x=P.bk(0,0,0,0,null)
w=new D.d2(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.d([],[P.fi])
t=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.v,P.t])),[P.v,P.t])
z=new E.ob(z,null,"none",!1,!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",D.bTb(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.aN8("chartBase")
z.aN6()
z.aNT()
z.sYA("single")
z.aNl()
return z},
c8H:[function(a,b,c){return E.bgI(a,c)},"$3","bTG",6,0,1,17,29,1],
bgI:function(a,b){var z,y,x
z=a.F("view")
if(z==null)return
y=J.d1(z)
if(y==null)return
x=J.i(y)
return J.L(J.B(J.a(y.gta(),"circular")?P.aC(x.gbG(y),x.gcl(y)):x.gbG(y),b),200)},
c8I:[function(a,b,c){return E.bgJ(a,c)},"$3","bTH",6,0,1,17,29,1],
bgJ:function(a,b){var z,y,x,w
z=a.F("view")
if(z==null)return
y=J.d1(z)
if(y==null)return
x=J.B(b,200)
w=J.i(y)
return J.L(x,J.a(y.gta(),"circular")?P.aC(w.gbG(y),w.gcl(y)):w.gbG(y))},
c8J:[function(a,b,c){return E.bgK(a,c)},"$3","ajF",6,0,1,17,29,1],
bgK:function(a,b){var z,y,x
z=a.F("view")
if(z==null)return
y=J.d1(z)
if(y==null)return
x=J.i(y)
return J.L(J.B(J.a(y.gta(),"circular")?P.aC(x.gbG(y),x.gcl(y)):x.gbG(y),b),200)},
c8K:[function(a,b,c){return E.bgL(a,c)},"$3","ajG",6,0,1,17,29,1],
bgL:function(a,b){var z,y,x,w
z=a.F("view")
if(z==null)return
y=J.d1(z)
if(y==null)return
x=J.B(b,200)
w=J.i(y)
return J.L(x,J.a(y.gta(),"circular")?P.aC(w.gbG(y),w.gcl(y)):w.gbG(y))},
c8L:[function(a,b,c){return E.bgM(a,c)},"$3","ajH",6,0,1,17,29,1],
bgM:function(a,b){var z,y,x
z=a.F("view")
if(z==null)return
y=J.d1(z)
if(y==null)return
x=J.i(y)
if(J.a(y.gta(),"circular")){x=P.aC(x.gbG(y),x.gcl(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.L(J.B(x.gbG(y),b),100)
return x},
c8M:[function(a,b,c){return E.bgN(a,c)},"$3","ajI",6,0,1,17,29,1],
bgN:function(a,b){var z,y,x,w
z=a.F("view")
if(z==null)return
y=J.d1(z)
if(y==null)return
x=J.aw(b)
w=J.i(y)
return J.a(y.gta(),"circular")?J.L(x.bC(b,200),P.aC(w.gbG(y),w.gcl(y))):J.L(x.bC(b,100),w.gbG(y))},
avf:{"^":"Qs;a,b,c",
sc0:function(a,b){var z,y,x,w,v
if(J.a(this.b,b))return
this.aJW(this,b)
if(b instanceof D.lZ){z=b.e
if(z.gaW() instanceof D.ex&&H.j(z.gaW(),"$isex").w!=null){J.Ag(J.J(this.a),"")
return}y=U.c3(b.r,"fault")
if(y==="fault"&&b.r instanceof V.u){x=b.r
if(J.a(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof V.eZ&&J.x(w.x1,0)){z=H.j(w.di(0),"$isk9")
y=U.dX(z.gic(z),null,"rgba(0,0,0,0)")}}}v=H.b(y==="fault"?U.dX(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.Ag(J.J(this.a),v)}},
aj7:function(a){J.b2(this.a,a,$.$get$aB())}},
au1:{"^":"arl;ab,a7,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,T,J,a2,P,a8,a5,U,X,K,a9,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
stO:function(a){var z=this.k4
if(z instanceof V.u)H.j(z,"$isu").dk(this.geq())
this.aJ2(a)
if(a instanceof V.u)a.dI(this.geq())},
swa:function(a,b){this.akn(this,b)
this.a1J()},
sM5:function(a){this.ako(a)
this.a1J()},
ge8:function(){return this.a7},
se8:function(a){H.j(a,"$isaU")
this.a7=a
if(a!=null)V.bf(this.gbl9())},
fm:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.akp(a,b)
return}if(!!J.n(a).$isbg){z=this.ab.a
if(!z.W(0,a))z.l(0,a,new N.cc(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kC(b)}},
ra:[function(a){this.dn()},"$1","geq",2,0,2,10],
a1J:[function(){var z=this.a7
if(z!=null)if(z.a instanceof V.u)V.W(new E.au2(this))},"$0","gbl9",0,0,0]},
au2:{"^":"c:3;a",
$0:[function(){var z=this.a
z.a7.a.bm("offsetLeft",z.K)
z.a7.a.bm("offsetRight",z.a9)},null,null,0,0,null,"call"]},
H8:{"^":"aRU;aG,fa:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cd,cf,c9,cm,cr,cB,cC,bT,cL,cT,cn,cz,cG,bZ,co,cu,cE,cD,cF,cH,cN,cJ,cX,cv,cO,cM,cA,cP,ci,bO,cw,cR,cU,cV,cK,cj,cS,dd,de,cZ,d0,dg,d_,cQ,d1,d2,d8,cs,d3,d4,cI,d5,d9,da,cW,d6,cY,cp,dc,d7,P,a8,a5,U,X,K,a9,ab,a7,ak,ao,ac,ar,ai,aw,aC,aM,ah,aT,aA,aD,aq,ax,aP,aS,az,aR,b8,aJ,b1,bl,bn,aQ,bp,bb,b9,br,bh,by,bH,bz,bd,bu,b_,bv,bq,bw,bJ,cg,c_,bQ,bM,bN,c7,bR,bX,bS,bW,bE,bt,bj,c5,ck,c4,bP,c1,ce,y2,w,A,T,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdS:function(){return this.aG},
seM:function(a,b){if(J.a(this.ab,"none")&&!J.a(b,"none")){this.mN(this,b)
this.eu()}else this.mN(this,b)},
h0:[function(a,b){this.nd(this,b)
this.shB(!0)},"$1","gf6",2,0,2,10],
jW:[function(a){this.xV()},"$0","gim",0,0,0],
V:[function(){this.shB(!1)
this.fO()
this.v.sLS(!0)
this.v.V()
this.v.stO(null)
this.v.sLS(!1)},"$0","gdq",0,0,0],
ig:[function(){this.shB(!1)
this.fO()},"$0","gkz",0,0,0],
ha:function(){this.wK()
this.shB(!0)},
xV:function(){if(this.a instanceof V.u)this.v.jg(J.d6(this.b),J.cV(this.b))},
eu:function(){var z,y
this.CR()
this.sov(-1)
z=this.v
y=J.i(z)
y.sbG(z,J.p(y.gbG(z),1))},
$isbO:1,
$isbP:1,
$iscq:1},
aRU:{"^":"aU+lu;ov:x$?,tP:y$?",$iscq:1},
bA2:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sta(U.ar(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bA3:{"^":"c:44;",
$2:[function(a,b){J.MI(J.d1(a),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bA4:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sM5(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bA5:{"^":"c:44;",
$2:[function(a,b){J.Al(J.d1(a),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bA6:{"^":"c:44;",
$2:[function(a,b){J.Ak(J.d1(a),U.b0(b,100))},null,null,4,0,null,0,2,"call"]},
bA7:{"^":"c:44;",
$2:[function(a,b){J.d1(a).syZ(U.E(b,""))},null,null,4,0,null,0,2,"call"]},
bA8:{"^":"c:44;",
$2:[function(a,b){J.d1(a).saHc(U.R(b,!1))},null,null,4,0,null,0,2,"call"]},
bA9:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sbgx(U.ko(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
bAa:{"^":"c:44;",
$2:[function(a,b){J.d1(a).stO(R.cU(b,16777215))},null,null,4,0,null,0,2,"call"]},
bAc:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sLE(U.E(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
bAd:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sLF(U.ar(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bAe:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sLG(U.ar(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bAf:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sLI(U.ar(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
bAg:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sLH(U.ag(b,0))},null,null,4,0,null,0,2,"call"]},
bAh:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sb8B(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bAi:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sb8A(U.ar(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
bAj:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sXn(U.b0(b,-120))},null,null,4,0,null,0,2,"call"]},
bAk:{"^":"c:44;",
$2:[function(a,b){J.Mu(J.d1(a),U.b0(b,120))},null,null,4,0,null,0,2,"call"]},
bAl:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sa_J(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bAn:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sa_K(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bAo:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sa_L(U.b0(b,90))},null,null,4,0,null,0,2,"call"]},
bAp:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sacM(U.ag(b,11))},null,null,4,0,null,0,2,"call"]},
bAq:{"^":"c:44;",
$2:[function(a,b){J.d1(a).sb8m(U.ar(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
au3:{"^":"arm;J,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,T,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
stR:function(a){var z=this.rx
if(z instanceof V.u)H.j(z,"$isu").dk(this.geq())
this.aJa(a)
if(a instanceof V.u)a.dI(this.geq())},
sacL:function(a){var z=this.k4
if(z instanceof V.u)H.j(z,"$isu").dk(this.geq())
this.aJ9(a)
if(a instanceof V.u)a.dI(this.geq())},
fN:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.J.a
if(z.W(0,a))z.h(0,a).kN(null)
this.aJ5(a,b,c,d)
return}if(!!J.n(a).$isbg){z=this.J.a
if(!z.W(0,a))z.l(0,a,new N.cc(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kN(b)
y.smr(c)
y.sm4(d)}},
ra:[function(a){this.dn()},"$1","geq",2,0,2,10]},
Ha:{"^":"aRV;aG,fa:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cd,cf,c9,cm,cr,cB,cC,bT,cL,cT,cn,cz,cG,bZ,co,cu,cE,cD,cF,cH,cN,cJ,cX,cv,cO,cM,cA,cP,ci,bO,cw,cR,cU,cV,cK,cj,cS,dd,de,cZ,d0,dg,d_,cQ,d1,d2,d8,cs,d3,d4,cI,d5,d9,da,cW,d6,cY,cp,dc,d7,P,a8,a5,U,X,K,a9,ab,a7,ak,ao,ac,ar,ai,aw,aC,aM,ah,aT,aA,aD,aq,ax,aP,aS,az,aR,b8,aJ,b1,bl,bn,aQ,bp,bb,b9,br,bh,by,bH,bz,bd,bu,b_,bv,bq,bw,bJ,cg,c_,bQ,bM,bN,c7,bR,bX,bS,bW,bE,bt,bj,c5,ck,c4,bP,c1,ce,y2,w,A,T,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdS:function(){return this.aG},
seM:function(a,b){if(J.a(this.ab,"none")&&!J.a(b,"none")){this.mN(this,b)
this.eu()}else this.mN(this,b)},
h0:[function(a,b){this.nd(this,b)
this.shB(!0)
if(b==null)this.v.jg(J.d6(this.b),J.cV(this.b))},"$1","gf6",2,0,2,10],
jW:[function(a){this.v.jg(J.d6(this.b),J.cV(this.b))},"$0","gim",0,0,0],
V:[function(){this.shB(!1)
this.fO()
this.v.sLS(!0)
this.v.V()
this.v.stR(null)
this.v.sacL(null)
this.v.sLS(!1)},"$0","gdq",0,0,0],
ig:[function(){this.shB(!1)
this.fO()},"$0","gkz",0,0,0],
ha:function(){this.wK()
this.shB(!0)},
eu:function(){var z,y
this.CR()
this.sov(-1)
z=this.v
y=J.i(z)
y.sbG(z,J.p(y.gbG(z),1))},
xV:function(){this.v.jg(J.d6(this.b),J.cV(this.b))},
$isbO:1,
$isbP:1},
aRV:{"^":"aU+lu;ov:x$?,tP:y$?",$iscq:1},
bAr:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sta(U.ar(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bAs:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sbjm(U.ar(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
bAt:{"^":"c:54;",
$2:[function(a,b){J.MI(J.d1(a),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bAu:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sM5(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bAv:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sacL(R.cU(b,16777215))},null,null,4,0,null,0,2,"call"]},
bAw:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sb9I(U.ag(b,1))},null,null,4,0,null,0,2,"call"]},
bAy:{"^":"c:54;",
$2:[function(a,b){J.d1(a).stR(R.cU(b,16777215))},null,null,4,0,null,0,2,"call"]},
bAz:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sM_(U.ag(b,1))},null,null,4,0,null,0,2,"call"]},
bAA:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sXn(U.b0(b,-120))},null,null,4,0,null,0,2,"call"]},
bAB:{"^":"c:54;",
$2:[function(a,b){J.Mu(J.d1(a),U.b0(b,120))},null,null,4,0,null,0,2,"call"]},
bAC:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sa_J(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bAD:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sa_K(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bAE:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sa_L(U.b0(b,90))},null,null,4,0,null,0,2,"call"]},
bAF:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sacM(U.ag(b,11))},null,null,4,0,null,0,2,"call"]},
bAG:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sb9J(U.ko(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
bAH:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sbad(U.ag(b,2))},null,null,4,0,null,0,2,"call"]},
bAJ:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sbae(U.ko(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
bAK:{"^":"c:54;",
$2:[function(a,b){J.d1(a).sb0J(U.b0(b,null))},null,null,4,0,null,0,2,"call"]},
au4:{"^":"arn;T,J,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gkQ:function(){return this.J},
skQ:function(a){var z=this.J
if(z!=null)z.dk(this.gagh())
this.J=a
if(a!=null)a.dI(this.gagh())
if(!this.r)this.bkI(null)},
aq8:function(a){if(a!=null){a.h_(V.iA(new V.dU(0,255,0,1),0,0))
a.h_(V.iA(new V.dU(0,0,0,1),0,50))}},
bkI:[function(a){var z,y,x,w,v,u,t,s,r,q
z=this.J
if(z==null){z=new V.eZ(!1,null,H.d([],[V.aD]),0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!1,null,null,-1,null,!1,null,!1,null,!1,0,null,null,null,null,null)
z.bs()
z.aO(!1,null)
z.ch=null
this.aq8(z)}else{y=J.i(z)
x=y.hO(z)
for(w=J.H(x),v=J.p(w.gm(x),1);u=J.F(v),u.dj(v,0);v=u.D(v,1))if(w.h(x,v)==null)y.N(z,v)
if(J.a(J.I(y.hO(z)),0))this.aq8(z)}t=J.ha(z)
y=J.b5(t)
y.f0(t,V.uy())
s=[]
if(J.x(y.gm(t),1))for(y=y.gba(t);y.u();){r=y.gI()
w=J.i(r)
u=w.gic(r)
q=H.dl(r.i("alpha"))
q.toString
s.push(new D.zd(u,q,J.L(w.gwg(r),100)))}else if(J.a(y.gm(t),1)){r=y.h(t,0)
y=J.i(r)
w=y.gic(r)
u=H.dl(r.i("alpha"))
u.toString
s.push(new D.zd(w,u,0))
y=y.gic(r)
u=H.dl(r.i("alpha"))
u.toString
s.push(new D.zd(y,u,1))}this.saix(s)},"$1","gagh",2,0,6,10],
fm:function(a,b){var z,y,x
if(typeof b==="number"&&Math.floor(b)===b){this.akp(a,b)
return}if(!!J.n(a).$isbg){z=this.T.a
if(!z.W(0,a))z.l(0,a,new N.cc(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
x=V.cZ(!1,null)
x.O("fillType",!0).aj("gradient")
x.O("gradient",!0).$2(b,!1)
x.O("gradientType",!0).aj("linear")
y.kC(x)
x.V()}},
V:[function(){var z=this.J
if(z!=null&&!J.a(z,$.$get$B3())){this.J.dk(this.gagh())
this.J=null}this.aJb()},"$0","gdq",0,0,0],
aNm:function(){var z=$.$get$B3()
if(J.a(z.x1,0)){z.h_(V.iA(new V.dU(0,255,0,1),1,0))
z.h_(V.iA(new V.dU(255,255,0,1),1,50))
z.h_(V.iA(new V.dU(255,0,0,1),1,100))}},
ap:{
au5:function(){var z=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.t,N.cc])),[P.t,N.cc])
z=new E.au4(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.cz(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.cy=P.iu()
z.aNa()
z.aNm()
return z}}},
Hc:{"^":"aRW;aG,fa:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cd,cf,c9,cm,cr,cB,cC,bT,cL,cT,cn,cz,cG,bZ,co,cu,cE,cD,cF,cH,cN,cJ,cX,cv,cO,cM,cA,cP,ci,bO,cw,cR,cU,cV,cK,cj,cS,dd,de,cZ,d0,dg,d_,cQ,d1,d2,d8,cs,d3,d4,cI,d5,d9,da,cW,d6,cY,cp,dc,d7,P,a8,a5,U,X,K,a9,ab,a7,ak,ao,ac,ar,ai,aw,aC,aM,ah,aT,aA,aD,aq,ax,aP,aS,az,aR,b8,aJ,b1,bl,bn,aQ,bp,bb,b9,br,bh,by,bH,bz,bd,bu,b_,bv,bq,bw,bJ,cg,c_,bQ,bM,bN,c7,bR,bX,bS,bW,bE,bt,bj,c5,ck,c4,bP,c1,ce,y2,w,A,T,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdS:function(){return this.aG},
seM:function(a,b){if(J.a(this.ab,"none")&&!J.a(b,"none")){this.mN(this,b)
this.eu()}else this.mN(this,b)},
h0:[function(a,b){this.nd(this,b)
this.shB(!0)},"$1","gf6",2,0,2,10],
jW:[function(a){this.xV()},"$0","gim",0,0,0],
V:[function(){this.shB(!1)
this.fO()
this.v.sLS(!0)
this.v.V()
this.v.skQ(null)
this.v.sLS(!1)},"$0","gdq",0,0,0],
ig:[function(){this.shB(!1)
this.fO()},"$0","gkz",0,0,0],
ha:function(){this.wK()
this.shB(!0)},
eu:function(){var z,y
this.CR()
this.sov(-1)
z=this.v
y=J.i(z)
y.sbG(z,J.p(y.gbG(z),1))},
xV:function(){if(this.a instanceof V.u)this.v.jg(J.d6(this.b),J.cV(this.b))},
$isbO:1,
$isbP:1},
aRW:{"^":"aU+lu;ov:x$?,tP:y$?",$iscq:1},
bzN:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sta(U.ar(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bzR:{"^":"c:83;",
$2:[function(a,b){J.MI(J.d1(a),U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bzS:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sM5(U.b0(b,0))},null,null,4,0,null,0,2,"call"]},
bzT:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sbgw(U.ko(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
bzU:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sbgv(U.ko(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
bzV:{"^":"c:83;",
$2:[function(a,b){J.d1(a).skj(U.ar(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
bzW:{"^":"c:83;",
$2:[function(a,b){var z=J.d1(a)
z.skQ(b!=null?V.ro(b):$.$get$B3())},null,null,4,0,null,0,2,"call"]},
bzX:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sXn(U.b0(b,-120))},null,null,4,0,null,0,2,"call"]},
bzY:{"^":"c:83;",
$2:[function(a,b){J.Mu(J.d1(a),U.b0(b,120))},null,null,4,0,null,0,2,"call"]},
bzZ:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sa_J(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bA_:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sa_K(U.b0(b,50))},null,null,4,0,null,0,2,"call"]},
bA1:{"^":"c:83;",
$2:[function(a,b){J.d1(a).sa_L(U.b0(b,90))},null,null,4,0,null,0,2,"call"]},
AM:{"^":"t;aho:a@,jw:b*,ki:c*"},
aqz:{"^":"mv;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,c,d,e,f,r,x,y,z,Q,ch,a,b",
gtC:function(){return this.r1},
stC:function(a){if(!J.a(this.r1,a)){this.r1=a
this.dn()}},
gdh:function(){return this.r2},
sdh:function(a){this.bhE(a)},
gl7:function(){return this.go},
jM:function(a,b){var z,y,x,w
this.Jz(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.iu()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.b(a)+"px"
z.width=y
z=this.id.style
y=H.b(b)+"px"
z.height=y
this.fN(this.k1,0,0,"none")
this.fm(this.k1,this.r2.cC)
z=this.k2
y=this.r2
this.fN(z,y.cm,J.aQ(y.cr),this.r2.cB)
y=this.k3
z=this.r2
this.fN(y,z.cm,J.aQ(z.cr),this.r2.cB)
z=this.db
if(z===2){z=J.x(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a1(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aH(a))
y=this.k1
y.toString
y.setAttribute("height",J.a1(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a1(J.k(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aH(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.b.aH(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.b(this.cy.b)+" L "+H.b(a)+","+H.b(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.b(J.k(this.cy.b,this.r1.b))+" L "+H.b(a)+","+H.b(J.k(this.cy.b,this.r1.b)))}else if(z===1){z=J.x(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a1(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a1(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aH(b))}else{x.toString
x.setAttribute("x",J.a1(J.k(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.b.aH(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aH(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.b(this.cy.a)+",0 L "+H.b(this.cy.a)+","+H.b(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.b(J.k(this.cy.a,this.r1.a))+",0 L "+H.b(J.k(this.cy.a,this.r1.a))+","+H.b(b))}else if(z===3){z=J.x(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a1(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a1(this.r1.a))}else{y.toString
y.setAttribute("x",J.a1(J.k(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.b.aH(0-y))}z=J.x(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a1(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a1(this.r1.b))}else{y.toString
y.setAttribute("y",J.a1(J.k(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.b.aH(0-y))}z=this.k1
y=this.r2
this.fN(z,y.cm,J.aQ(y.cr),this.r2.cB)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
bhE:function(a){var z,y
this.aff()
this.afg()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().E(0)
this.r2.r0(0,"CartesianChartZoomerReset",this.gauq())}this.r2=a
if(a!=null){z=this.fx
y=J.cj(a.cx)
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaZi()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.r2.oS(0,"CartesianChartZoomerReset",this.gauq())
if($.$get$hF()===!0){y=this.r2.cx
y.toString
y=H.d(new W.bI(y,"touchstart",!1),[H.r(C.T,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaZj()),y.c),[H.r(y,0)])
y.t()
z.push(y)}}this.dx=null
this.dy=null},
aZo:function(a){var z=J.n(a)
return!!z.$istT||!!z.$isir||!!z.$isjv},
Qh:function(a){return C.a.iE(this.Nz(a),new E.aqB(this),V.LK())!=null},
aEF:function(a){var z=J.n(a)
if(!!z.$isjv)return J.av(a.db)?null:a.db
else if(!!z.$iskN)return a.db
return 0/0},
a3I:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isjv){if(b==null)y=null
else{y=J.aV(b)
x=!a.ac
w=new P.aj(y,x)
w.eL(y,x)
y=w}z.sjw(a,y)}else if(!!z.$isir)z.sjw(a,b)
else if(!!z.$istT)z.sjw(a,b)},
aGI:function(a,b){return this.a3I(a,b,!1)},
aED:function(a){var z=J.n(a)
if(!!z.$isjv)return J.av(a.cy)?null:a.cy
else if(!!z.$iskN)return a.cy
return 0/0},
a3H:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isjv){if(b==null)y=null
else{y=J.aV(b)
x=!a.ac
w=new P.aj(y,x)
w.eL(y,x)
y=w}z.ski(a,y)}else if(!!z.$isir)z.ski(a,b)
else if(!!z.$istT)z.ski(a,b)},
aGG:function(a,b){return this.a3H(a,b,!1)},
ahn:function(a,b,a0){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=a===2
if(z){y=this.dy
if(y==null){y=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[D.eF,E.AM])),[D.eF,E.AM])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[D.eF,E.AM])),[D.eF,E.AM])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.Nz(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.K)(v),++u){t=v[u]
s=x.a
if(!s.W(0,t)){r=J.n(t)
r=!!r.$istT||!!r.$isir||!!r.$isjv}else r=!1
if(r)s.l(0,t,new E.AM(!1,this.aEF(t),this.aED(t)))}}y=this.cy
if(z){y=y.b
q=P.aH(y,J.k(y,b))
y=this.cy.b
p=P.aC(y,J.k(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aH(y,J.k(y,b))
y=this.cy.a
m=P.aC(y,J.k(y,b))
o="h"
q=null
p=null}l=[]
k=D.k0(this.r2.ai,!1)
for(y=k.length,s=o==="v",r=!a0,j=null,i=null,h=null,g=null,u=0;u<k.length;k.length===y||(0,H.K)(k),++u){f=k[u]
if(!(f instanceof D.kB))continue
if(f.go!==!0||f.fy!==!0){g=f
continue}h=s?f.ar:f.ac
e=J.n(h)
if(!(!!e.$istT||!!e.$isir||!!e.$isjv)){g=f
continue}if(J.am(C.a.bA(l,h),0)){g=f
continue}l.push(h)
e=f.cy
if(z){d=F.b9(e,H.d(new P.G(0,0),[null]))
e=J.aQ(F.aO(J.ae(f.gdh()),d).b)
if(typeof q!=="number")return q.D()
e=H.d(new P.G(0,q-e),[null])
j=J.q(f.fr.rK([J.p(e.a,C.b.S(f.cy.offsetLeft)),J.p(e.b,C.b.S(f.cy.offsetTop))]),1)
d=F.b9(f.cy,H.d(new P.G(0,0),[null]))
e=J.aQ(F.aO(J.ae(f.gdh()),d).b)
if(typeof p!=="number")return p.D()
e=H.d(new P.G(0,p-e),[null])
i=J.q(f.fr.rK([J.p(e.a,C.b.S(f.cy.offsetLeft)),J.p(e.b,C.b.S(f.cy.offsetTop))]),1)}else{d=F.b9(e,H.d(new P.G(0,0),[null]))
e=J.aQ(F.aO(J.ae(f.gdh()),d).a)
if(typeof m!=="number")return m.D()
e=H.d(new P.G(m-e,0),[null])
j=J.q(f.fr.rK([J.p(e.a,C.b.S(f.cy.offsetLeft)),J.p(e.b,C.b.S(f.cy.offsetTop))]),0)
d=F.b9(f.cy,H.d(new P.G(0,0),[null]))
e=J.aQ(F.aO(J.ae(f.gdh()),d).a)
if(typeof n!=="number")return n.D()
e=H.d(new P.G(n-e,0),[null])
i=J.q(f.fr.rK([J.p(e.a,C.b.S(f.cy.offsetLeft)),J.p(e.b,C.b.S(f.cy.offsetTop))]),0)}if(J.Q(i,j)){c=i
i=j
j=c}this.aGI(h,j)
this.aGG(h,i)
if(!this.fr){x.a.h(0,h).saho(!0)
if(h!=null&&r){e=this.r2
if(z){e.cf=j
e.c9=i
e.aCS()}else{e.c1=j
e.ce=i
e.aBT()}}}this.fr=!0
if(!this.r2.ck)break
g=f}},
aDA:function(a,b){return this.ahn(a,b,!1)},
aA4:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.Nz(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.W(0,t)){this.a3I(t,J.Xd(w.h(0,t)),!0)
this.a3H(t,J.Xc(w.h(0,t)),!0)
if(w.h(0,t).gaho())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.c1=0/0
x.ce=0/0
x.aBT()}},
aff:function(){return this.aA4(!1)},
aA9:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.Nz(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.W(0,t)){this.a3I(t,J.Xd(w.h(0,t)),!0)
this.a3H(t,J.Xc(w.h(0,t)),!0)
if(w.h(0,t).gaho())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.cf=0/0
x.c9=0/0
x.aCS()}},
afg:function(){return this.aA9(!1)},
aDB:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.F(a)
if(z.gke(a)||J.av(b)){if(this.fr)if(c)this.aA9(!0)
else this.aA4(!0)
return}if(!this.Qh(c))return
y=this.Nz(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.aEZ(x)
if(w==null)return
v=J.n(b)
if(c){u=J.k(w.L1(["0",z.aH(a)]).b,this.aiv(w))
t=J.k(w.L1(["0",v.aH(b)]).b,this.aiv(w))
this.cy=H.d(new P.G(50,u),[null])
this.ahn(2,J.p(t,u),!0)}else{s=J.k(w.L1([z.aH(a),"0"]).a,this.aiu(w))
r=J.k(w.L1([v.aH(b),"0"]).a,this.aiu(w))
this.cy=H.d(new P.G(s,50),[null])
this.ahn(1,J.p(r,s),!0)}},
Nz:function(a){var z,y,x,w,v,u,t
z=[]
y=D.k0(this.r2.ai,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.K)(y),++v){u=y[v]
if(!(u instanceof D.kB))continue
if(a){t=u.ar
if(t!=null&&J.Q(C.a.bA(z,t),0))z.push(u.ar)}else{t=u.ac
if(t!=null&&J.Q(C.a.bA(z,t),0))z.push(u.ac)}w=u}return z},
aEZ:function(a){var z,y,x,w,v
z=D.k0(this.r2.ai,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.K)(z),++w){v=z[w]
if(!(v instanceof D.kB))continue
if(J.a(v.ar,a)||J.a(v.ac,a))return v
x=v}return},
aiu:function(a){var z=F.b9(a.cy,H.d(new P.G(0,0),[null]))
return J.aQ(F.aO(J.ae(a.gdh()),z).a)},
aiv:function(a){var z=F.b9(a.cy,H.d(new P.G(0,0),[null]))
return J.aQ(F.aO(J.ae(a.gdh()),z).b)},
fN:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.W(0,a))z.h(0,a).kN(null)
R.qy(a,b,c,d)
return}if(!!J.n(a).$isbg){z=this.k4.a
if(!z.W(0,a))z.l(0,a,new N.cc(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kN(b)
y.smr(c)
y.sm4(d)}},
fm:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.W(0,a))z.h(0,a).kC(null)
R.vu(a,b)
return}if(!!J.n(a).$isbg){z=this.k4.a
if(!z.W(0,a))z.l(0,a,new N.cc(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kC(b)}},
aS2:function(a){var z,y,x,w
for(z=a.length,y=this.rx,x=0;x<a.length;a.length===z||(0,H.K)(a),++x){w=a[x]
if(y.C(0,w.identifier))return w}return},
aS3:function(a){var z,y,x,w
z=this.rx
z.dP(0)
for(y=a.length,x=0;w=a.length,x<w;a.length===y||(0,H.K)(a),++x)z.n(0,a[x].identifier)
if(0>=w)return H.e(a,0)
return a[0]},
brw:[function(a){var z,y
if($.$get$hF()===!0){z=Date.now()
y=$.nq
if(typeof y!=="number")return H.l(y)
y=z-y<1000
z=y}else z=!1
if(z)return
this.ayU(J.ck(a))},"$1","gaZi",2,0,4,4],
brx:[function(a){var z=this.aS3(J.M8(a))
$.nq=Date.now()
this.ayU(H.d(new P.G(C.b.S(z.pageX),C.b.S(z.pageY)),[null]))},"$1","gaZj",2,0,5,4],
ayU:function(a){var z,y
z=this.r2
if(!z.c4&&!z.cd)return
z.cx.appendChild(this.go)
z=this.r2
this.jg(z.Q,z.ch)
this.cy=F.aO(this.go,a)
this.cx=!0
z=this.fy
y=H.d(new W.az(document,"mousemove",!1),[H.r(C.x,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaFk()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.az(document,"mouseup",!1),[H.r(C.z,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaFl()),y.c),[H.r(y,0)])
y.t()
z.push(y)
if($.$get$hF()===!0){y=H.d(new W.az(document,"touchmove",!1),[H.r(C.av,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaFn()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.az(document,"touchend",!1),[H.r(C.ab,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaFm()),y.c),[H.r(y,0)])
y.t()
z.push(y)}y=H.d(new W.az(document,"keydown",!1),[H.r(C.a4,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gDZ()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.db=0
this.stC(null)},
bnq:[function(a){this.ayV(J.ck(a))},"$1","gaFk",2,0,4,4],
bnt:[function(a){var z=this.aS2(J.M8(a))
if(z!=null)this.ayV(J.ck(z))},"$1","gaFn",2,0,5,4],
ayV:function(a){var z,y
z=F.aO(this.go,a)
if(this.db===0)if(this.r2.bP){if(!(this.Qh(!0)&&this.Qh(!1))){this.KP()
return}if(J.am(J.aX(J.p(z.a,this.cy.a)),2)&&J.am(J.aX(J.p(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.x(J.aX(J.p(z.b,this.cy.b)),J.aX(J.p(z.a,this.cy.a)))){if(this.Qh(!0))this.db=2
else{this.KP()
return}y=2}else{if(this.Qh(!1))this.db=1
else{this.KP()
return}y=1}if(y===1)if(!this.r2.c4){this.KP()
return}if(y===2)if(!this.r2.cd){this.KP()
return}}y=this.r2
if(P.bk(0,0,y.Q,y.ch,null).pk(0,z)){y=this.db
if(y===2)this.stC(H.d(new P.G(0,J.p(z.b,this.cy.b)),[null]))
else if(y===1)this.stC(H.d(new P.G(J.p(z.a,this.cy.a),0),[null]))
else if(y===3)this.stC(H.d(new P.G(J.p(z.a,this.cy.a),J.p(z.b,this.cy.b)),[null]))
else this.stC(null)}},
bnr:[function(a){this.ayW()},"$1","gaFl",2,0,4,4],
bns:[function(a){this.ayW()},"$1","gaFm",2,0,5,4],
ayW:function(){var z,y
for(z=this.fy;z.length>0;)z.pop().E(0)
J.Z(this.go)
this.cx=!1
this.dn()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.aDA(2,z.b)
z=this.db
if(z===1||z===3)this.aDA(1,this.r1.a)}else{this.aff()
V.W(new E.aqD(this))}},
ab3:[function(a){if(F.d_(a)===27)this.KP()},"$1","gDZ",2,0,7,4],
KP:function(){for(var z=this.fy;z.length>0;)z.pop().E(0)
J.Z(this.go)
this.cx=!1
this.dn()},
bud:[function(a){this.aff()
V.W(new E.aqC(this))},"$1","gauq",2,0,8,4],
aN7:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.y(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
ap:{
aqA:function(){var z,y
z=H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.t,N.cc])),[P.t,N.cc])
y=P.a7(null,null,null,P.O)
z=new E.aqz(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,y,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.a9(H.d(new H.a3(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.aN7()
return z}}},
aqB:{"^":"c:0;a",
$1:function(a){return this.a.aZo(a)}},
aqD:{"^":"c:3;a",
$0:[function(){this.a.afg()},null,null,0,0,null,"call"]},
aqC:{"^":"c:3;a",
$0:[function(){this.a.afg()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.b8,args:[V.u,P.v,P.b8]},{func:1,v:true,args:[[P.a0,P.v]]},{func:1,ret:F.bO},{func:1,v:true,args:[W.cG]},{func:1,v:true,args:[W.iI]},{func:1,v:true,args:[P.t]},{func:1,v:true,args:[W.hr]},{func:1,v:true,args:[N.cy]},{func:1,ret:P.v,args:[D.lZ]}]
init.types.push.apply(init.types,deferredTypes)
$.Vv=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["a3z","$get$a3z",function(){return P.m(["scaleType",new E.bA2(),"offsetLeft",new E.bA3(),"offsetRight",new E.bA4(),"minimum",new E.bA5(),"maximum",new E.bA6(),"formatString",new E.bA7(),"showMinMaxOnly",new E.bA8(),"percentTextSize",new E.bA9(),"labelsColor",new E.bAa(),"labelsFontFamily",new E.bAc(),"labelsFontStyle",new E.bAd(),"labelsFontWeight",new E.bAe(),"labelsTextDecoration",new E.bAf(),"labelsLetterSpacing",new E.bAg(),"labelsRotation",new E.bAh(),"labelsAlign",new E.bAi(),"angleFrom",new E.bAj(),"angleTo",new E.bAk(),"percentOriginX",new E.bAl(),"percentOriginY",new E.bAn(),"percentRadius",new E.bAo(),"majorTicksCount",new E.bAp(),"justify",new E.bAq()])},$,"a3A","$get$a3A",function(){var z=P.U()
z.p(0,N.ep())
z.p(0,$.$get$a3z())
return z},$,"a3B","$get$a3B",function(){return P.m(["scaleType",new E.bAr(),"ticksPlacement",new E.bAs(),"offsetLeft",new E.bAt(),"offsetRight",new E.bAu(),"majorTickStroke",new E.bAv(),"majorTickStrokeWidth",new E.bAw(),"minorTickStroke",new E.bAy(),"minorTickStrokeWidth",new E.bAz(),"angleFrom",new E.bAA(),"angleTo",new E.bAB(),"percentOriginX",new E.bAC(),"percentOriginY",new E.bAD(),"percentRadius",new E.bAE(),"majorTicksCount",new E.bAF(),"majorTicksPercentLength",new E.bAG(),"minorTicksCount",new E.bAH(),"minorTicksPercentLength",new E.bAJ(),"cutOffAngle",new E.bAK()])},$,"a3C","$get$a3C",function(){var z=P.U()
z.p(0,N.ep())
z.p(0,$.$get$a3B())
return z},$,"a3D","$get$a3D",function(){return P.m(["scaleType",new E.bzN(),"offsetLeft",new E.bzR(),"offsetRight",new E.bzS(),"percentStartThickness",new E.bzT(),"percentEndThickness",new E.bzU(),"placement",new E.bzV(),"gradient",new E.bzW(),"angleFrom",new E.bzX(),"angleTo",new E.bzY(),"percentOriginX",new E.bzZ(),"percentOriginY",new E.bA_(),"percentRadius",new E.bA1()])},$,"a3E","$get$a3E",function(){var z=P.U()
z.p(0,N.ep())
z.p(0,$.$get$a3D())
return z},$])}
$dart_deferred_initializers$["lxt0FUhmBrEf8gOphpfR0fhcxRY="]=$dart_deferred_initializers$.current

//# sourceMappingURL=main.dart.js_2.part.js.map
