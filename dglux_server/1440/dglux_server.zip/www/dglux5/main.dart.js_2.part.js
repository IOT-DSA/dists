self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,D,{"^":"",
aVz:function(){var z=document
z=z.createElement("div")
z=new D.JG(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.rz()
z.ang()
return z},
ast:{"^":"On;",
su4:["aLa",function(a){if(!J.a(this.k4,a)){this.k4=a
this.ds()}}],
sMk:function(a){if(!J.a(this.r1,a)){this.r1=a
this.ds()}},
sSU:function(a){if(!J.a(this.r2,a)){this.r2=a
this.ds()}},
sMl:function(a){if(!J.a(this.rx,a)){this.rx=a
this.ds()}},
sMm:function(a){if(!J.a(this.ry,a)){this.ry=a
this.ds()}},
sMo:function(a){if(!J.a(this.x1,a)){this.x1=a
this.ds()}},
sMn:function(a){if(!J.a(this.x2,a)){this.x2=a
this.ds()}},
sbbF:function(a){if(!J.a(this.y1,a)){if(J.x(a,180))a=180
this.y1=J.Q(a,-180)?-180:a
this.ds()}},
sbbE:function(a){if(J.a(this.y2,a))return
this.y2=a
this.ds()},
gjN:function(a){return this.A},
sjN:function(a,b){if(b==null)b=0
if(!J.a(this.A,b)){this.A=b
this.ds()}},
gkE:function(a){return this.S},
skE:function(a,b){if(b==null)b=100
if(!J.a(this.S,b)){this.S=b
this.ds()}},
sbjK:function(a){if(this.J!==a){this.J=a
this.ds()}},
gxY:function(a){return this.a2},
sxY:function(a,b){if(b==null||J.Q(b,0))b=0
if(J.x(b,4))b=4
if(!J.a(this.a2,b)){this.a2=b
this.ds()}},
saJe:function(a){if(this.P!==a){this.P=a
this.ds()}},
szi:function(a){this.a5=a
this.ds()},
gtp:function(){return this.R},
stp:function(a){if(!J.a(this.R,a)){this.R=a
this.ds()}},
sbbp:function(a){if(!J.a(this.V,a)){this.V=a
this.ds()}},
gwy:function(a){return this.K},
swy:["alH",function(a,b){if(!J.a(this.K,b))this.K=b}],
sMK:["alI",function(a){if(!J.a(this.ae,a))this.ae=a}],
sadV:function(a){this.alK(a)
this.ds()},
jQ:function(a,b){this.K6(a,b)
this.Ua()
if(J.a(this.R,"circular"))this.bk_(a,b)
else this.bk0(a,b)},
Ua:function(){var z,y,x,w,v
z=this.P
y=this.k2
if(z){y.seU(0,2)
z=this.k2.f
if(0>=z.length)return H.e(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isds)z.sc_(x,this.aav(this.A,this.a2))
J.a6(J.b9(x.gb0()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.e(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isds)z.sc_(x,this.aav(this.S,this.a2))
J.a6(J.b9(x.gb0()),"text-decoration",this.x1)}else{y.seU(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.e(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isds){y=this.A
w=J.k(y,J.B(J.L(J.p(this.S,y),J.p(this.fy,1)),v))
z.sc_(x,this.aav(w,this.a2))}J.a6(J.b9(x.gb0()),"text-decoration",this.x1);++v}}this.ft(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",H.b(this.r2)+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.b(this.x2)+"px")},
bk_:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.L(J.p(this.fr,this.dy),z-1)
x=P.aA(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.L(a,2)
x=P.aA(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.p(w,x*(50-u)/100)
u=J.L(b,2)
x=P.aA(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.p(u,x*(50-w)/100)
r=C.c.B(this.J,"%")&&!0
x=this.J
if(r){H.cu("")
x=H.ec(x,"%","")}q=P.dN(x,null)
for(x=J.az(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.e(w,p)
o=w[p]
w=J.k(J.p(this.dy,90),x.bD(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.Oq(o)
w=m.b
u=J.F(w)
if(u.bz(w,0)){if(r){l=P.aA(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.L(l,w)}else k=0
l=m.a
j=J.az(l)
i=J.k(j.bD(l,l),u.bD(w,w))
if(typeof i!=="number")H.ab(H.bp(i))
i=Math.sqrt(i)
h=J.B(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.V){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.B(j.dQ(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.B(u.dQ(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a6(J.b9(o.gb0()),"transform","")
i=J.n(o)
if(!!i.$isd8)i.jy(o,d,c)
else N.fw(o.gb0(),d,c)
i=J.b9(o.gb0())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," scale ("+H.b(k)+")"))
if(!J.a(this.y1,0))if(!!J.n(o.gb0()).$isnW){i=J.b9(o.gb0())
h=J.H(i)
h.l(i,"transform",J.k(h.h(i,"transform")," rotate("+H.b(this.y1)+" "+H.b(j.dQ(l,2))+" "+H.b(J.L(u.fE(w),2))+")"))}else{J.hS(J.J(o.gb0())," rotate("+H.b(this.y1)+"deg)")
J.pm(J.J(o.gb0()),H.b(J.B(j.dQ(l,2),k))+" "+H.b(J.B(u.dQ(w,2),k)))}}},
bk0:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.L(J.p(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.e(x,0)
w=this.Oq(x[0])
v=C.c.B(this.J,"%")&&!0
x=this.J
if(v){H.cu("")
x=H.ec(x,"%","")}u=P.dN(x,null)
x=w.b
t=J.F(x)
if(t.bz(x,0))s=J.L(v?J.L(J.B(a,u),200):u,x)
else s=0
r=J.L(J.B(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ai(r)))
p=Math.abs(Math.sin(H.ai(r)))
this.alH(this,J.B(J.L(J.k(J.B(w.a,q),t.bD(x,p)),2),s))
this.a2s()
x=this.k2.f
if(y<0||y>=x.length)return H.e(x,y)
w=this.Oq(x[y])
x=w.b
t=J.F(x)
if(t.bz(x,0))s=J.L(v?J.L(J.B(a,u),200):u,x)
else s=0
this.alI(J.B(J.L(J.k(J.B(w.a,q),t.bD(x,p)),2),s))
this.a2s()
if(!J.a(this.y1,0)){for(x=J.az(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.e(t,n)
w=this.Oq(t[n])
t=w.b
m=J.F(t)
if(m.bz(t,0))J.L(v?J.L(x.bD(a,u),200):u,t)
o=P.aG(J.k(J.B(w.a,p),m.bD(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.F(a)
k=J.L(J.p(x.E(a,this.K),this.ae),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.e(y,n)
j=y[n]
y=this.K
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.k(y,t)
w=this.Oq(j)
y=w.b
m=J.F(y)
if(m.bz(y,0))s=J.L(v?J.L(x.bD(a,u),200):u,y)
else s=0
h=w.a
g=J.F(h)
i=J.p(i,J.B(g.dQ(h,2),s))
J.a6(J.b9(j.gb0()),"transform","")
if(J.a(this.y1,0)){y=J.B(J.k(g.bD(h,p),m.bD(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.n(j)
if(!!y.$isd8)y.jy(j,i,f)
else N.fw(j.gb0(),i,f)
y=J.b9(j.gb0())
t=J.H(y)
t.l(y,"transform",J.k(t.h(y,"transform")," scale ("+H.b(s)+")"))}else{i=J.p(J.k(this.K,t),g.dQ(h,2))
t=J.k(g.bD(h,p),m.bD(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.n(j)
if(!!t.$isd8)t.jy(j,i,e)
else N.fw(j.gb0(),i,e)
d=g.dQ(h,2)
c=-y/2
y=J.b9(j.gb0())
t=J.H(y)
m=s-1
t.l(y,"transform",J.k(t.h(y,"transform")," translate("+H.b(J.B(J.bI(d),m))+" "+H.b(-c*m)+")"))
m=J.b9(j.gb0())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," scale ("+H.b(s)+")"))
m=J.b9(j.gb0())
y=J.H(m)
y.l(m,"transform",J.k(y.h(m,"transform")," rotate("+H.b(this.y1)+" "+H.b(d)+" "+H.b(c)+")"))}}},
Oq:function(a){var z,y,x,w
if(!!J.n(a.gb0()).$isf5){z=H.j(a.gb0(),"$isf5").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.bD()
w=x*0.7}else{y=J.da(a.gb0())
y.toString
w=J.d0(a.gb0())
w.toString}return H.d(new P.G(y,w),[null])},
aaI:[function(){return D.Gk()},"$0","gxv",0,0,3],
aav:function(a,b){var z=this.a5
if(z==null||J.a(z,""))return O.qe(a,"0",null,null)
else return O.qe(a,this.a5,null,null)},
W:[function(){this.alK(0)
this.ds()
var z=this.k2
z.d=!0
z.r=!0
z.seU(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gdu",0,0,0],
aPn:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.w(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new D.oH(this.gxv(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
On:{"^":"mB;",
ga62:function(){return this.cy},
sa0p:["aLe",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.x(a,100))a=100
if(!J.a(this.db,a)){this.db=a
this.ds()}}],
sa0q:["aLf",function(a){if(a==null)a=50
if(J.Q(a,0))a=0
if(J.x(a,100))a=100
if(!J.a(this.dx,a)){this.dx=a
this.ds()}}],
sY7:["aLb",function(a){if(J.Q(a,-360))a=-360
if(J.x(a,360))a=360
if(!J.a(this.dy,a)){this.dy=a
this.eC()
this.ds()}}],
sas4:["aLc",function(a,b){if(J.Q(b,-360))b=-360
if(J.x(b,360))b=360
if(!J.a(this.fr,b)){this.fr=b
this.eC()
this.ds()}}],
sbdn:function(a){if(a==null||J.Q(a,0))a=0
if(J.x(a,20))a=20
if(!J.a(this.fx,a)){this.fx=a
this.ds()}},
sadV:["alK",function(a){if(a==null||J.Q(a,2))a=2
if(J.x(a,30))a=30
if(!J.a(this.fy,a)){this.fy=a
this.ds()}}],
sbdo:function(a){if(this.go!==a){this.go=a
this.ds()}},
sbcP:function(a){if(this.id!==a){this.id=a
this.ds()}},
sa0r:["aLg",function(a){if(a==null||J.Q(a,0))a=0
if(J.x(a,200))a=200
if(!J.a(this.k1,a)){this.k1=a
this.ds()}}],
gl9:function(){return this.cy},
fP:["aLd",function(a,b,c,d){R.qM(a,b,c,d)}],
ft:["alJ",function(a,b){R.vK(a,b)}],
DN:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.h(a)
if(y!=="")J.a6(z.gfK(a),"d",y)
else J.a6(z.gfK(a),"d","M 0,0")}},
asu:{"^":"On;",
sadU:["aLh",function(a){if(!J.a(this.k4,a)){this.k4=a
this.ds()}}],
sbcO:function(a){if(!J.a(this.r2,a)){this.r2=a
this.ds()}},
su7:["aLi",function(a){if(!J.a(this.rx,a)){this.rx=a
this.ds()}}],
saec:function(a){if(!J.a(this.ry,a)){this.ry=a
this.ds()}},
sME:function(a){if(!J.a(this.x1,a)){this.x1=a
this.ds()}},
gtp:function(){return this.x2},
stp:function(a){if(!J.a(this.x2,a)){this.x2=a
this.ds()}},
gwy:function(a){return this.y1},
swy:function(a,b){if(!J.a(this.y1,b)){this.y1=b
this.ds()}},
sMK:function(a){if(!J.a(this.y2,a)){this.y2=a
this.ds()}},
sbmJ:function(a){if(!J.a(this.w,a)){this.w=a
this.ds()}},
sb3o:function(a){var z
if(!J.a(this.A,a)){this.A=a
if(a!=null){z=J.p(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.S=z
this.ds()}},
jQ:function(a,b){var z,y
this.K6(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.fP(this.k2,this.k4,J.aR(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.fP(this.k3,this.rx,J.aR(this.x1),this.ry)
if(J.a(this.x2,"circular"))this.b5I(a,b)
else this.b5J(a,b)},
b5I:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.L(J.p(this.fr,this.dy),J.p(J.k(J.B(this.fx,J.p(this.fy,1)),this.fy),1))
x=C.c.B(this.go,"%")&&!0
w=this.go
if(x){H.cu("")
w=H.ec(w,"%","")}v=P.dN(w,null)
if(x){w=P.aA(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.aA(a,b)
w=J.L(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.p(w,t*(50-s)/100)
s=J.L(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.p(s,t*(50-w)/100)
w=P.aA(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.a(this.w,"center"))o=0.5
else o=J.a(this.w,"outside")?1:0
w=o-1
s=J.az(y)
n=0
while(!0){m=J.k(J.B(this.fx,J.p(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.k(J.p(this.dy,90),s.bD(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.S
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++n}this.DN(this.k3)
z.a=""
y=J.L(J.p(this.fr,this.dy),J.p(this.fy,1))
h=C.c.B(this.id,"%")&&!0
s=this.id
if(h){H.cu("")
s=H.ec(s,"%","")}g=P.dN(s,null)
if(h){s=P.aA(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.az(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.k(J.p(this.dy,90),s.bD(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.S
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++f}this.DN(this.k2)},
b5J:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.c.B(this.go,"%")&&!0
y=this.go
if(z){H.cu("")
y=H.ec(y,"%","")}x=P.dN(y,null)
w=z?J.L(J.B(J.L(a,2),x),100):x
v=C.c.B(this.id,"%")&&!0
y=this.id
if(v){H.cu("")
y=H.ec(y,"%","")}u=P.dN(y,null)
t=v?J.L(J.B(J.L(a,2),u),100):u
y=this.cx
y.a=""
s=J.F(a)
r=J.L(J.p(s.E(a,this.y1),this.y2),J.p(J.k(J.B(this.fx,J.p(this.fy,1)),this.fy),1))
if(J.a(this.w,"center"))q=0.5
else q=J.a(this.w,"outside")?1:0
p=J.F(t)
o=p.E(t,w)
n=1-q
m=0
while(!0){l=J.k(J.B(this.fx,J.p(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.E(t,q*o)
y.a+="M "+H.b(k)+","+H.b(n*o)+" "
y.a+="L "+H.b(k)+","+H.b(j)+" ";++m}this.DN(this.k3)
y.a=""
r=J.L(J.p(s.E(a,this.y1),this.y2),J.p(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.b(k)+",0 "
y.a+="L "+H.b(k)+","+H.b(t)+" ";++i}this.DN(this.k2)},
W:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.DN(z)
this.DN(this.k3)}},"$0","gdu",0,0,0]},
asv:{"^":"On;",
sa0p:function(a){this.aLe(a)
this.r2=!0},
sa0q:function(a){this.aLf(a)
this.r2=!0},
sY7:function(a){this.aLb(a)
this.r2=!0},
sas4:function(a,b){this.aLc(this,b)
this.r2=!0},
sa0r:function(a){this.aLg(a)
this.r2=!0},
sbjJ:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.ds()}},
sbjI:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.ds()}},
sajL:function(a){if(this.x2!==a){this.x2=a
this.eC()
this.ds()}},
gk7:function(){return this.y1},
sk7:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.a(this.y1,a)){this.y1=a
this.r2=!0
this.ds()}},
gtp:function(){return this.y2},
stp:function(a){if(!J.a(this.y2,a)){this.y2=a
this.r2=!0
this.ds()}},
gwy:function(a){return this.w},
swy:function(a,b){if(!J.a(this.w,b)){this.w=b
this.r2=!0
this.ds()}},
sMK:function(a){if(!J.a(this.A,a)){this.A=a
this.r2=!0
this.ds()}},
kz:function(a){var z,y,x,w,v,u,t,s,r
this.Dh(this)
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.K)(z),++u){t=z[u]
s=J.h(t)
y.push(s.ghU(t))
x.push(s.gDM(t))
w.push(s.gvm(t))}if(J.ch(J.p(this.dy,this.fr))===!0){z=J.aX(J.p(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.f.U(0.5*z)}else r=0
this.k2=this.b27(y,w,r)
this.k3=this.b_5(x,w,r)
this.r2=!0},
jQ:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.K6(a,b)
z=J.az(a)
y=J.az(b)
N.Jv(this.k4,z.bD(a,1),y.bD(b,1))
if(J.a(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.aA(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.a(this.y2,"circular")){z=P.aG(0,P.aA(a,b))
this.rx=z
this.b5L(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.b(this.rx)+" "+H.b(this.rx))}else{z=J.B(J.p(z.E(a,this.w),this.A),1)
y.bD(b,1)
v=C.c.B(this.ry,"%")&&!0
y=this.ry
if(v){H.cu("")
y=H.ec(y,"%","")}u=P.dN(y,null)
t=v?J.L(J.B(z,u),100):u
s=C.c.B(this.x1,"%")&&!0
y=this.x1
if(s){H.cu("")
y=H.ec(y,"%","")}r=P.dN(y,null)
q=s?J.L(J.B(z,r),100):r
this.r1.seU(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.p(q,t)
p=q
o=p
m=0
break
case"cross":y=J.F(q)
x=J.F(t)
o=J.k(y.dQ(q,2),x.dQ(t,2))
n=J.p(y.dQ(q,2),x.dQ(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.d(new P.G(this.w,o),[null])
k=H.d(new P.G(this.w,n),[null])
j=H.d(new P.G(J.k(this.w,z),p),[null])
i=H.d(new P.G(J.k(this.w,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.e(y,0)
h=y[0]
this.ft(h.gb0(),this.J)
R.qM(h.gb0(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.b(y)+","+H.b(x)+" "
z.a+="L "+H.b(j.a)+","+H.b(j.b)+" "
z.a+="L "+H.b(i.a)+","+H.b(i.b)+" "
z.a+="L "+H.b(k.a)+","+H.b(k.b)+" "
z.a+="L "+H.b(y)+","+H.b(x)+" "
this.DN(h.gb0())
x=this.cy
x.toString
new W.dZ(x).M(0,"viewBox")}},
b27:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.li(J.B(J.p(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.e(a,y)
t=J.a_(J.ca(a[y],16),255)
if(y>=a.length)return H.e(a,y)
s=J.a_(J.ca(a[y],8),255)
if(y>=a.length)return H.e(a,y)
r=J.a_(a[y],255)
if(x>=a.length)return H.e(a,x)
q=J.a_(J.ca(a[x],16),255)
if(x>=a.length)return H.e(a,x)
p=J.a_(J.ca(a[x],8),255)
if(x>=a.length)return H.e(a,x)
o=J.a_(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.b.U(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.b.U(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.b.U(w*r+m*o)&255)>>>0)}}return z},
b_5:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.li(J.B(J.p(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.e(a,x)
v=a[x]
if(y>=w)return H.e(a,y)
t=J.L(J.p(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.e(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.k(w,s*t))}}return z},
b5L:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.aA(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.c.B(this.ry,"%")&&!0
z=this.ry
if(v){H.cu("")
z=H.ec(z,"%","")}u=P.dN(z,new D.asw())
if(v){z=P.aA(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.c.B(this.x1,"%")&&!0
z=this.x1
if(s){H.cu("")
z=H.ec(z,"%","")}r=P.dN(z,new D.asx())
if(s){z=P.aA(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.aA(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.aA(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.seU(0,w)
for(z=J.F(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.p(this.dy,90)
d=J.p(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.k(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.E(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.e(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.e(e,d)
g=J.aV(J.B(e[d],255))
g=J.bf(J.a(g,0)?1:g,24)
e=h.gb0()
a3=this.k2
if(d>=a3.length)return H.e(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.ft(e,a3+g)
a3=h.gb0()
e=this.k2
if(d>=e.length)return H.e(e,d)
R.qM(a3,e[d]+g,1,"solid")
y.a+="M "+H.b(l)+","+H.b(k)+" "
y.a+="L "+H.b(a)+","+H.b(a0)+" "
y.a+="L "+H.b(a1)+","+H.b(a2)+" "
y.a+="L "+H.b(j)+","+H.b(i)+" "
y.a+="L "+H.b(l)+","+H.b(k)+" "
this.DN(h.gb0())}}},
bDD:[function(){var z,y
z=new D.acX(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gbjz",0,0,3],
W:["aLj",function(){var z=this.r1
z.d=!0
z.r=!0
z.seU(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gdu",0,0,0],
aPo:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.sajL([new D.zD(65280,0.5,0),new D.zD(16776960,0.8,0.5),new D.zD(16711680,1,1)])
z=new D.oH(this.gbjz(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
asw:{"^":"c:0;",
$1:function(a){return 0}},
asx:{"^":"c:0;",
$1:function(a){return 0}},
zD:{"^":"t;hU:a*,DM:b>,vm:c>"}}],["","",,E,{"^":"",
c3Y:[function(a){var z=!!J.n(a.gmC().gb0()).$ishk?H.j(a.gmC().gb0(),"$ishk"):null
if(z!=null)if(z.gpE()!=null&&!J.a(z.gpE(),""))return E.a_C(a.gmC(),z.gpE())
else return z.M_(a)
return""},"$1","bW1",2,0,9,56],
bST:function(){if($.Wt)return
$.Wt=!0
$.$get$iv().l(0,"percentTextSize",E.bW6())
$.$get$iv().l(0,"minorTicksPercentLength",E.akO())
$.$get$iv().l(0,"majorTicksPercentLength",E.akO())
$.$get$iv().l(0,"percentStartThickness",E.akQ())
$.$get$iv().l(0,"percentEndThickness",E.akQ())
$.$get$iw().l(0,"percentTextSize",E.bW7())
$.$get$iw().l(0,"minorTicksPercentLength",E.akP())
$.$get$iw().l(0,"majorTicksPercentLength",E.akP())
$.$get$iw().l(0,"percentStartThickness",E.akR())
$.$get$iw().l(0,"percentEndThickness",E.akR())},
bkg:function(a){var z
switch(a){case"chart":z=[]
C.a.p(z,$.$get$e8())
C.a.p(z,$.$get$GB())
return z
case"scaleTicks":z=[]
C.a.p(z,$.$get$e8())
C.a.p(z,$.$get$HL())
return z
case"scaleLabels":z=[]
C.a.p(z,$.$get$e8())
C.a.p(z,$.$get$HJ())
return z
case"scaleTrack":z=[]
C.a.p(z,$.$get$e8())
C.a.p(z,$.$get$Qz())
return z
case"linearAxis":return $.$get$yj()
case"logAxis":return $.$get$ym()
case"categoryAxis":return $.$get$vy()
case"datetimeAxis":return $.$get$y5()
case"axisRenderer":return $.$get$vr()
case"radialAxisRenderer":return $.$get$Qs()
case"angularAxisRenderer":return $.$get$Oy()
case"linearAxisRenderer":return $.$get$vr()
case"logAxisRenderer":return $.$get$vr()
case"categoryAxisRenderer":return $.$get$vr()
case"datetimeAxisRenderer":return $.$get$vr()
case"lineSeries":return $.$get$yh()
case"areaSeries":return $.$get$Gh()
case"columnSeries":return $.$get$GD()
case"barSeries":return $.$get$Go()
case"bubbleSeries":return $.$get$Gv()
case"pieSeries":return $.$get$BZ()
case"spectrumSeries":return $.$get$QO()
case"radarSeries":return $.$get$C2()
case"lineSet":return $.$get$tx()
case"areaSet":return $.$get$Gj()
case"columnSet":return $.$get$GF()
case"barSet":return $.$get$Gq()
case"gridlines":return $.$get$Py()}return[]},
bke:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof E.ok)return a
else{z=$.$get$a18()
y=H.d([],[D.eC])
x=H.d([],[N.k1])
w=H.d([],[E.j5])
v=H.d([],[N.k1])
u=H.d([],[E.j5])
t=H.d([],[N.k1])
s=H.d([],[E.Bl])
r=H.d([],[N.k1])
q=H.d([],[E.C3])
p=H.d([],[N.k1])
o=$.$get$ap()
n=$.T+1
$.T=n
n=new E.ok(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,null,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
n.cc(b,"chart")
J.V(J.w(n.b),"absolute")
o=E.av0()
n.v=o
J.bC(n.b,o.cx)
o=n.v
o.bj=n
o.UE()
o=E.arI()
n.C=o
o.sdn(n.v)
return n}case"scaleTicks":if(a instanceof E.HK)return a
else{z=$.$get$a4E()
y=$.$get$ap()
x=$.T+1
$.T=x
x=new E.HK(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-ticks")
J.V(J.w(x.b),"absolute")
z=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.t,N.cd])),[P.t,N.cd])
z=new E.avf(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.cy(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.cy=P.iC()
x.v=z
J.bC(x.b,z.ga62())
return x}case"scaleLabels":if(a instanceof E.HI)return a
else{z=$.$get$a4C()
y=$.$get$ap()
x=$.T+1
$.T=x
x=new E.HI(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-labels")
J.V(J.w(x.b),"absolute")
z=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.t,N.cd])),[P.t,N.cd])
z=new E.avd(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.cy(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.cy=P.iC()
z.aPn()
x.v=z
J.bC(x.b,z.ga62())
x.v.sec(x)
return x}case"scaleTrack":if(a instanceof E.HM)return a
else{z=$.$get$a4G()
y=$.$get$ap()
x=$.T+1
$.T=x
x=new E.HM(z,null,!1,null,null,null,null,null,null,-1,-1,null,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,-1,1,null,null,0,0,null,null,!1,"","",!1,!1,null,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],-1,-1,!1,!1,null,null,null,4.3,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,"","",!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,!1,"","",!1,"","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$aq(),!1,null,null,null,null,null,null,!1,!1,null,null,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a8(null,null,null,P.O),0,null,null,null,null,null,null,null,!1,null,null,null,null)
x.cc(b,"scale-track")
J.V(J.w(x.b),"absolute")
J.lj(J.J(x.b),"hidden")
y=E.avh()
x.v=y
J.bC(x.b,y.ga62())
return x}}return},
c4t:[function(){var z=new E.awq(null,null,null)
z.an4()
return z},"$0","bW2",0,0,3],
av0:function(){var z,y,x,w,v,u,t
z=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.t,N.cd])),[P.t,N.cd])
y=P.bl(0,0,0,0,null)
x=P.bl(0,0,0,0,null)
w=new D.d7(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.d([],[P.fm])
t=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.v,P.t])),[P.v,P.t])
z=new E.oj(z,null,"none",!1,!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",D.bVC(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.aPm("chartBase")
z.aPk()
z.aQ5()
z.sZf("single")
z.aPz()
return z},
cbq:[function(a,b,c){return E.biP(a,c)},"$3","bW6",6,0,1,17,30,1],
biP:function(a,b){var z,y,x
z=a.F("view")
if(z==null)return
y=J.d6(z)
if(y==null)return
x=J.h(y)
return J.L(J.B(J.a(y.gtp(),"circular")?P.aA(x.gbF(y),x.gco(y)):x.gbF(y),b),200)},
cbr:[function(a,b,c){return E.biQ(a,c)},"$3","bW7",6,0,1,17,30,1],
biQ:function(a,b){var z,y,x,w
z=a.F("view")
if(z==null)return
y=J.d6(z)
if(y==null)return
x=J.B(b,200)
w=J.h(y)
return J.L(x,J.a(y.gtp(),"circular")?P.aA(w.gbF(y),w.gco(y)):w.gbF(y))},
cbs:[function(a,b,c){return E.biR(a,c)},"$3","akO",6,0,1,17,30,1],
biR:function(a,b){var z,y,x
z=a.F("view")
if(z==null)return
y=J.d6(z)
if(y==null)return
x=J.h(y)
return J.L(J.B(J.a(y.gtp(),"circular")?P.aA(x.gbF(y),x.gco(y)):x.gbF(y),b),200)},
cbt:[function(a,b,c){return E.biS(a,c)},"$3","akP",6,0,1,17,30,1],
biS:function(a,b){var z,y,x,w
z=a.F("view")
if(z==null)return
y=J.d6(z)
if(y==null)return
x=J.B(b,200)
w=J.h(y)
return J.L(x,J.a(y.gtp(),"circular")?P.aA(w.gbF(y),w.gco(y)):w.gbF(y))},
cbu:[function(a,b,c){return E.biT(a,c)},"$3","akQ",6,0,1,17,30,1],
biT:function(a,b){var z,y,x
z=a.F("view")
if(z==null)return
y=J.d6(z)
if(y==null)return
x=J.h(y)
if(J.a(y.gtp(),"circular")){x=P.aA(x.gbF(y),x.gco(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.L(J.B(x.gbF(y),b),100)
return x},
cbv:[function(a,b,c){return E.biU(a,c)},"$3","akR",6,0,1,17,30,1],
biU:function(a,b){var z,y,x,w
z=a.F("view")
if(z==null)return
y=J.d6(z)
if(y==null)return
x=J.az(b)
w=J.h(y)
return J.a(y.gtp(),"circular")?J.L(x.bD(b,200),P.aA(w.gbF(y),w.gco(y))):J.L(x.bD(b,100),w.gbF(y))},
awq:{"^":"Rg;a,b,c",
sc_:function(a,b){var z,y,x,w,v
if(J.a(this.b,b))return
this.aMb(this,b)
if(b instanceof D.m6){z=b.e
if(z.gb0() instanceof D.eC&&H.j(z.gb0(),"$iseC").w!=null){J.AJ(J.J(this.a),"")
return}y=U.c5(b.r,"fault")
if(y==="fault"&&b.r instanceof V.u){x=b.r
if(J.a(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof V.eT&&J.x(w.x1,0)){z=H.j(w.dq(0),"$iskd")
y=U.e_(z.ghU(z),null,"rgba(0,0,0,0)")}}}v=H.b(y==="fault"?U.e_(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.AJ(J.J(this.a),v)}},
akk:function(a){J.b2(this.a,a,$.$get$aw())}},
avd:{"^":"ast;aa,ab,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,S,J,a2,P,a5,a3,R,V,K,ae,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
su4:function(a){var z=this.k4
if(z instanceof V.u)H.j(z,"$isu").dr(this.geq())
this.aLa(a)
if(a instanceof V.u)a.dN(this.geq())},
swy:function(a,b){this.alH(this,b)
this.a2s()},
sMK:function(a){this.alI(a)
this.a2s()},
gec:function(){return this.ab},
sec:function(a){H.j(a,"$isaU")
this.ab=a
if(a!=null)V.bc(this.gboH())},
ft:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.alJ(a,b)
return}if(!!J.n(a).$isbi){z=this.aa.a
if(!z.X(0,a))z.l(0,a,new N.cd(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kI(b)}},
rm:[function(a){this.ds()},"$1","geq",2,0,2,9],
a2s:[function(){var z=this.ab
if(z!=null)if(z.a instanceof V.u)V.W(new E.ave(this))},"$0","gboH",0,0,0]},
ave:{"^":"c:3;a",
$0:[function(){var z=this.a
z.ab.a.bk("offsetLeft",z.K)
z.ab.a.bk("offsetRight",z.ae)},null,null,0,0,null,"call"]},
HI:{"^":"aTM;aI,fv:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cd,cg,ca,cp,cu,cD,cE,bW,cO,cX,cq,cB,cJ,c0,cr,cz,cG,cF,cH,cK,cQ,cL,cY,cv,cR,cP,cC,cS,ck,bN,cn,cM,cU,cV,cI,c7,cW,df,dg,d0,d2,dh,d1,cT,d3,d4,da,cw,d5,d6,cN,d7,dc,dd,cZ,d8,d_,cs,de,d9,P,a5,a3,R,V,K,ae,aa,ab,ad,aq,ac,ak,af,an,aA,aK,ag,aY,aD,aG,ar,ay,aS,aW,aC,aU,bc,aN,b7,bl,bm,aT,bn,be,bd,bu,bh,bC,bH,bA,bg,bw,b4,bx,bo,by,bJ,ci,c1,bT,bK,bL,c8,bU,bZ,bV,bX,bE,bv,bj,c6,cm,c4,bM,c2,cf,y2,w,A,S,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdV:function(){return this.aI},
sf9:function(a,b){if(J.a(this.aa,"none")&&!J.a(b,"none")){this.mU(this,b)
this.eA()}else this.mU(this,b)},
h1:[function(a,b){this.mV(this,b)
this.shD(!0)},"$1","gfd",2,0,2,9],
k5:[function(a){this.ut()},"$0","gis",0,0,0],
W:[function(){this.shD(!1)
this.fR()
this.v.sMw(!0)
this.v.W()
this.v.su4(null)
this.v.sMw(!1)},"$0","gdu",0,0,0],
il:[function(){this.shD(!1)
this.fR()},"$0","gkC",0,0,0],
hd:function(){this.x4()
this.shD(!0)},
ut:function(){if(this.a instanceof V.u)this.v.jl(J.da(this.b),J.d0(this.b))},
eA:function(){var z,y
this.Dk()
this.soH(-1)
z=this.v
y=J.h(z)
y.sbF(z,J.p(y.gbF(z),1))},
$isbL:1,
$isbN:1,
$isct:1},
aTM:{"^":"aU+lB;oH:x$?,u5:y$?",$isct:1},
bCv:{"^":"c:42;",
$2:[function(a,b){J.d6(a).stp(U.ar(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bCw:{"^":"c:42;",
$2:[function(a,b){J.Np(J.d6(a),U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCx:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sMK(U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCy:{"^":"c:42;",
$2:[function(a,b){J.xA(J.d6(a),U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCz:{"^":"c:42;",
$2:[function(a,b){J.xz(J.d6(a),U.b1(b,100))},null,null,4,0,null,0,2,"call"]},
bCA:{"^":"c:42;",
$2:[function(a,b){J.d6(a).szi(U.E(b,""))},null,null,4,0,null,0,2,"call"]},
bCB:{"^":"c:42;",
$2:[function(a,b){J.d6(a).saJe(U.R(b,!1))},null,null,4,0,null,0,2,"call"]},
bCC:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sbjK(U.kq(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
bCD:{"^":"c:42;",
$2:[function(a,b){J.d6(a).su4(R.cZ(b,16777215))},null,null,4,0,null,0,2,"call"]},
bCE:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sMk($.hI.$3(a.gG(),b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
bCG:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sMl(U.ar(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bCH:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sMm(U.ar(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bCI:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sMo(U.ar(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
bCJ:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sMn(U.ah(b,0))},null,null,4,0,null,0,2,"call"]},
bCK:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sbbF(U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCL:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sbbE(U.ar(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
bCM:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sY7(U.b1(b,-120))},null,null,4,0,null,0,2,"call"]},
bCN:{"^":"c:42;",
$2:[function(a,b){J.N9(J.d6(a),U.b1(b,120))},null,null,4,0,null,0,2,"call"]},
bCO:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sa0p(U.b1(b,50))},null,null,4,0,null,0,2,"call"]},
bCP:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sa0q(U.b1(b,50))},null,null,4,0,null,0,2,"call"]},
bCR:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sa0r(U.b1(b,90))},null,null,4,0,null,0,2,"call"]},
bCS:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sadV(U.ah(b,11))},null,null,4,0,null,0,2,"call"]},
bCT:{"^":"c:42;",
$2:[function(a,b){J.d6(a).sbbp(U.ar(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
avf:{"^":"asu;J,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,S,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
su7:function(a){var z=this.rx
if(z instanceof V.u)H.j(z,"$isu").dr(this.geq())
this.aLi(a)
if(a instanceof V.u)a.dN(this.geq())},
sadU:function(a){var z=this.k4
if(z instanceof V.u)H.j(z,"$isu").dr(this.geq())
this.aLh(a)
if(a instanceof V.u)a.dN(this.geq())},
fP:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.J.a
if(z.X(0,a))z.h(0,a).kR(null)
this.aLd(a,b,c,d)
return}if(!!J.n(a).$isbi){z=this.J.a
if(!z.X(0,a))z.l(0,a,new N.cd(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kR(b)
y.smv(c)
y.sm9(d)}},
rm:[function(a){this.ds()},"$1","geq",2,0,2,9]},
HK:{"^":"aTN;aI,fv:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cd,cg,ca,cp,cu,cD,cE,bW,cO,cX,cq,cB,cJ,c0,cr,cz,cG,cF,cH,cK,cQ,cL,cY,cv,cR,cP,cC,cS,ck,bN,cn,cM,cU,cV,cI,c7,cW,df,dg,d0,d2,dh,d1,cT,d3,d4,da,cw,d5,d6,cN,d7,dc,dd,cZ,d8,d_,cs,de,d9,P,a5,a3,R,V,K,ae,aa,ab,ad,aq,ac,ak,af,an,aA,aK,ag,aY,aD,aG,ar,ay,aS,aW,aC,aU,bc,aN,b7,bl,bm,aT,bn,be,bd,bu,bh,bC,bH,bA,bg,bw,b4,bx,bo,by,bJ,ci,c1,bT,bK,bL,c8,bU,bZ,bV,bX,bE,bv,bj,c6,cm,c4,bM,c2,cf,y2,w,A,S,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdV:function(){return this.aI},
sf9:function(a,b){if(J.a(this.aa,"none")&&!J.a(b,"none")){this.mU(this,b)
this.eA()}else this.mU(this,b)},
h1:[function(a,b){this.mV(this,b)
this.shD(!0)
if(b==null)this.v.jl(J.da(this.b),J.d0(this.b))},"$1","gfd",2,0,2,9],
k5:[function(a){this.v.jl(J.da(this.b),J.d0(this.b))},"$0","gis",0,0,0],
W:[function(){this.shD(!1)
this.fR()
this.v.sMw(!0)
this.v.W()
this.v.su7(null)
this.v.sadU(null)
this.v.sMw(!1)},"$0","gdu",0,0,0],
il:[function(){this.shD(!1)
this.fR()},"$0","gkC",0,0,0],
hd:function(){this.x4()
this.shD(!0)},
eA:function(){var z,y
this.Dk()
this.soH(-1)
z=this.v
y=J.h(z)
y.sbF(z,J.p(y.gbF(z),1))},
ut:function(){this.v.jl(J.da(this.b),J.d0(this.b))},
$isbL:1,
$isbN:1},
aTN:{"^":"aU+lB;oH:x$?,u5:y$?",$isct:1},
bCU:{"^":"c:53;",
$2:[function(a,b){J.d6(a).stp(U.ar(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bCV:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sbmJ(U.ar(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
bCW:{"^":"c:53;",
$2:[function(a,b){J.Np(J.d6(a),U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCX:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sMK(U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCY:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sadU(R.cZ(b,16777215))},null,null,4,0,null,0,2,"call"]},
bCZ:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sbcO(U.ah(b,1))},null,null,4,0,null,0,2,"call"]},
bD_:{"^":"c:53;",
$2:[function(a,b){J.d6(a).su7(R.cZ(b,16777215))},null,null,4,0,null,0,2,"call"]},
bD1:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sME(U.ah(b,1))},null,null,4,0,null,0,2,"call"]},
bD2:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sY7(U.b1(b,-120))},null,null,4,0,null,0,2,"call"]},
bD3:{"^":"c:53;",
$2:[function(a,b){J.N9(J.d6(a),U.b1(b,120))},null,null,4,0,null,0,2,"call"]},
bD4:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sa0p(U.b1(b,50))},null,null,4,0,null,0,2,"call"]},
bD5:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sa0q(U.b1(b,50))},null,null,4,0,null,0,2,"call"]},
bD6:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sa0r(U.b1(b,90))},null,null,4,0,null,0,2,"call"]},
bD7:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sadV(U.ah(b,11))},null,null,4,0,null,0,2,"call"]},
bD8:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sbcP(U.kq(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
bD9:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sbdn(U.ah(b,2))},null,null,4,0,null,0,2,"call"]},
bDa:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sbdo(U.kq(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
bDc:{"^":"c:53;",
$2:[function(a,b){J.d6(a).sb3o(U.b1(b,null))},null,null,4,0,null,0,2,"call"]},
avg:{"^":"asv;S,J,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,w,A,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gka:function(){return this.J},
ska:function(a){var z=this.J
if(z!=null)z.dr(this.gahu())
this.J=a
if(a!=null)a.dN(this.gahu())
if(!this.r)this.bof(null)},
arC:function(a){if(a!=null){a.fY(V.ie(new V.dP(0,255,0,1),0,0))
a.fY(V.ie(new V.dP(0,0,0,1),0,50))}},
bof:[function(a){var z,y,x,w,v,u,t,s,r,q
z=this.J
if(z==null){z=new V.eT(!1,null,H.d([],[V.aF]),0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!1,null,null,-1,null,!1,null,!1,null,!1,0,null,null,null,null,null)
z.bt()
z.aQ(!1,null)
z.ch=null
this.arC(z)}else{y=J.h(z)
x=y.hI(z)
for(w=J.H(x),v=J.p(w.gm(x),1);u=J.F(v),u.dm(v,0);v=u.E(v,1))if(w.h(x,v)==null)y.M(z,v)
if(J.a(J.I(y.hI(z)),0))this.arC(z)}t=J.h1(z)
y=J.b5(t)
y.eO(t,V.rD())
s=[]
if(J.x(y.gm(t),1))for(y=y.gb5(t);y.u();){r=y.gI()
w=J.h(r)
u=w.ghU(r)
q=H.dm(r.i("alpha"))
q.toString
s.push(new D.zD(u,q,J.L(w.gvm(r),100)))}else if(J.a(y.gm(t),1)){r=y.h(t,0)
y=J.h(r)
w=y.ghU(r)
u=H.dm(r.i("alpha"))
u.toString
s.push(new D.zD(w,u,0))
y=y.ghU(r)
u=H.dm(r.i("alpha"))
u.toString
s.push(new D.zD(y,u,1))}this.sajL(s)},"$1","gahu",2,0,6,9],
ft:function(a,b){var z,y,x
if(typeof b==="number"&&Math.floor(b)===b){this.alJ(a,b)
return}if(!!J.n(a).$isbi){z=this.S.a
if(!z.X(0,a))z.l(0,a,new N.cd(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
x=V.d3(!1,null)
x.O("fillType",!0).am("gradient")
x.O("gradient",!0).$2(b,!1)
x.O("gradientType",!0).am("linear")
y.kI(x)
x.W()}},
W:[function(){var z=this.J
if(z!=null&&!J.a(z,$.$get$Bx())){this.J.dr(this.gahu())
this.J=null}this.aLj()},"$0","gdu",0,0,0],
aPA:function(){var z=$.$get$Bx()
if(J.a(z.x1,0)){z.fY(V.ie(new V.dP(0,255,0,1),1,0))
z.fY(V.ie(new V.dP(255,255,0,1),1,50))
z.fY(V.ie(new V.dP(255,0,0,1),1,100))}},
aj:{
avh:function(){var z=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.t,N.cd])),[P.t,N.cd])
z=new E.avg(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.cy(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.cy=P.iC()
z.aPo()
z.aPA()
return z}}},
HM:{"^":"aTO;aI,fv:v*,a$,b$,c$,d$,e$,f$,r$,x$,y$,z$,cd,cg,ca,cp,cu,cD,cE,bW,cO,cX,cq,cB,cJ,c0,cr,cz,cG,cF,cH,cK,cQ,cL,cY,cv,cR,cP,cC,cS,ck,bN,cn,cM,cU,cV,cI,c7,cW,df,dg,d0,d2,dh,d1,cT,d3,d4,da,cw,d5,d6,cN,d7,dc,dd,cZ,d8,d_,cs,de,d9,P,a5,a3,R,V,K,ae,aa,ab,ad,aq,ac,ak,af,an,aA,aK,ag,aY,aD,aG,ar,ay,aS,aW,aC,aU,bc,aN,b7,bl,bm,aT,bn,be,bd,bu,bh,bC,bH,bA,bg,bw,b4,bx,bo,by,bJ,ci,c1,bT,bK,bL,c8,bU,bZ,bV,bX,bE,bv,bj,c6,cm,c4,bM,c2,cf,y2,w,A,S,J,a2,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1",
gdV:function(){return this.aI},
sf9:function(a,b){if(J.a(this.aa,"none")&&!J.a(b,"none")){this.mU(this,b)
this.eA()}else this.mU(this,b)},
h1:[function(a,b){this.mV(this,b)
this.shD(!0)},"$1","gfd",2,0,2,9],
k5:[function(a){this.ut()},"$0","gis",0,0,0],
W:[function(){this.shD(!1)
this.fR()
this.v.sMw(!0)
this.v.W()
this.v.ska(null)
this.v.sMw(!1)},"$0","gdu",0,0,0],
il:[function(){this.shD(!1)
this.fR()},"$0","gkC",0,0,0],
hd:function(){this.x4()
this.shD(!0)},
eA:function(){var z,y
this.Dk()
this.soH(-1)
z=this.v
y=J.h(z)
y.sbF(z,J.p(y.gbF(z),1))},
ut:function(){if(this.a instanceof V.u)this.v.jl(J.da(this.b),J.d0(this.b))},
$isbL:1,
$isbN:1},
aTO:{"^":"aU+lB;oH:x$?,u5:y$?",$isct:1},
bCh:{"^":"c:85;",
$2:[function(a,b){J.d6(a).stp(U.ar(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bCi:{"^":"c:85;",
$2:[function(a,b){J.Np(J.d6(a),U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCk:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sMK(U.b1(b,0))},null,null,4,0,null,0,2,"call"]},
bCl:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sbjJ(U.kq(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
bCm:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sbjI(U.kq(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
bCn:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sk7(U.ar(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
bCo:{"^":"c:85;",
$2:[function(a,b){var z=J.d6(a)
z.ska(b!=null?V.rC(b):$.$get$Bx())},null,null,4,0,null,0,2,"call"]},
bCp:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sY7(U.b1(b,-120))},null,null,4,0,null,0,2,"call"]},
bCq:{"^":"c:85;",
$2:[function(a,b){J.N9(J.d6(a),U.b1(b,120))},null,null,4,0,null,0,2,"call"]},
bCr:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sa0p(U.b1(b,50))},null,null,4,0,null,0,2,"call"]},
bCs:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sa0q(U.b1(b,50))},null,null,4,0,null,0,2,"call"]},
bCt:{"^":"c:85;",
$2:[function(a,b){J.d6(a).sa0r(U.b1(b,90))},null,null,4,0,null,0,2,"call"]},
Bf:{"^":"t;aiD:a@,jN:b*,kE:c*"},
arH:{"^":"mB;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,c,d,e,f,r,x,y,z,Q,ch,a,b",
gtR:function(){return this.r1},
stR:function(a){if(!J.a(this.r1,a)){this.r1=a
this.ds()}},
gdn:function(){return this.r2},
sdn:function(a){this.bkX(a)},
gl9:function(){return this.go},
jQ:function(a,b){var z,y,x,w
this.K6(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.iC()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.b(a)+"px"
z.width=y
z=this.id.style
y=H.b(b)+"px"
z.height=y
this.fP(this.k1,0,0,"none")
this.ft(this.k1,this.r2.cE)
z=this.k2
y=this.r2
this.fP(z,y.cp,J.aR(y.cu),this.r2.cD)
y=this.k3
z=this.r2
this.fP(y,z.cp,J.aR(z.cu),this.r2.cD)
z=this.db
if(z===2){z=J.x(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a1(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aJ(a))
y=this.k1
y.toString
y.setAttribute("height",J.a1(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a1(J.k(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aJ(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.b.aJ(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.b(this.cy.b)+" L "+H.b(a)+","+H.b(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.b(J.k(this.cy.b,this.r1.b))+" L "+H.b(a)+","+H.b(J.k(this.cy.b,this.r1.b)))}else if(z===1){z=J.x(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a1(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a1(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aJ(b))}else{x.toString
x.setAttribute("x",J.a1(J.k(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.b.aJ(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aJ(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.b(this.cy.a)+",0 L "+H.b(this.cy.a)+","+H.b(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.b(J.k(this.cy.a,this.r1.a))+",0 L "+H.b(J.k(this.cy.a,this.r1.a))+","+H.b(b))}else if(z===3){z=J.x(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a1(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a1(this.r1.a))}else{y.toString
y.setAttribute("x",J.a1(J.k(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.b.aJ(0-y))}z=J.x(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a1(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a1(this.r1.b))}else{y.toString
y.setAttribute("y",J.a1(J.k(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.b.aJ(0-y))}z=this.k1
y=this.r2
this.fP(z,y.cp,J.aR(y.cu),this.r2.cD)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
bkX:function(a){var z,y
this.agq()
this.agr()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().D(0)
this.r2.re(0,"CartesianChartZoomerReset",this.gaw8())}this.r2=a
if(a!=null){z=this.fx
y=J.ci(a.cx)
y=H.d(new W.A(0,y.a,y.b,W.z(this.gb0S()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.r2.p7(0,"CartesianChartZoomerReset",this.gaw8())
if($.$get$hK()===!0){y=this.r2.cx
y.toString
y=H.d(new W.bK(y,"touchstart",!1),[H.r(C.T,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gb0T()),y.c),[H.r(y,0)])
y.t()
z.push(y)}}this.dx=null
this.dy=null},
b0Y:function(a){var z=J.n(a)
return!!z.$isua||!!z.$isiA||!!z.$isjD},
QZ:function(a){return C.a.iz(this.Ob(a),new E.arJ(this),V.EN())!=null},
aGx:function(a){var z=J.n(a)
if(!!z.$isjD)return J.au(a.db)?null:a.db
else if(!!z.$iskW)return a.db
return 0/0},
a4z:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isjD){if(b==null)y=null
else{y=J.aV(b)
x=!a.ac
w=new P.ak(y,x)
w.eQ(y,x)
y=w}z.sjN(a,y)}else if(!!z.$isiA)z.sjN(a,b)
else if(!!z.$isua)z.sjN(a,b)},
aIL:function(a,b){return this.a4z(a,b,!1)},
aGv:function(a){var z=J.n(a)
if(!!z.$isjD)return J.au(a.cy)?null:a.cy
else if(!!z.$iskW)return a.cy
return 0/0},
a4y:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isjD){if(b==null)y=null
else{y=J.aV(b)
x=!a.ac
w=new P.ak(y,x)
w.eQ(y,x)
y=w}z.skE(a,y)}else if(!!z.$isiA)z.skE(a,b)
else if(!!z.$isua)z.skE(a,b)},
aIJ:function(a,b){return this.a4y(a,b,!1)},
aiC:function(a,b,a0){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=a===2
if(z){y=this.dy
if(y==null){y=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[D.eJ,E.Bf])),[D.eJ,E.Bf])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[D.eJ,E.Bf])),[D.eJ,E.Bf])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.Ob(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.K)(v),++u){t=v[u]
s=x.a
if(!s.X(0,t)){r=J.n(t)
r=!!r.$isua||!!r.$isiA||!!r.$isjD}else r=!1
if(r)s.l(0,t,new E.Bf(!1,this.aGx(t),this.aGv(t)))}}y=this.cy
if(z){y=y.b
q=P.aG(y,J.k(y,b))
y=this.cy.b
p=P.aA(y,J.k(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aG(y,J.k(y,b))
y=this.cy.a
m=P.aA(y,J.k(y,b))
o="h"
q=null
p=null}l=[]
k=D.k4(this.r2.af,!1)
for(y=k.length,s=o==="v",r=!a0,j=null,i=null,h=null,g=null,u=0;u<k.length;k.length===y||(0,H.K)(k),++u){f=k[u]
if(!(f instanceof D.kJ))continue
if(f.go!==!0||f.fy!==!0){g=f
continue}h=s?f.ak:f.ac
e=J.n(h)
if(!(!!e.$isua||!!e.$isiA||!!e.$isjD)){g=f
continue}if(J.ao(C.a.bp(l,h),0)){g=f
continue}l.push(h)
e=f.cy
if(z){d=F.ba(e,H.d(new P.G(0,0),[null]))
e=J.aR(F.aO(J.ac(f.gdn()),d).b)
if(typeof q!=="number")return q.E()
e=H.d(new P.G(0,q-e),[null])
j=J.q(f.fr.rV([J.p(e.a,C.b.U(f.cy.offsetLeft)),J.p(e.b,C.b.U(f.cy.offsetTop))]),1)
d=F.ba(f.cy,H.d(new P.G(0,0),[null]))
e=J.aR(F.aO(J.ac(f.gdn()),d).b)
if(typeof p!=="number")return p.E()
e=H.d(new P.G(0,p-e),[null])
i=J.q(f.fr.rV([J.p(e.a,C.b.U(f.cy.offsetLeft)),J.p(e.b,C.b.U(f.cy.offsetTop))]),1)}else{d=F.ba(e,H.d(new P.G(0,0),[null]))
e=J.aR(F.aO(J.ac(f.gdn()),d).a)
if(typeof m!=="number")return m.E()
e=H.d(new P.G(m-e,0),[null])
j=J.q(f.fr.rV([J.p(e.a,C.b.U(f.cy.offsetLeft)),J.p(e.b,C.b.U(f.cy.offsetTop))]),0)
d=F.ba(f.cy,H.d(new P.G(0,0),[null]))
e=J.aR(F.aO(J.ac(f.gdn()),d).a)
if(typeof n!=="number")return n.E()
e=H.d(new P.G(n-e,0),[null])
i=J.q(f.fr.rV([J.p(e.a,C.b.U(f.cy.offsetLeft)),J.p(e.b,C.b.U(f.cy.offsetTop))]),0)}if(J.Q(i,j)){c=i
i=j
j=c}this.aIL(h,j)
this.aIJ(h,i)
if(!this.fr){x.a.h(0,h).saiD(!0)
if(h!=null&&r){e=this.r2
if(z){e.cg=j
e.ca=i
e.aEG()}else{e.c2=j
e.cf=i
e.aDG()}}}this.fr=!0
if(!this.r2.cm)break
g=f}},
aFs:function(a,b){return this.aiC(a,b,!1)},
aBR:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.Ob(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.X(0,t)){this.a4z(t,J.Y9(w.h(0,t)),!0)
this.a4y(t,J.Y8(w.h(0,t)),!0)
if(w.h(0,t).gaiD())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.c2=0/0
x.cf=0/0
x.aDG()}},
agq:function(){return this.aBR(!1)},
aBW:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.Ob(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.K)(y),++u){t=y[u]
if(w.X(0,t)){this.a4z(t,J.Y9(w.h(0,t)),!0)
this.a4y(t,J.Y8(w.h(0,t)),!0)
if(w.h(0,t).gaiD())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.cg=0/0
x.ca=0/0
x.aEG()}},
agr:function(){return this.aBW(!1)},
aFt:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.F(a)
if(z.gkm(a)||J.au(b)){if(this.fr)if(c)this.aBW(!0)
else this.aBR(!0)
return}if(!this.QZ(c))return
y=this.Ob(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.aGS(x)
if(w==null)return
v=J.n(b)
if(c){u=J.k(w.LH(["0",z.aJ(a)]).b,this.ajJ(w))
t=J.k(w.LH(["0",v.aJ(b)]).b,this.ajJ(w))
this.cy=H.d(new P.G(50,u),[null])
this.aiC(2,J.p(t,u),!0)}else{s=J.k(w.LH([z.aJ(a),"0"]).a,this.ajI(w))
r=J.k(w.LH([v.aJ(b),"0"]).a,this.ajI(w))
this.cy=H.d(new P.G(s,50),[null])
this.aiC(1,J.p(r,s),!0)}},
Ob:function(a){var z,y,x,w,v,u,t
z=[]
y=D.k4(this.r2.af,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.K)(y),++v){u=y[v]
if(!(u instanceof D.kJ))continue
if(a){t=u.ak
if(t!=null&&J.Q(C.a.bp(z,t),0))z.push(u.ak)}else{t=u.ac
if(t!=null&&J.Q(C.a.bp(z,t),0))z.push(u.ac)}w=u}return z},
aGS:function(a){var z,y,x,w,v
z=D.k4(this.r2.af,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.K)(z),++w){v=z[w]
if(!(v instanceof D.kJ))continue
if(J.a(v.ak,a)||J.a(v.ac,a))return v
x=v}return},
ajI:function(a){var z=F.ba(a.cy,H.d(new P.G(0,0),[null]))
return J.aR(F.aO(J.ac(a.gdn()),z).a)},
ajJ:function(a){var z=F.ba(a.cy,H.d(new P.G(0,0),[null]))
return J.aR(F.aO(J.ac(a.gdn()),z).b)},
fP:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.X(0,a))z.h(0,a).kR(null)
R.qM(a,b,c,d)
return}if(!!J.n(a).$isbi){z=this.k4.a
if(!z.X(0,a))z.l(0,a,new N.cd(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.kR(b)
y.smv(c)
y.sm9(d)}},
ft:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.X(0,a))z.h(0,a).kI(null)
R.vK(a,b)
return}if(!!J.n(a).$isbi){z=this.k4.a
if(!z.X(0,a))z.l(0,a,new N.cd(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).kI(b)}},
aUl:function(a){var z,y,x,w
for(z=a.length,y=this.rx,x=0;x<a.length;a.length===z||(0,H.K)(a),++x){w=a[x]
if(y.B(0,w.identifier))return w}return},
aUm:function(a){var z,y,x,w
z=this.rx
z.dU(0)
for(y=a.length,x=0;w=a.length,x<w;a.length===y||(0,H.K)(a),++x)z.n(0,a[x].identifier)
if(0>=w)return H.e(a,0)
return a[0]},
bvB:[function(a){var z,y
if($.$get$hK()===!0){z=Date.now()
y=$.nx
if(typeof y!=="number")return H.l(y)
y=z-y<1000
z=y}else z=!1
if(z)return
this.aAE(J.cl(a))},"$1","gb0S",2,0,4,4],
bvC:[function(a){var z=this.aUm(J.MM(a))
$.nx=Date.now()
this.aAE(H.d(new P.G(C.b.U(z.pageX),C.b.U(z.pageY)),[null]))},"$1","gb0T",2,0,5,4],
aAE:function(a){var z,y
z=this.r2
if(!z.c4&&!z.cd)return
z.cx.appendChild(this.go)
z=this.r2
this.jl(z.Q,z.ch)
this.cy=F.aO(this.go,a)
this.cx=!0
z=this.fy
y=H.d(new W.aC(document,"mousemove",!1),[H.r(C.y,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaHf()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.aC(document,"mouseup",!1),[H.r(C.z,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaHg()),y.c),[H.r(y,0)])
y.t()
z.push(y)
if($.$get$hK()===!0){y=H.d(new W.aC(document,"touchmove",!1),[H.r(C.av,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaHi()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.aC(document,"touchend",!1),[H.r(C.ab,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gaHh()),y.c),[H.r(y,0)])
y.t()
z.push(y)}y=H.d(new W.aC(document,"keydown",!1),[H.r(C.a4,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gEu()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.db=0
this.stR(null)},
brh:[function(a){this.aAF(J.cl(a))},"$1","gaHf",2,0,4,4],
brk:[function(a){var z=this.aUl(J.MM(a))
if(z!=null)this.aAF(J.cl(z))},"$1","gaHi",2,0,5,4],
aAF:function(a){var z,y
z=F.aO(this.go,a)
if(this.db===0)if(this.r2.bM){if(!(this.QZ(!0)&&this.QZ(!1))){this.Lu()
return}if(J.ao(J.aX(J.p(z.a,this.cy.a)),2)&&J.ao(J.aX(J.p(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.x(J.aX(J.p(z.b,this.cy.b)),J.aX(J.p(z.a,this.cy.a)))){if(this.QZ(!0))this.db=2
else{this.Lu()
return}y=2}else{if(this.QZ(!1))this.db=1
else{this.Lu()
return}y=1}if(y===1)if(!this.r2.c4){this.Lu()
return}if(y===2)if(!this.r2.cd){this.Lu()
return}}y=this.r2
if(P.bl(0,0,y.Q,y.ch,null).pA(0,z)){y=this.db
if(y===2)this.stR(H.d(new P.G(0,J.p(z.b,this.cy.b)),[null]))
else if(y===1)this.stR(H.d(new P.G(J.p(z.a,this.cy.a),0),[null]))
else if(y===3)this.stR(H.d(new P.G(J.p(z.a,this.cy.a),J.p(z.b,this.cy.b)),[null]))
else this.stR(null)}},
bri:[function(a){this.aAG()},"$1","gaHg",2,0,4,4],
brj:[function(a){this.aAG()},"$1","gaHh",2,0,5,4],
aAG:function(){var z,y
for(z=this.fy;z.length>0;)z.pop().D(0)
J.Z(this.go)
this.cx=!1
this.ds()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.aFs(2,z.b)
z=this.db
if(z===1||z===3)this.aFs(1,this.r1.a)}else{this.agq()
V.W(new E.arL(this))}},
ac7:[function(a){if(F.d_(a)===27)this.Lu()},"$1","gEu",2,0,7,4],
Lu:function(){for(var z=this.fy;z.length>0;)z.pop().D(0)
J.Z(this.go)
this.cx=!1
this.ds()},
byp:[function(a){this.agq()
V.W(new E.arK(this))},"$1","gaw8",2,0,8,4],
aPl:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.w(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
aj:{
arI:function(){var z,y
z=H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.t,N.cd])),[P.t,N.cd])
y=P.a8(null,null,null,P.O)
z=new E.arH(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,y,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new U.aa(H.d(new H.a2(0,null,null,null,null,null,0),[P.v,[P.C,P.aI]])),[P.v,[P.C,P.aI]]))
z.a=z
z.aPl()
return z}}},
arJ:{"^":"c:0;a",
$1:function(a){return this.a.b0Y(a)}},
arL:{"^":"c:3;a",
$0:[function(){this.a.agr()},null,null,0,0,null,"call"]},
arK:{"^":"c:3;a",
$0:[function(){this.a.agr()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.b8,args:[V.u,P.v,P.b8]},{func:1,v:true,args:[[P.a3,P.v]]},{func:1,ret:F.bL},{func:1,v:true,args:[W.cH]},{func:1,v:true,args:[W.iR]},{func:1,v:true,args:[P.t]},{func:1,v:true,args:[W.hy]},{func:1,v:true,args:[N.cA]},{func:1,ret:P.v,args:[D.m6]}]
init.types.push.apply(init.types,deferredTypes)
$.Wt=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["a4B","$get$a4B",function(){return P.m(["scaleType",new E.bCv(),"offsetLeft",new E.bCw(),"offsetRight",new E.bCx(),"minimum",new E.bCy(),"maximum",new E.bCz(),"formatString",new E.bCA(),"showMinMaxOnly",new E.bCB(),"percentTextSize",new E.bCC(),"labelsColor",new E.bCD(),"labelsFontFamily",new E.bCE(),"labelsFontStyle",new E.bCG(),"labelsFontWeight",new E.bCH(),"labelsTextDecoration",new E.bCI(),"labelsLetterSpacing",new E.bCJ(),"labelsRotation",new E.bCK(),"labelsAlign",new E.bCL(),"angleFrom",new E.bCM(),"angleTo",new E.bCN(),"percentOriginX",new E.bCO(),"percentOriginY",new E.bCP(),"percentRadius",new E.bCR(),"majorTicksCount",new E.bCS(),"justify",new E.bCT()])},$,"a4C","$get$a4C",function(){var z=P.U()
z.p(0,N.em())
z.p(0,$.$get$a4B())
return z},$,"a4D","$get$a4D",function(){return P.m(["scaleType",new E.bCU(),"ticksPlacement",new E.bCV(),"offsetLeft",new E.bCW(),"offsetRight",new E.bCX(),"majorTickStroke",new E.bCY(),"majorTickStrokeWidth",new E.bCZ(),"minorTickStroke",new E.bD_(),"minorTickStrokeWidth",new E.bD1(),"angleFrom",new E.bD2(),"angleTo",new E.bD3(),"percentOriginX",new E.bD4(),"percentOriginY",new E.bD5(),"percentRadius",new E.bD6(),"majorTicksCount",new E.bD7(),"majorTicksPercentLength",new E.bD8(),"minorTicksCount",new E.bD9(),"minorTicksPercentLength",new E.bDa(),"cutOffAngle",new E.bDc()])},$,"a4E","$get$a4E",function(){var z=P.U()
z.p(0,N.em())
z.p(0,$.$get$a4D())
return z},$,"a4F","$get$a4F",function(){return P.m(["scaleType",new E.bCh(),"offsetLeft",new E.bCi(),"offsetRight",new E.bCk(),"percentStartThickness",new E.bCl(),"percentEndThickness",new E.bCm(),"placement",new E.bCn(),"gradient",new E.bCo(),"angleFrom",new E.bCp(),"angleTo",new E.bCq(),"percentOriginX",new E.bCr(),"percentOriginY",new E.bCs(),"percentRadius",new E.bCt()])},$,"a4G","$get$a4G",function(){var z=P.U()
z.p(0,N.em())
z.p(0,$.$get$a4F())
return z},$])}
$dart_deferred_initializers$["I4M4yAw4tfrwuFCFFGwdsHoI2NU="]=$dart_deferred_initializers$.current

//# sourceMappingURL=main.dart.js_2.part.js.map
