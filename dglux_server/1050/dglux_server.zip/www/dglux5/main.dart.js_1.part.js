self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,N,{"^":"",
aI3:function(){var z=document
z=z.createElement("div")
z=new N.G0(null,null,null,null,null,null,null,null,null,null,null,null,null,"horizontal",null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,null,1,null,11583952,"solid",1,!1,15658734,"solid",1,!0,15658734,"solid",1,null,null,"line",null,-1,-1,null,z,[],null,null,null,!0,!0,!0,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.ps()
z.adE()
return z},
akE:{"^":"Kb;",
sqN:["axh",function(a){if(!J.a(this.k4,a)){this.k4=a
this.cZ()}}],
sHt:function(a){if(!J.a(this.r1,a)){this.r1=a
this.cZ()}},
sHu:function(a){if(!J.a(this.rx,a)){this.rx=a
this.cZ()}},
sHv:function(a){if(!J.a(this.ry,a)){this.ry=a
this.cZ()}},
sHx:function(a){if(!J.a(this.x1,a)){this.x1=a
this.cZ()}},
sHw:function(a){if(!J.a(this.x2,a)){this.x2=a
this.cZ()}},
saUW:function(a){if(!J.a(this.y1,a)){if(J.y(a,180))a=180
this.y1=J.S(a,-180)?-180:a
this.cZ()}},
saUV:function(a){if(J.a(this.y2,a))return
this.y2=a
this.cZ()},
giJ:function(a){return this.E},
siJ:function(a,b){if(b==null)b=0
if(!J.a(this.E,b)){this.E=b
this.cZ()}},
gji:function(a){return this.v},
sji:function(a,b){if(b==null)b=100
if(!J.a(this.v,b)){this.v=b
this.cZ()}},
sb0M:function(a){if(this.L!==a){this.L=a
this.cZ()}},
gv3:function(a){return this.T},
sv3:function(a,b){if(b==null||J.S(b,0))b=0
if(J.y(b,4))b=4
if(!J.a(this.T,b)){this.T=b
this.cZ()}},
savF:function(a){if(this.W!==a){this.W=a
this.cZ()}},
swc:function(a){this.Y=a
this.cZ()},
gqe:function(){return this.F},
sqe:function(a){if(!J.a(this.F,a)){this.F=a
this.cZ()}},
saUL:function(a){if(!J.a(this.Z,a)){this.Z=a
this.cZ()}},
gtX:function(a){return this.S},
stX:["acs",function(a,b){if(!J.a(this.S,b))this.S=b}],
sHQ:["act",function(a){if(!J.a(this.at,a))this.at=a}],
sa5x:function(a){this.acv(a)
this.cZ()},
iS:function(a,b){this.FE(a,b)
this.Ob()
if(J.a(this.F,"circular"))this.b0W(a,b)
else this.b0X(a,b)},
Ob:function(){var z,y,x,w,v
z=this.W
y=this.k2
if(z){y.sdY(0,2)
z=this.k2.f
if(0>=z.length)return H.e(z,0)
x=z[0]
z=J.n(x)
if(!!z.$isd8)z.sc6(x,this.a2F(this.E,this.T))
J.a3(J.b6(x.gaV()),"text-decoration",this.x1)
z=this.k2.f
if(1>=z.length)return H.e(z,1)
x=z[1]
z=J.n(x)
if(!!z.$isd8)z.sc6(x,this.a2F(this.v,this.T))
J.a3(J.b6(x.gaV()),"text-decoration",this.x1)}else{y.sdY(0,this.fy)
w=null
v=0
while(!0){z=this.fy
if(typeof z!=="number")return H.l(z)
if(!(v<z))break
z=this.k2.f
if(v>=z.length)return H.e(z,v)
x=z[v]
z=J.n(x)
if(!!z.$isd8){y=this.E
w=J.k(y,J.D(J.M(J.o(this.v,y),J.o(this.fy,1)),v))
z.sc6(x,this.a2F(w,this.T))}J.a3(J.b6(x.gaV()),"text-decoration",this.x1);++v}}this.eK(this.k3,this.k4)
this.k3.setAttribute("font-family",this.r1)
z=this.k3
z.toString
z.setAttribute("font-size",""+this.r2+"px")
this.k3.setAttribute("font-style",this.rx)
this.k3.setAttribute("font-weight",this.ry)
z=this.k3
z.toString
z.setAttribute("letter-spacing",H.b(this.x2)+"px")},
b0W:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=J.M(J.o(this.fr,this.dy),z-1)
x=P.ax(a,b)
w=this.k1
if(typeof w!=="number")return H.l(w)
v=x*w/200
w=J.M(a,2)
x=P.ax(a,b)
u=this.db
if(typeof u!=="number")return H.l(u)
t=J.o(w,x*(50-u)/100)
u=J.M(b,2)
x=P.ax(a,b)
w=this.dx
if(typeof w!=="number")return H.l(w)
s=J.o(u,x*(50-w)/100)
r=C.c.M(this.L,"%")&&!0
x=this.L
if(r){H.c9("")
x=H.dH(x,"%","")}q=P.dG(x,null)
for(x=J.aw(y),p=0;p<z;++p){w=this.k2.f
if(p>=w.length)return H.e(w,p)
o=w[p]
w=J.k(J.o(this.dy,90),x.bk(y,p))
if(typeof w!=="number")return H.l(w)
n=0.017453292519943295*w
m=this.Jp(o)
w=m.b
u=J.E(w)
if(u.bI(w,0)){if(r){l=P.ax(a,b)
if(typeof q!=="number")return H.l(q)
l=l*q/200}else l=q
k=J.M(l,w)}else k=0
l=m.a
j=J.aw(l)
i=J.k(j.bk(l,l),u.bk(w,w))
if(typeof i!=="number")H.ac(H.bB(i))
i=Math.sqrt(i)
h=J.D(k,5)
if(typeof h!=="number")return H.l(h)
g=i/2+h
switch(this.Z){case"inside":f=v-g
break
case"outside":f=v+g
break
default:f=v}i=Math.cos(n)
if(typeof t!=="number")return H.l(t)
h=Math.sin(n)
if(typeof s!=="number")return H.l(s)
e=J.D(j.dg(l,2),k)
if(typeof e!=="number")return H.l(e)
d=f*i+t-e
e=J.D(u.dg(w,2),k)
if(typeof e!=="number")return H.l(e)
c=f*h+s+e
J.a3(J.b6(o.gaV()),"transform","")
i=J.n(o)
if(!!i.$iscK)i.iK(o,d,c)
else E.eB(o.gaV(),d,c)
i=J.b6(o.gaV())
h=J.I(i)
h.l(i,"transform",J.k(h.h(i,"transform")," scale ("+H.b(k)+")"))
if(!J.a(this.y1,0))if(!!J.n(o.gaV()).$ismE){i=J.b6(o.gaV())
h=J.I(i)
h.l(i,"transform",J.k(h.h(i,"transform")," rotate("+H.b(this.y1)+" "+H.b(j.dg(l,2))+" "+H.b(J.M(u.f4(w),2))+")"))}else{J.kq(J.J(o.gaV())," rotate("+H.b(this.y1)+"deg)")
J.nQ(J.J(o.gaV()),H.b(J.D(j.dg(l,2),k))+" "+H.b(J.D(u.dg(w,2),k)))}}},
b0X:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c
z=this.k2.f.length
y=z-1
J.M(J.o(this.fr,this.dy),y)
x=this.k2.f
if(0>=x.length)return H.e(x,0)
w=this.Jp(x[0])
v=C.c.M(this.L,"%")&&!0
x=this.L
if(v){H.c9("")
x=H.dH(x,"%","")}u=P.dG(x,null)
x=w.b
t=J.E(x)
if(t.bI(x,0))s=J.M(v?J.M(J.D(a,u),200):u,x)
else s=0
r=J.M(J.D(this.y1,3.141592653589793),180)
q=Math.abs(Math.cos(H.ab(r)))
p=Math.abs(Math.sin(H.ab(r)))
this.acs(this,J.D(J.M(J.k(J.D(w.a,q),t.bk(x,p)),2),s))
this.Ws()
x=this.k2.f
if(y<0||y>=x.length)return H.e(x,y)
w=this.Jp(x[y])
x=w.b
t=J.E(x)
if(t.bI(x,0))s=J.M(v?J.M(J.D(a,u),200):u,x)
else s=0
this.act(J.D(J.M(J.k(J.D(w.a,q),t.bk(x,p)),2),s))
this.Ws()
if(!J.a(this.y1,0)){for(x=J.aw(a),o=0,n=0;n<z;++n){t=this.k2.f
if(n>=t.length)return H.e(t,n)
w=this.Jp(t[n])
t=w.b
m=J.E(t)
if(m.bI(t,0))J.M(v?J.M(x.bk(a,u),200):u,t)
o=P.aB(J.k(J.D(w.a,p),m.bk(t,q)),o)}switch(this.y2){case"left":l=0
break
case"center":l=0.5
break
default:l=1}}else{o=0
l=null}x=J.E(a)
k=J.M(J.o(x.A(a,this.S),this.at),y)
for(n=0;n<z;++n){y=this.k2.f
if(n>=y.length)return H.e(y,n)
j=y[n]
y=this.S
if(typeof k!=="number")return H.l(k)
t=n*k
i=J.k(y,t)
w=this.Jp(j)
y=w.b
m=J.E(y)
if(m.bI(y,0))s=J.M(v?J.M(x.bk(a,u),200):u,y)
else s=0
h=w.a
g=J.E(h)
i=J.o(i,J.D(g.dg(h,2),s))
J.a3(J.b6(j.gaV()),"transform","")
if(J.a(this.y1,0)){y=J.D(J.k(g.bk(h,p),m.bk(y,q)),s)
if(typeof y!=="number")return H.l(y)
f=0+y
y=J.n(j)
if(!!y.$iscK)y.iK(j,i,f)
else E.eB(j.gaV(),i,f)
y=J.b6(j.gaV())
t=J.I(y)
t.l(y,"transform",J.k(t.h(y,"transform")," scale ("+H.b(s)+")"))}else{i=J.o(J.k(this.S,t),g.dg(h,2))
t=J.k(g.bk(h,p),m.bk(y,q))
if(typeof t!=="number")return H.l(t)
if(typeof l!=="number")return H.l(l)
if(typeof s!=="number")return H.l(s)
if(typeof y!=="number")return H.l(y)
e=((o*(1-l)*2+(0+t)*(2*l-1))*s+y)/2
t=J.n(j)
if(!!t.$iscK)t.iK(j,i,e)
else E.eB(j.gaV(),i,e)
d=g.dg(h,2)
c=-y/2
y=J.b6(j.gaV())
t=J.I(y)
m=s-1
t.l(y,"transform",J.k(t.h(y,"transform")," translate("+H.b(J.D(J.bG(d),m))+" "+H.b(-c*m)+")"))
m=J.b6(j.gaV())
y=J.I(m)
y.l(m,"transform",J.k(y.h(m,"transform")," scale ("+H.b(s)+")"))
m=J.b6(j.gaV())
y=J.I(m)
y.l(m,"transform",J.k(y.h(m,"transform")," rotate("+H.b(this.y1)+" "+H.b(d)+" "+H.b(c)+")"))}}},
Jp:function(a){var z,y,x,w
if(!!J.n(a.gaV()).$isep){z=H.j(a.gaV(),"$isep").getBBox()
y=z.width
y.toString
x=z.height
if(typeof x!=="number")return x.bk()
w=x*0.7}else{y=J.d0(a.gaV())
y.toString
w=J.cU(a.gaV())
w.toString}return H.d(new P.F(y,w),[null])},
a2N:[function(){return N.CZ()},"$0","guF",0,0,3],
a2F:function(a,b){var z=this.Y
if(z==null||J.a(z,""))return U.oE(a,"0")
else return U.oE(a,this.Y)},
a7:[function(){this.acv(0)
this.cZ()
var z=this.k2
z.d=!0
z.r=!0
z.sdY(0,0)
z=this.k2
z.d=!1
z.r=!1},"$0","gd9",0,0,0],
aAY:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k3=y
J.x(y).n(0,"gauge-labels")
this.cy.appendChild(this.k3)
z=new N.nj(this.guF(),this.k3,0,!1,!0,[],!1,null,null)
this.k2=z
z.d=!0
z.r=!0}},
Kb:{"^":"ly;",
gZs:function(){return this.cy},
sUG:["axl",function(a){if(a==null)a=50
if(J.S(a,0))a=0
if(J.y(a,100))a=100
if(!J.a(this.db,a)){this.db=a
this.cZ()}}],
sUH:["axm",function(a){if(a==null)a=50
if(J.S(a,0))a=0
if(J.y(a,100))a=100
if(!J.a(this.dx,a)){this.dx=a
this.cZ()}}],
sRq:["axi",function(a){if(J.S(a,-360))a=-360
if(J.y(a,360))a=360
if(!J.a(this.dy,a)){this.dy=a
this.dZ()
this.cZ()}}],
sahC:["axj",function(a,b){if(J.S(b,-360))b=-360
if(J.y(b,360))b=360
if(!J.a(this.fr,b)){this.fr=b
this.dZ()
this.cZ()}}],
saWl:function(a){if(a==null||J.S(a,0))a=0
if(J.y(a,20))a=20
if(!J.a(this.fx,a)){this.fx=a
this.cZ()}},
sa5x:["acv",function(a){if(a==null||J.S(a,2))a=2
if(J.y(a,30))a=30
if(!J.a(this.fy,a)){this.fy=a
this.cZ()}}],
saWm:function(a){if(this.go!==a){this.go=a
this.cZ()}},
saVT:function(a){if(this.id!==a){this.id=a
this.cZ()}},
sUI:["axn",function(a){if(a==null||J.S(a,0))a=0
if(J.y(a,200))a=200
if(!J.a(this.k1,a)){this.k1=a
this.cZ()}}],
gk7:function(){return this.cy},
f6:["axk",function(a,b,c,d){R.p2(a,b,c,d)}],
eK:["acu",function(a,b){R.tN(a,b)}],
A7:function(a){var z,y
z=this.cx.a
y=z.charCodeAt(0)==0?z:z
z=J.h(a)
if(y!=="")J.a3(z.gf2(a),"d",y)
else J.a3(z.gf2(a),"d","M 0,0")}},
akF:{"^":"Kb;",
sa5w:["axo",function(a){if(!J.a(this.k4,a)){this.k4=a
this.cZ()}}],
saVS:function(a){if(!J.a(this.r2,a)){this.r2=a
this.cZ()}},
sqP:["axp",function(a){if(!J.a(this.rx,a)){this.rx=a
this.cZ()}}],
sHL:function(a){if(!J.a(this.x1,a)){this.x1=a
this.cZ()}},
gqe:function(){return this.x2},
sqe:function(a){if(!J.a(this.x2,a)){this.x2=a
this.cZ()}},
gtX:function(a){return this.y1},
stX:function(a,b){if(!J.a(this.y1,b)){this.y1=b
this.cZ()}},
sHQ:function(a){if(!J.a(this.y2,a)){this.y2=a
this.cZ()}},
sb2Y:function(a){if(!J.a(this.K,a)){this.K=a
this.cZ()}},
saNQ:function(a){var z
if(!J.a(this.E,a)){this.E=a
if(a!=null){z=J.o(a,90)
if(typeof z!=="number")return H.l(z)
z=3.141592653589793*z/180}else z=null
this.v=z
this.cZ()}},
iS:function(a,b){var z,y
this.FE(a,b)
z=this.k2
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k2=y
this.cy.appendChild(y)}else z.setAttribute("d","M 0,0")
this.f6(this.k2,this.k4,J.aL(this.r2),this.r1)
z=this.k3
if(z==null){z=document
y=z.createElementNS("http://www.w3.org/2000/svg","path")
this.k3=y
this.cy.insertBefore(y,this.k2)}else z.setAttribute("d","M 0,0")
this.f6(this.k3,this.rx,J.aL(this.x1),this.ry)
if(J.a(this.x2,"circular"))this.aPK(a,b)
else this.aPL(a,b)},
aPK:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f
z=this.cx
z.a=""
y=J.M(J.o(this.fr,this.dy),J.o(J.k(J.D(this.fx,J.o(this.fy,1)),this.fy),1))
x=C.c.M(this.go,"%")&&!0
w=this.go
if(x){H.c9("")
w=H.dH(w,"%","")}v=P.dG(w,null)
if(x){w=P.ax(b,a)
if(typeof v!=="number")return H.l(v)
u=w/2*v/100}else u=v
t=P.ax(a,b)
w=J.M(a,2)
s=this.db
if(typeof s!=="number")return H.l(s)
r=J.o(w,t*(50-s)/100)
s=J.M(b,2)
w=this.dx
if(typeof w!=="number")return H.l(w)
q=J.o(s,t*(50-w)/100)
w=P.ax(a,b)
s=this.k1
if(typeof s!=="number")return H.l(s)
p=w*s/200
if(J.a(this.K,"center"))o=0.5
else o=J.a(this.K,"outside")?1:0
w=o-1
s=J.aw(y)
n=0
while(!0){m=J.k(J.D(this.fx,J.o(this.fy,1)),this.fy)
if(typeof m!=="number")return H.l(m)
if(!(n<m))break
m=J.k(J.o(this.dy,90),s.bk(y,n))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++n}this.A7(this.k3)
z.a=""
y=J.M(J.o(this.fr,this.dy),J.o(this.fy,1))
h=C.c.M(this.id,"%")&&!0
s=this.id
if(h){H.c9("")
s=H.dH(s,"%","")}g=P.dG(s,null)
if(h){s=P.ax(b,a)
if(typeof g!=="number")return H.l(g)
u=s/2*g/100}else u=g
s=J.aw(y)
f=0
while(!0){m=this.fy
if(typeof m!=="number")return H.l(m)
if(!(f<m))break
m=J.k(J.o(this.dy,90),s.bk(y,f))
if(typeof m!=="number")return H.l(m)
l=0.017453292519943295*m
m=this.v
if(m!=null){if(typeof m!=="number")return H.l(m)
m=l>m}else m=!1
if(m)break
k=Math.cos(l)
j=Math.sin(l)
if(typeof u!=="number")return H.l(u)
m=p+o*u
if(typeof r!=="number")return H.l(r)
if(typeof q!=="number")return H.l(q)
i=p+w*u
z.a+="M "+H.b(m*k+r)+","+H.b(m*j+q)+" "
z.a+="L "+H.b(i*k+r)+","+H.b(i*j+q)+" ";++f}this.A7(this.k2)},
aPL:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i
z=C.c.M(this.go,"%")&&!0
y=this.go
if(z){H.c9("")
y=H.dH(y,"%","")}x=P.dG(y,null)
w=z?J.M(J.D(J.M(a,2),x),100):x
v=C.c.M(this.id,"%")&&!0
y=this.id
if(v){H.c9("")
y=H.dH(y,"%","")}u=P.dG(y,null)
t=v?J.M(J.D(J.M(a,2),u),100):u
y=this.cx
y.a=""
s=J.E(a)
r=J.M(J.o(s.A(a,this.y1),this.y2),J.o(J.k(J.D(this.fx,J.o(this.fy,1)),this.fy),1))
if(J.a(this.K,"center"))q=0.5
else q=J.a(this.K,"outside")?1:0
p=J.E(t)
o=p.A(t,w)
n=1-q
m=0
while(!0){l=J.k(J.D(this.fx,J.o(this.fy,1)),this.fy)
if(typeof l!=="number")return H.l(l)
if(!(m<l))break
if(typeof r!=="number")return H.l(r)
l=this.y1
if(typeof l!=="number")return H.l(l)
k=m*r+l
if(typeof o!=="number")return H.l(o)
j=p.A(t,q*o)
y.a+="M "+H.b(k)+","+H.b(n*o)+" "
y.a+="L "+H.b(k)+","+H.b(j)+" ";++m}this.A7(this.k3)
y.a=""
r=J.M(J.o(s.A(a,this.y1),this.y2),J.o(this.fy,1))
i=0
while(!0){s=this.fy
if(typeof s!=="number")return H.l(s)
if(!(i<s))break
if(typeof r!=="number")return H.l(r)
s=this.y1
if(typeof s!=="number")return H.l(s)
k=i*r+s
y.a+="M "+H.b(k)+",0 "
y.a+="L "+H.b(k)+","+H.b(t)+" ";++i}this.A7(this.k2)},
a7:[function(){var z=this.k2
if(z!=null){this.cx.a=""
this.A7(z)
this.A7(this.k3)}},"$0","gd9",0,0,0]},
akG:{"^":"Kb;",
sUG:function(a){this.axl(a)
this.r2=!0},
sUH:function(a){this.axm(a)
this.r2=!0},
sRq:function(a){this.axi(a)
this.r2=!0},
sahC:function(a,b){this.axj(this,b)
this.r2=!0},
sUI:function(a){this.axn(a)
this.r2=!0},
sb0L:function(a){if(this.ry!==a){this.ry=a
this.r2=!0
this.cZ()}},
sb0K:function(a){if(this.x1!==a){this.x1=a
this.r2=!0
this.cZ()}},
saaS:function(a){if(this.x2!==a){this.x2=a
this.dZ()
this.cZ()}},
gjk:function(){return this.y1},
sjk:function(a){var z=J.n(a)
if(!z.k(a,"inside")&&!z.k(a,"outside")&&!z.k(a,"cross"))a="inside"
if(!J.a(this.y1,a)){this.y1=a
this.r2=!0
this.cZ()}},
gqe:function(){return this.y2},
sqe:function(a){if(!J.a(this.y2,a)){this.y2=a
this.r2=!0
this.cZ()}},
gtX:function(a){return this.K},
stX:function(a,b){if(!J.a(this.K,b)){this.K=b
this.r2=!0
this.cZ()}},
sHQ:function(a){if(!J.a(this.E,a)){this.E=a
this.r2=!0
this.cZ()}},
jr:function(a){var z,y,x,w,v,u,t,s,r
this.zG(this)
z=this.x2
if(z==null){this.k2=[]
this.k3=[]
return}y=[]
x=[]
w=[]
for(v=z.length,u=0;u<z.length;z.length===v||(0,H.L)(z),++u){t=z[u]
s=J.h(t)
y.push(s.ghi(t))
x.push(s.gCS(t))
w.push(s.gu3(t))}if(J.cJ(J.o(this.dy,this.fr))===!0){z=J.b8(J.o(this.dy,this.fr))
if(typeof z!=="number")return H.l(z)
r=C.i.G(0.5*z)}else r=0
this.k2=this.aMN(y,w,r)
this.k3=this.aKl(x,w,r)
this.r2=!0},
iS:function(a,b){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h
this.FE(a,b)
z=J.aw(a)
y=J.aw(b)
E.FT(this.k4,z.bk(a,1),y.bk(b,1))
if(J.a(this.y2,"circular"))x=!this.r2||z.k(a,0)||y.k(b,0)
else x=!1
if(x){w=P.ax(a,b)
if(w===0)return
if(Math.abs(w-this.rx)/w<0.2)return}this.r2=!1
if(J.a(this.y2,"circular")){z=P.aB(0,P.ax(a,b))
this.rx=z
this.aPN(z,z)
z=this.cy
z.toString
z.setAttribute("viewBox","0 0 "+H.b(this.rx)+" "+H.b(this.rx))}else{z=J.D(J.o(z.A(a,this.K),this.E),1)
y.bk(b,1)
v=C.c.M(this.ry,"%")&&!0
y=this.ry
if(v){H.c9("")
y=H.dH(y,"%","")}u=P.dG(y,null)
t=v?J.M(J.D(z,u),100):u
s=C.c.M(this.x1,"%")&&!0
y=this.x1
if(s){H.c9("")
y=H.dH(y,"%","")}r=P.dG(y,null)
q=s?J.M(J.D(z,r),100):r
this.r1.sdY(0,1)
switch(this.y1){case"inside":p=q
o=t
n=0
m=0
break
case"outside":n=J.o(q,t)
p=q
o=p
m=0
break
case"cross":y=J.E(q)
x=J.E(t)
o=J.k(y.dg(q,2),x.dg(t,2))
n=J.o(y.dg(q,2),x.dg(t,2))
p=q
m=0
break
default:o=null
p=null
n=null
m=null}l=H.d(new P.F(this.K,o),[null])
k=H.d(new P.F(this.K,n),[null])
j=H.d(new P.F(J.k(this.K,z),p),[null])
i=H.d(new P.F(J.k(this.K,z),m),[null])
z=this.cx
z.a=""
y=this.r1.f
if(0>=y.length)return H.e(y,0)
h=y[0]
this.eK(h.gaV(),this.L)
R.p2(h.gaV(),null,0,"solid")
y=l.a
x=l.b
z.a+="M "+H.b(y)+","+H.b(x)+" "
z.a+="L "+H.b(j.a)+","+H.b(j.b)+" "
z.a+="L "+H.b(i.a)+","+H.b(i.b)+" "
z.a+="L "+H.b(k.a)+","+H.b(k.b)+" "
z.a+="L "+H.b(y)+","+H.b(x)+" "
this.A7(h.gaV())
x=this.cy
x.toString
new W.di(x).O(0,"viewBox")}},
aMN:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.km(J.D(J.o(v,b[y]),c))
if(u===0)continue
if(y>=a.length)return H.e(a,y)
t=J.V(J.bT(a[y],16),255)
if(y>=a.length)return H.e(a,y)
s=J.V(J.bT(a[y],8),255)
if(y>=a.length)return H.e(a,y)
r=J.V(a[y],255)
if(x>=a.length)return H.e(a,x)
q=J.V(J.bT(a[x],16),255)
if(x>=a.length)return H.e(a,x)
p=J.V(J.bT(a[x],8),255)
if(x>=a.length)return H.e(a,x)
o=J.V(a[x],255)
for(n=0;n<u;++n){m=n/u
w=1-m
if(typeof t!=="number")return H.l(t)
if(typeof q!=="number")return H.l(q)
v=C.b.G(w*t+m*q)
if(typeof s!=="number")return H.l(s)
if(typeof p!=="number")return H.l(p)
l=C.b.G(w*s+m*p)
if(typeof r!=="number")return H.l(r)
if(typeof o!=="number")return H.l(o)
z.push(((v&255)<<16|(l&255)<<8|C.b.G(w*r+m*o)&255)>>>0)}}return z},
aKl:function(a,b,c){var z,y,x,w,v,u,t,s
z=[]
for(y=0;y<a.length-1;y=x){x=y+1
w=b.length
if(x>=w)return H.e(b,x)
v=b[x]
if(y>=w)return H.e(b,y)
u=J.km(J.D(J.o(v,b[y]),c))
if(u===0)continue
w=a.length
if(x>=w)return H.e(a,x)
v=a[x]
if(y>=w)return H.e(a,y)
t=J.M(J.o(v,a[y]),u)
for(s=0;s<u;++s){if(y>=a.length)return H.e(a,y)
w=a[y]
if(typeof t!=="number")return H.l(t)
z.push(J.k(w,s*t))}}return z},
aPN:function(a4,a5){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,c,b,a,a0,a1,a2,a3
z=P.ax(a4,a5)
y=this.k1
if(typeof y!=="number")return H.l(y)
x=z*y/200
w=this.k2.length
v=C.c.M(this.ry,"%")&&!0
z=this.ry
if(v){H.c9("")
z=H.dH(z,"%","")}u=P.dG(z,new N.akH())
if(v){z=P.ax(a5,a4)
if(typeof u!=="number")return H.l(u)
t=z/2*u/100}else t=u
s=C.c.M(this.x1,"%")&&!0
z=this.x1
if(s){H.c9("")
z=H.dH(z,"%","")}r=P.dG(z,new N.akI())
if(s){z=P.ax(a5,a4)
if(typeof r!=="number")return H.l(r)
q=z/2*r/100}else q=r
z=P.ax(a4,a5)
y=this.db
if(typeof y!=="number")return H.l(y)
p=a4/2-z*(50-y)/100
y=P.ax(a4,a5)
z=this.dx
if(typeof z!=="number")return H.l(z)
o=a5/2-y*(50-z)/100
this.r1.sdY(0,w)
for(z=J.E(q),y=this.cx,n=null,m=null,l=0,k=0,j=0,i=0,h=null,g=null,f=0;f<=w;++f,i=a2,j=a1,k=a0,l=a){e=J.o(this.dy,90)
d=J.o(this.fr,this.dy)
if(typeof d!=="number")return H.l(d)
d=J.k(e,f*d/w)
if(typeof d!=="number")return H.l(d)
c=0.017453292519943295*d
d=z.A(q,t)
if(typeof d!=="number")return H.l(d)
if(typeof t!=="number")return H.l(t)
b=f*d/w+t
switch(this.y1){case"inside":m=-b
n=0
break
case"outside":n=b
m=0
break
case"cross":n=b/2
m=-b/2
break}if(typeof n!=="number")return H.l(n)
e=x+n
a=e*Math.cos(c)+p
a0=e*Math.sin(c)+o
if(typeof m!=="number")return H.l(m)
e=x+m
a1=e*Math.cos(c)+p
a2=e*Math.sin(c)+o
if(f!==0){y.a=""
e=this.r1.f
d=f-1
if(d<0||d>=e.length)return H.e(e,d)
h=e[d]
e=this.k3
if(d>=e.length)return H.e(e,d)
g=J.aN(J.D(e[d],255))
g=J.b1(J.a(g,0)?1:g,24)
e=h.gaV()
a3=this.k2
if(d>=a3.length)return H.e(a3,d)
a3=a3[d]
if(typeof g!=="number")return H.l(g)
this.eK(e,a3+g)
a3=h.gaV()
e=this.k2
if(d>=e.length)return H.e(e,d)
R.p2(a3,e[d]+g,1,"solid")
y.a+="M "+H.b(l)+","+H.b(k)+" "
y.a+="L "+H.b(a)+","+H.b(a0)+" "
y.a+="L "+H.b(a1)+","+H.b(a2)+" "
y.a+="L "+H.b(j)+","+H.b(i)+" "
y.a+="L "+H.b(l)+","+H.b(k)+" "
this.A7(h.gaV())}}},
bh3:[function(){var z,y
z=new N.a6r(null)
y=document
z.a=y.createElementNS("http://www.w3.org/2000/svg","path")
return z},"$0","gb0B",0,0,3],
a7:["axq",function(){var z=this.r1
z.d=!0
z.r=!0
z.sdY(0,0)
z=this.r1
z.d=!1
z.r=!1},"$0","gd9",0,0,0],
aAZ:function(){var z,y
z=document
y=z.createElementNS("http://www.w3.org/2000/svg","g")
this.k4=y
this.cy.appendChild(y)
this.k4.setAttribute("transform","scale (1)")
this.saaS([new N.xi(65280,0.5,0),new N.xi(16776960,0.8,0.5),new N.xi(16711680,1,1)])
z=new N.nj(this.gb0B(),this.k4,0,!1,!0,[],!1,null,null)
this.r1=z
z.d=!0
z.r=!0}},
akH:{"^":"c:0;",
$1:function(a){return 0}},
akI:{"^":"c:0;",
$1:function(a){return 0}},
xi:{"^":"t;hi:a*,CS:b>,u3:c>"}}],["","",,L,{"^":"",
bJy:[function(a){var z=!!J.n(a.glJ().gaV()).$isfW?H.j(a.glJ().gaV(),"$isfW"):null
if(z!=null)if(z.gop()!=null&&!J.a(z.gop(),""))return L.V1(a.glJ(),z.gop())
else return z.H8(a)
return""},"$1","bAZ",2,0,8,55],
by7:function(){if($.Rn)return
$.Rn=!0
$.$get$hG().l(0,"percentTextSize",L.bB1())
$.$get$hG().l(0,"minorTicksPercentLength",L.adQ())
$.$get$hG().l(0,"majorTicksPercentLength",L.adQ())
$.$get$hG().l(0,"percentStartThickness",L.adS())
$.$get$hG().l(0,"percentEndThickness",L.adS())
$.$get$hH().l(0,"percentTextSize",L.bB2())
$.$get$hH().l(0,"minorTicksPercentLength",L.adR())
$.$get$hH().l(0,"majorTicksPercentLength",L.adR())
$.$get$hH().l(0,"percentStartThickness",L.adT())
$.$get$hH().l(0,"percentEndThickness",L.adT())},
b43:function(a){var z
switch(a){case"chart":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$De())
return z
case"scaleTicks":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$Ek())
return z
case"scaleLabels":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$Ei())
return z
case"scaleTrack":z=[]
C.a.q(z,$.$get$eo())
C.a.q(z,$.$get$Mg())
return z
case"linearAxis":return $.$get$wb()
case"logAxis":return $.$get$we()
case"categoryAxis":return $.$get$tz()
case"datetimeAxis":return $.$get$vZ()
case"axisRenderer":return $.$get$tu()
case"radialAxisRenderer":return $.$get$M9()
case"angularAxisRenderer":return $.$get$Kn()
case"linearAxisRenderer":return $.$get$tu()
case"logAxisRenderer":return $.$get$tu()
case"categoryAxisRenderer":return $.$get$tu()
case"datetimeAxisRenderer":return $.$get$tu()
case"lineSeries":return $.$get$w9()
case"areaSeries":return $.$get$CV()
case"columnSeries":return $.$get$Dh()
case"barSeries":return $.$get$D2()
case"bubbleSeries":return $.$get$D9()
case"pieSeries":return $.$get$z7()
case"spectrumSeries":return $.$get$Mv()
case"radarSeries":return $.$get$zb()
case"lineSet":return $.$get$qC()
case"areaSet":return $.$get$CX()
case"columnSet":return $.$get$Dj()
case"barSet":return $.$get$D4()
case"gridlines":return $.$get$Li()}return[]},
b41:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n
switch(c){case"chart":if(a instanceof L.nZ)return a
else{z=$.$get$Wo()
y=H.d([],[N.eF])
x=H.d([],[E.jn])
w=H.d([],[L.iO])
v=H.d([],[E.jn])
u=H.d([],[L.iO])
t=H.d([],[E.jn])
s=H.d([],[L.yF])
r=H.d([],[E.jn])
q=H.d([],[L.zc])
p=H.d([],[E.jn])
o=$.$get$am()
n=$.Q+1
$.Q=n
n=new L.nZ(z,null,null,y,x,!1,null,w,v,!1,null,u,t,!1,null,s,r,!1,null,q,p,!1,null,null,null,!1,!1,null,null,null,null,null,null,!1,null,null,null,null,null,null,-1,-1,o,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,n,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
n.c1(b,"chart")
J.U(J.x(n.b),"absolute")
o=L.amP()
n.w=o
J.bu(n.b,o.cx)
o=n.w
o.bo=n
o.OC()
o=L.ajW()
n.V=o
o.sd0(n.w)
return n}case"scaleTicks":if(a instanceof L.Ej)return a
else{z=$.$get$ZC()
y=$.$get$am()
x=$.Q+1
$.Q=x
x=new L.Ej(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c1(b,"scale-ticks")
J.U(J.x(x.b),"absolute")
z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.an2(z,null,null,16777215,"solid",1,16777215,"solid",1,"circular",0,0,"inside",null,null,new P.cl(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.cy=P.hK()
x.w=z
J.bu(x.b,z.gZs())
return x}case"scaleLabels":if(a instanceof L.Eh)return a
else{z=$.$get$ZA()
y=$.$get$am()
x=$.Q+1
$.Q=x
x=new L.Eh(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c1(b,"scale-labels")
J.U(J.x(x.b),"absolute")
z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.an0(z,null,null,null,16777215,"Verdana",16,"normal","normal","none",0,0,"right",null,0,100,"10%",1,!1,null,null,"circular","center",0,0,new P.cl(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.cy=P.hK()
z.aAY()
x.w=z
J.bu(x.b,z.gZs())
x.w.se5(x)
return x}case"scaleTrack":if(a instanceof L.El)return a
else{z=$.$get$ZE()
y=$.$get$am()
x=$.Q+1
$.Q=x
x=new L.El(z,null,!1,null,null,null,null,null,null,-1,-1,y,null,!1,!1,!1,"0.0","0.0","0.0","0.0","0.0","",null,"none",1,1,null,null,0,0,null,null,!1,"","",!1,!1,!0,x,"default",null,null,!1,"default",!1,null,0,!0,null,null,!1,!1,null,0,!1,0,0/0,null,null,null,[],!1,null,null,!1,null,!1,"absolute",!1,"","",null,!0,!1,!1,null,null,null,null,null,null,null,"",null,null,"","",null,"",!1,!1,"","","","","","",0/0,!1,!1,null,!1,null,0/0,0/0,!0,!1,!1,0,0,!1,!1,"0px","0px",0,0,1,1,!1,"50%","50%","50%","50%",0,0,null,$.$get$ao(),null,null,null,null,null,null,!1,!1,null,null,!1,null,null,null,null,null,null,null,null,null,null,P.a6(null,null,null,P.O),null,null,null,null,null,null,null,!1,null,null,null,null)
x.c1(b,"scale-track")
J.U(J.x(x.b),"absolute")
J.m6(J.J(x.b),"hidden")
y=L.an4()
x.w=y
J.bu(x.b,y.gZs())
return x}}return},
bK3:[function(){var z=new L.aoc(null,null,null)
z.ads()
return z},"$0","bB_",0,0,3],
amP:function(){var z,y,x,w,v,u,t
z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
y=P.bd(0,0,0,0,null)
x=P.bd(0,0,0,0,null)
w=new N.cG(0,0,0,0)
w.b=0
w.d=0
v=document
v=v.createElement("div")
u=H.d([],[P.fn])
t=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,P.t])),[P.u,P.t])
z=new L.nY(z,null,"none",!1,!1,0/0,0/0,!1,0/0,0/0,14976769,1,"solid",2566979328,0/0,0/0,0/0,0.65,0/0,0/0,0/0,0/0,0.65,0/0,y,!1,[],[],null,1,null,null,0,1,!0,x,w,!1,[],[],[],[],[],[],0/0,0/0,0/0,0/0,0.33,[],0.33,[],v,null,null,null,null,null,null,null,null,!1,null,null,u,[],[],null,null,!1,!1,0,!0,0/0,6,6,!0,t,null,null,null,null,[],[],[],[],null,null,"multiple",N.bAD(),0,5,[],[],!1,!1,16711680,1,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.aAW("chartBase")
z.aAU()
z.aBG()
z.sSy("single")
z.aB7()
return z},
bQD:[function(a,b,c){return L.b2M(a,c)},"$3","bB1",6,0,1,16,29,1],
b2M:function(a,b){var z,y,x
z=a.C("view")
if(z==null)return
y=z.gds()
if(y==null)return
x=J.h(y)
return J.M(J.D(J.a(y.gqe(),"circular")?P.ax(x.gbx(y),x.gbW(y)):x.gbx(y),b),200)},
bQE:[function(a,b,c){return L.b2N(a,c)},"$3","bB2",6,0,1,16,29,1],
b2N:function(a,b){var z,y,x,w
z=a.C("view")
if(z==null)return
y=z.gds()
if(y==null)return
x=J.D(b,200)
w=J.h(y)
return J.M(x,J.a(y.gqe(),"circular")?P.ax(w.gbx(y),w.gbW(y)):w.gbx(y))},
bQF:[function(a,b,c){return L.b2O(a,c)},"$3","adQ",6,0,1,16,29,1],
b2O:function(a,b){var z,y,x
z=a.C("view")
if(z==null)return
y=z.gds()
if(y==null)return
x=J.h(y)
return J.M(J.D(J.a(y.gqe(),"circular")?P.ax(x.gbx(y),x.gbW(y)):x.gbx(y),b),200)},
bQG:[function(a,b,c){return L.b2P(a,c)},"$3","adR",6,0,1,16,29,1],
b2P:function(a,b){var z,y,x,w
z=a.C("view")
if(z==null)return
y=z.gds()
if(y==null)return
x=J.D(b,200)
w=J.h(y)
return J.M(x,J.a(y.gqe(),"circular")?P.ax(w.gbx(y),w.gbW(y)):w.gbx(y))},
bQH:[function(a,b,c){return L.b2Q(a,c)},"$3","adS",6,0,1,16,29,1],
b2Q:function(a,b){var z,y,x
z=a.C("view")
if(z==null)return
y=z.gds()
if(y==null)return
x=J.h(y)
if(J.a(y.gqe(),"circular")){x=P.ax(x.gbx(y),x.gbW(y))
if(typeof b!=="number")return H.l(b)
x=x*b/200}else x=J.M(J.D(x.gbx(y),b),100)
return x},
bQI:[function(a,b,c){return L.b2R(a,c)},"$3","adT",6,0,1,16,29,1],
b2R:function(a,b){var z,y,x,w
z=a.C("view")
if(z==null)return
y=z.gds()
if(y==null)return
x=J.h(y)
w=J.aw(b)
return J.a(y.gqe(),"circular")?J.M(w.bk(b,200),P.ax(x.gbx(y),x.gbW(y))):J.M(w.bk(b,100),x.gbx(y))},
aoc:{"^":"MT;a,b,c",
sc6:function(a,b){var z,y,x,w,v
if(J.a(this.b,b))return
this.ay5(this,b)
if(b instanceof N.l3){z=b.e
if(z.gaV() instanceof N.eF&&H.j(z.gaV(),"$iseF").K!=null){J.lm(J.J(this.a),"")
return}y=K.bP(b.r,"fault")
if(y==="fault"&&b.r instanceof F.w){x=b.r
if(J.a(x.i("fillType"),"gradient")){w=x.i("gradient")
if(w instanceof F.el&&J.y(w.ry,0)){z=H.j(w.cX(0),"$isjC")
y=K.eS(z.ghi(z),null,"rgba(0,0,0,0)")}}}v=H.b(y==="fault"?K.eS(16711680,null,"rgba(0,0,0,0)"):y)+" 2px solid"
J.lm(J.J(this.a),v)}}},
an0:{"^":"akE;ai,ab,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,E,v,L,T,W,Y,U,F,Z,S,at,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sqN:function(a){var z=this.k4
if(z instanceof F.w)H.j(z,"$isw").cY(this.gdB())
this.axh(a)
if(a instanceof F.w)a.di(this.gdB())},
stX:function(a,b){this.acs(this,b)
this.Ws()},
sHQ:function(a){this.act(a)
this.Ws()},
ge5:function(){return this.ab},
se5:function(a){H.j(a,"$isaM")
this.ab=a
if(a!=null)F.bZ(this.gb4l())},
eK:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){this.acu(a,b)
return}if(!!J.n(a).$isb4){z=this.ai.a
if(!z.R(0,a))z.l(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jx(b)}},
oI:[function(a){this.cZ()},"$1","gdB",2,0,2,11],
Ws:[function(){var z=this.ab
if(z!=null)if(z.a instanceof F.w)F.a7(new L.an1(this))},"$0","gb4l",0,0,0]},
an1:{"^":"c:3;a",
$0:[function(){var z=this.a
z.ab.a.bC("offsetLeft",z.S)
z.ab.a.bC("offsetRight",z.at)},null,null,0,0,null,"call"]},
Eh:{"^":"aGr;aK,ds:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,c_,bo,bS,c5,c7,bz,bZ,bT,c2,c8,c9,c3,bJ,ck,cC,cq,ca,cw,cr,cz,cA,cG,cl,ct,cu,ci,cb,cJ,cn,cB,cD,bN,cf,cm,cE,cH,co,cs,cK,cU,cI,cv,cL,cM,cR,cc,cN,cO,cp,cP,cS,cQ,E,v,L,T,W,Y,U,F,Z,S,at,ai,ab,ac,aa,ag,ao,a9,aA,aO,aR,ae,aB,aD,aF,ap,an,aM,aQ,aw,b1,b6,b9,bh,bc,ba,b2,b3,bq,b0,bj,aX,bG,by,bm,bi,bn,aY,bD,bv,bf,br,bO,bB,bs,bQ,bH,bV,bE,bP,bF,bt,bd,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdv:function(){return this.aK},
sf9:function(a,b){if(J.a(this.F,"none")&&!J.a(b,"none")){this.m6(this,b)
this.e9()}else this.m6(this,b)},
fz:[function(a,b){this.mv(this,b)
this.siq(!0)},"$1","gf7",2,0,2,11],
rW:[function(a){this.x_()},"$0","gmJ",0,0,0],
a7:[function(){this.siq(!1)
this.fH()
this.w.sHE(!0)
this.w.a7()
this.w.sqN(null)
this.w.sHE(!1)},"$0","gd9",0,0,0],
ia:[function(){this.siq(!1)
this.fH()},"$0","gkp",0,0,0],
fV:function(){this.Cg()
this.siq(!0)},
x_:function(){if(this.a instanceof F.w)this.w.is(J.d0(this.b),J.cU(this.b))},
e9:function(){var z,y
this.zH()
this.soA(-1)
z=this.w
y=J.h(z)
y.sbx(z,J.o(y.gbx(z),1))},
$isbL:1,
$isbK:1,
$iscI:1},
aGr:{"^":"aM+mA;oA:x$?,uQ:y$?",$iscI:1},
bhr:{"^":"c:36;",
$2:[function(a,b){a.gds().sqe(K.at(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bhs:{"^":"c:36;",
$2:[function(a,b){J.Jq(a.gds(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bht:{"^":"c:36;",
$2:[function(a,b){a.gds().sHQ(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhu:{"^":"c:36;",
$2:[function(a,b){J.yc(a.gds(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhv:{"^":"c:36;",
$2:[function(a,b){J.yb(a.gds(),K.aV(b,100))},null,null,4,0,null,0,2,"call"]},
bhx:{"^":"c:36;",
$2:[function(a,b){a.gds().swc(K.G(b,""))},null,null,4,0,null,0,2,"call"]},
bhy:{"^":"c:36;",
$2:[function(a,b){a.gds().savF(K.T(b,!1))},null,null,4,0,null,0,2,"call"]},
bhz:{"^":"c:36;",
$2:[function(a,b){a.gds().sb0M(K.kJ(b,"","10%"))},null,null,4,0,null,0,2,"call"]},
bhA:{"^":"c:36;",
$2:[function(a,b){a.gds().sqN(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
bhB:{"^":"c:36;",
$2:[function(a,b){a.gds().sHt(K.G(b,"Verdana"))},null,null,4,0,null,0,2,"call"]},
bhC:{"^":"c:36;",
$2:[function(a,b){a.gds().sHu(K.at(b,"normal,italic".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bhD:{"^":"c:36;",
$2:[function(a,b){a.gds().sHv(K.at(b,"normal,bold,bolder,lighter,100,200,300,400,500,600,700,800,900".split(","),"normal"))},null,null,4,0,null,0,2,"call"]},
bhE:{"^":"c:36;",
$2:[function(a,b){a.gds().sHx(K.at(b,"none,overline,line-through,overline,underline".split(","),"none"))},null,null,4,0,null,0,2,"call"]},
bhF:{"^":"c:36;",
$2:[function(a,b){a.gds().sHw(K.ak(b,0))},null,null,4,0,null,0,2,"call"]},
bhG:{"^":"c:36;",
$2:[function(a,b){a.gds().saUW(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhI:{"^":"c:36;",
$2:[function(a,b){a.gds().saUV(K.at(b,["left","right","center"],"right"))},null,null,4,0,null,0,2,"call"]},
bhJ:{"^":"c:36;",
$2:[function(a,b){a.gds().sRq(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bhK:{"^":"c:36;",
$2:[function(a,b){J.Je(a.gds(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bhL:{"^":"c:36;",
$2:[function(a,b){a.gds().sUG(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bhM:{"^":"c:36;",
$2:[function(a,b){a.gds().sUH(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bhN:{"^":"c:36;",
$2:[function(a,b){a.gds().sUI(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
bhO:{"^":"c:36;",
$2:[function(a,b){a.gds().sa5x(K.ak(b,11))},null,null,4,0,null,0,2,"call"]},
bhP:{"^":"c:36;",
$2:[function(a,b){a.gds().saUL(K.at(b,["inside","center","outside"],"center"))},null,null,4,0,null,0,2,"call"]},
an2:{"^":"akF;L,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,E,v,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
sqP:function(a){var z=this.rx
if(z instanceof F.w)H.j(z,"$isw").cY(this.gdB())
this.axp(a)
if(a instanceof F.w)a.di(this.gdB())},
sa5w:function(a){var z=this.k4
if(z instanceof F.w)H.j(z,"$isw").cY(this.gdB())
this.axo(a)
if(a instanceof F.w)a.di(this.gdB())},
f6:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.L.a
if(z.R(0,a))z.h(0,a).jK(null)
this.axk(a,b,c,d)
return}if(!!J.n(a).$isb4){z=this.L.a
if(!z.R(0,a))z.l(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jK(b)
y.slb(c)
y.skR(d)}},
oI:[function(a){this.cZ()},"$1","gdB",2,0,2,11]},
Ej:{"^":"aGs;aK,ds:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,c_,bo,bS,c5,c7,bz,bZ,bT,c2,c8,c9,c3,bJ,ck,cC,cq,ca,cw,cr,cz,cA,cG,cl,ct,cu,ci,cb,cJ,cn,cB,cD,bN,cf,cm,cE,cH,co,cs,cK,cU,cI,cv,cL,cM,cR,cc,cN,cO,cp,cP,cS,cQ,E,v,L,T,W,Y,U,F,Z,S,at,ai,ab,ac,aa,ag,ao,a9,aA,aO,aR,ae,aB,aD,aF,ap,an,aM,aQ,aw,b1,b6,b9,bh,bc,ba,b2,b3,bq,b0,bj,aX,bG,by,bm,bi,bn,aY,bD,bv,bf,br,bO,bB,bs,bQ,bH,bV,bE,bP,bF,bt,bd,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdv:function(){return this.aK},
sf9:function(a,b){if(J.a(this.F,"none")&&!J.a(b,"none")){this.m6(this,b)
this.e9()}else this.m6(this,b)},
fz:[function(a,b){this.mv(this,b)
this.siq(!0)
if(b==null)this.w.is(J.d0(this.b),J.cU(this.b))},"$1","gf7",2,0,2,11],
rW:[function(a){this.w.is(J.d0(this.b),J.cU(this.b))},"$0","gmJ",0,0,0],
a7:[function(){this.siq(!1)
this.fH()
this.w.sHE(!0)
this.w.a7()
this.w.sqP(null)
this.w.sa5w(null)
this.w.sHE(!1)},"$0","gd9",0,0,0],
ia:[function(){this.siq(!1)
this.fH()},"$0","gkp",0,0,0],
fV:function(){this.Cg()
this.siq(!0)},
e9:function(){var z,y
this.zH()
this.soA(-1)
z=this.w
y=J.h(z)
y.sbx(z,J.o(y.gbx(z),1))},
x_:function(){this.w.is(J.d0(this.b),J.cU(this.b))},
$isbL:1,
$isbK:1},
aGs:{"^":"aM+mA;oA:x$?,uQ:y$?",$iscI:1},
bhQ:{"^":"c:48;",
$2:[function(a,b){a.gds().sqe(K.at(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bhR:{"^":"c:48;",
$2:[function(a,b){a.gds().sb2Y(K.at(b,["inside","outside","center"],"inside"))},null,null,4,0,null,0,2,"call"]},
bhT:{"^":"c:48;",
$2:[function(a,b){J.Jq(a.gds(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhU:{"^":"c:48;",
$2:[function(a,b){a.gds().sHQ(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhV:{"^":"c:48;",
$2:[function(a,b){a.gds().sa5w(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
bhW:{"^":"c:48;",
$2:[function(a,b){a.gds().saVS(K.ak(b,1))},null,null,4,0,null,0,2,"call"]},
bhX:{"^":"c:48;",
$2:[function(a,b){a.gds().sqP(R.cE(b,16777215))},null,null,4,0,null,0,2,"call"]},
bhY:{"^":"c:48;",
$2:[function(a,b){a.gds().sHL(K.ak(b,1))},null,null,4,0,null,0,2,"call"]},
bhZ:{"^":"c:48;",
$2:[function(a,b){a.gds().sRq(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bi_:{"^":"c:48;",
$2:[function(a,b){J.Je(a.gds(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bi0:{"^":"c:48;",
$2:[function(a,b){a.gds().sUG(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bi1:{"^":"c:48;",
$2:[function(a,b){a.gds().sUH(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bi3:{"^":"c:48;",
$2:[function(a,b){a.gds().sUI(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
bi4:{"^":"c:48;",
$2:[function(a,b){a.gds().sa5x(K.ak(b,11))},null,null,4,0,null,0,2,"call"]},
bi5:{"^":"c:48;",
$2:[function(a,b){a.gds().saVT(K.kJ(b,"","6%"))},null,null,4,0,null,0,2,"call"]},
bi6:{"^":"c:48;",
$2:[function(a,b){a.gds().saWl(K.ak(b,2))},null,null,4,0,null,0,2,"call"]},
bi7:{"^":"c:48;",
$2:[function(a,b){a.gds().saWm(K.kJ(b,"","4%"))},null,null,4,0,null,0,2,"call"]},
bi8:{"^":"c:48;",
$2:[function(a,b){a.gds().saNQ(K.aV(b,null))},null,null,4,0,null,0,2,"call"]},
an3:{"^":"akG;v,L,k2,k3,k4,r1,r2,rx,ry,x1,x2,y1,y2,K,E,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,c,d,e,f,r,x,y,z,Q,ch,a,b",
gk6:function(){return this.L},
sk6:function(a){var z=this.L
if(z!=null)z.cY(this.ga8P())
this.L=a
if(a!=null)a.di(this.ga8P())
this.b40(null)},
b40:[function(a){var z,y,x,w,v,u,t,s
z=this.L
if(z==null){z=new F.el(!1,H.d([],[F.aA]),0,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,-1,null,!1,null,!1,null,!1,0,null,null,null,null,null)
z.bl()
z.aS(!1,null)
z.ch=null
z.fO(F.hS(new F.du(0,255,0,1),0,0))
z.fO(F.hS(new F.du(0,0,0,1),0,50))}y=J.hP(z)
x=J.b7(y)
x.es(y,F.rP())
w=[]
if(J.y(x.gm(y),1))for(x=x.gbg(y);x.u();){v=x.gI()
u=J.h(v)
t=u.ghi(v)
s=H.dx(v.i("alpha"))
s.toString
w.push(new N.xi(t,s,J.M(u.gu3(v),100)))}else if(J.a(x.gm(y),1)){v=x.h(y,0)
x=J.h(v)
u=x.ghi(v)
t=H.dx(v.i("alpha"))
t.toString
w.push(new N.xi(u,t,0))
x=x.ghi(v)
t=H.dx(v.i("alpha"))
t.toString
w.push(new N.xi(x,t,1))}this.saaS(w)},"$1","ga8P",2,0,5,11],
eK:function(a,b){var z,y,x
if(typeof b==="number"&&Math.floor(b)===b){this.acu(a,b)
return}if(!!J.n(a).$isb4){z=this.v.a
if(!z.R(0,a))z.l(0,a,new E.bW(null,this.cy,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
x=F.cH(!1,null)
x.B("fillType",!0).a_("gradient")
x.B("gradient",!0).$2(b,!1)
x.B("gradientType",!0).a_("linear")
y.jx(x)}},
a7:[function(){var z=this.L
if(z!=null){z.cY(this.ga8P())
this.L=null}this.axq()},"$0","gd9",0,0,0],
aB8:function(){var z=$.$get$Df()
if(J.a(z.ry,0)){z.fO(F.hS(new F.du(0,255,0,1),1,0))
z.fO(F.hS(new F.du(255,255,0,1),1,50))
z.fO(F.hS(new F.du(255,0,0,1),1,100))}},
ah:{
an4:function(){var z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.an3(z,null,null,null,null,null,!0,0,"1%","5%",null,"inside","circular",0,0,new P.cl(""),null,50,50,-120,120,2,11,"4%","6%",90,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.cy=P.hK()
z.aAZ()
z.aB8()
return z}}},
El:{"^":"aGt;aK,ds:w@,a$,b$,c$,d$,e$,f$,r$,x$,y$,c_,bo,bS,c5,c7,bz,bZ,bT,c2,c8,c9,c3,bJ,ck,cC,cq,ca,cw,cr,cz,cA,cG,cl,ct,cu,ci,cb,cJ,cn,cB,cD,bN,cf,cm,cE,cH,co,cs,cK,cU,cI,cv,cL,cM,cR,cc,cN,cO,cp,cP,cS,cQ,E,v,L,T,W,Y,U,F,Z,S,at,ai,ab,ac,aa,ag,ao,a9,aA,aO,aR,ae,aB,aD,aF,ap,an,aM,aQ,aw,b1,b6,b9,bh,bc,ba,b2,b3,bq,b0,bj,aX,bG,by,bm,bi,bn,aY,bD,bv,bf,br,bO,bB,bs,bQ,bH,bV,bE,bP,bF,bt,bd,x1,x2,y1,y2,K,a,b,c,d,e,f,r,x,y,z,Q,ch,cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,rx,ry",
gdv:function(){return this.aK},
sf9:function(a,b){if(J.a(this.F,"none")&&!J.a(b,"none")){this.m6(this,b)
this.e9()}else this.m6(this,b)},
fz:[function(a,b){this.mv(this,b)
this.siq(!0)},"$1","gf7",2,0,2,11],
rW:[function(a){this.x_()},"$0","gmJ",0,0,0],
a7:[function(){this.siq(!1)
this.fH()
this.w.sHE(!0)
this.w.a7()
this.w.sk6(null)
this.w.sHE(!1)},"$0","gd9",0,0,0],
ia:[function(){this.siq(!1)
this.fH()},"$0","gkp",0,0,0],
fV:function(){this.Cg()
this.siq(!0)},
e9:function(){var z,y
this.zH()
this.soA(-1)
z=this.w
y=J.h(z)
y.sbx(z,J.o(y.gbx(z),1))},
x_:function(){if(this.a instanceof F.w)this.w.is(J.d0(this.b),J.cU(this.b))},
$isbL:1,
$isbK:1},
aGt:{"^":"aM+mA;oA:x$?,uQ:y$?",$iscI:1},
bhe:{"^":"c:74;",
$2:[function(a,b){a.gds().sqe(K.at(b,["circular","linear"],"circular"))},null,null,4,0,null,0,2,"call"]},
bhf:{"^":"c:74;",
$2:[function(a,b){J.Jq(a.gds(),K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhg:{"^":"c:74;",
$2:[function(a,b){a.gds().sHQ(K.aV(b,0))},null,null,4,0,null,0,2,"call"]},
bhh:{"^":"c:74;",
$2:[function(a,b){a.gds().sb0L(K.kJ(b,"","1%"))},null,null,4,0,null,0,2,"call"]},
bhi:{"^":"c:74;",
$2:[function(a,b){a.gds().sb0K(K.kJ(b,"","5%"))},null,null,4,0,null,0,2,"call"]},
bhj:{"^":"c:74;",
$2:[function(a,b){a.gds().sjk(K.at(b,["inside","outside","cross"],"inside"))},null,null,4,0,null,0,2,"call"]},
bhk:{"^":"c:74;",
$2:[function(a,b){var z=a.gds()
z.sk6(b!=null?F.pS(b):$.$get$Df())},null,null,4,0,null,0,2,"call"]},
bhm:{"^":"c:74;",
$2:[function(a,b){a.gds().sRq(K.aV(b,-120))},null,null,4,0,null,0,2,"call"]},
bhn:{"^":"c:74;",
$2:[function(a,b){J.Je(a.gds(),K.aV(b,120))},null,null,4,0,null,0,2,"call"]},
bho:{"^":"c:74;",
$2:[function(a,b){a.gds().sUG(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bhp:{"^":"c:74;",
$2:[function(a,b){a.gds().sUH(K.aV(b,50))},null,null,4,0,null,0,2,"call"]},
bhq:{"^":"c:74;",
$2:[function(a,b){a.gds().sUI(K.aV(b,90))},null,null,4,0,null,0,2,"call"]},
yy:{"^":"t;a9S:a@,iJ:b*,ji:c*"},
ajV:{"^":"ly;cx,cy,db,dx,dy,fr,fx,fy,go,id,k1,k2,k3,k4,r1,r2,c,d,e,f,r,x,y,z,Q,ch,a,b",
gqB:function(){return this.r1},
sqB:function(a){if(!J.a(this.r1,a)){this.r1=a
this.cZ()}},
gd0:function(){return this.r2},
sd0:function(a){this.b1w(a)},
gk7:function(){return this.go},
iS:function(a,b){var z,y,x,w
this.FE(a,b)
if(this.id!=null){this.k1.setAttribute("x","0")
this.k1.setAttribute("y","0")
this.k1.setAttribute("width","0")
this.k1.setAttribute("height","0")
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}if(this.cx&&this.db!==0){if(this.id==null){z=P.hK()
this.id=z
this.go.appendChild(z)
z=document
this.k1=z.createElementNS("http://www.w3.org/2000/svg","rect")
z=document
this.k2=z.createElementNS("http://www.w3.org/2000/svg","path")
z=document
this.k3=z.createElementNS("http://www.w3.org/2000/svg","path")
this.id.appendChild(this.k1)
this.id.appendChild(this.k2)
this.id.appendChild(this.k3)}z=this.id.style
y=H.b(a)+"px"
z.width=y
z=this.id.style
y=H.b(b)+"px"
z.height=y
this.f6(this.k1,0,0,"none")
this.eK(this.k1,this.r2.ck)
z=this.k2
y=this.r2
this.f6(z,y.c9,J.aL(y.c3),this.r2.bJ)
y=this.k3
z=this.r2
this.f6(y,z.c9,J.aL(z.c3),this.r2.bJ)
z=this.db
if(z===2){z=J.y(this.r1.b,0)
y=J.n(a)
x=this.k1
if(z){x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a0(this.cy.b))
z=this.k1
z.toString
z.setAttribute("width",y.aN(a))
y=this.k1
y.toString
y.setAttribute("height",J.a0(this.r1.b))}else{x.setAttribute("x","0")
z=this.k1
z.toString
z.setAttribute("y",J.a0(J.k(this.cy.b,this.r1.b)))
z=this.k1
z.toString
z.setAttribute("width",y.aN(a))
y=this.k1
y.toString
z=this.r1.b
if(typeof z!=="number")return H.l(z)
y.setAttribute("height",C.b.aN(0-z))}z=this.k2
z.toString
z.setAttribute("d","M 0,"+H.b(this.cy.b)+" L "+H.b(a)+","+H.b(this.cy.b))
z=this.k3
z.toString
z.setAttribute("d","M 0,"+H.b(J.k(this.cy.b,this.r1.b))+" L "+H.b(a)+","+H.b(J.k(this.cy.b,this.r1.b)))}else if(z===1){z=J.y(this.r1.a,0)
y=J.n(b)
x=this.k1
w=this.cy
if(z){x.toString
x.setAttribute("x",J.a0(w.a))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
z.setAttribute("width",J.a0(this.r1.a))
z=this.k1
z.toString
z.setAttribute("height",y.aN(b))}else{x.toString
x.setAttribute("x",J.a0(J.k(w.a,this.r1.a)))
this.k1.setAttribute("y","0")
z=this.k1
z.toString
x=this.r1.a
if(typeof x!=="number")return H.l(x)
z.setAttribute("width",C.b.aN(0-x))
x=this.k1
x.toString
x.setAttribute("height",y.aN(b))}z=this.k2
z.toString
z.setAttribute("d","M "+H.b(this.cy.a)+",0 L "+H.b(this.cy.a)+","+H.b(b))
z=this.k3
z.toString
z.setAttribute("d","M "+H.b(J.k(this.cy.a,this.r1.a))+",0 L "+H.b(J.k(this.cy.a,this.r1.a))+","+H.b(b))}else if(z===3){z=J.y(this.r1.a,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("x",J.a0(x.a))
z=this.k1
z.toString
z.setAttribute("width",J.a0(this.r1.a))}else{y.toString
y.setAttribute("x",J.a0(J.k(x.a,this.r1.a)))
z=this.k1
z.toString
y=this.r1.a
if(typeof y!=="number")return H.l(y)
z.setAttribute("width",C.b.aN(0-y))}z=J.y(this.r1.b,0)
y=this.k1
x=this.cy
if(z){y.toString
y.setAttribute("y",J.a0(x.b))
z=this.k1
z.toString
z.setAttribute("height",J.a0(this.r1.b))}else{y.toString
y.setAttribute("y",J.a0(J.k(x.b,this.r1.b)))
z=this.k1
z.toString
y=this.r1.b
if(typeof y!=="number")return H.l(y)
z.setAttribute("height",C.b.aN(0-y))}z=this.k1
y=this.r2
this.f6(z,y.c9,J.aL(y.c3),this.r2.bJ)
this.k2.setAttribute("d","M 0,0")
this.k3.setAttribute("d","M 0,0")}}},
b1w:function(a){var z
this.a7W()
this.a7X()
if(this.r2!=null){for(z=this.fx;z.length>0;)z.pop().J(0)
this.r2.pc(0,"CartesianChartZoomerReset",this.gakX())}this.r2=a
if(a!=null){z=J.ck(a.cx)
z=H.d(new W.A(0,z.a,z.b,W.z(this.gaLW()),z.c),[H.r(z,0)])
z.t()
this.fx.push(z)
this.r2.no(0,"CartesianChartZoomerReset",this.gakX())}this.dx=null
this.dy=null},
LC:function(a){var z,y,x,w,v
z=this.Jd(a)
for(y=z.length,x=0;w=z.length,x<w;w===y||(0,H.L)(z),++x){v=J.n(z[x])
if(!(!!v.$isre||!!v.$isi0||!!v.$isiV))return!1}return!0},
atv:function(a){var z=J.n(a)
if(!!z.$isiV)return J.av(a.db)?null:a.db
else if(!!z.$isrg)return a.db
return 0/0},
Y6:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isiV){if(b==null)y=null
else{y=J.aN(b)
x=!a.ag
w=new P.ag(y,x)
w.eF(y,x)
y=w}z.siJ(a,y)}else if(!!z.$isi0)z.siJ(a,b)
else if(!!z.$isre)z.siJ(a,b)},
avf:function(a,b){return this.Y6(a,b,!1)},
att:function(a){var z=J.n(a)
if(!!z.$isiV)return J.av(a.cy)?null:a.cy
else if(!!z.$isrg)return a.cy
return 0/0},
Y5:function(a,b,c){var z,y,x,w
z=J.n(a)
if(!!z.$isiV){if(b==null)y=null
else{y=J.aN(b)
x=!a.ag
w=new P.ag(y,x)
w.eF(y,x)
y=w}z.sji(a,y)}else if(!!z.$isi0)z.sji(a,b)
else if(!!z.$isre)z.sji(a,b)},
avd:function(a,b){return this.Y5(a,b,!1)},
a9N:function(a,b,c){var z,y,x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
z=a===2
if(z){y=this.dy
if(y==null){y=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[N.e7,L.yy])),[N.e7,L.yy])
this.dy=y
x=y
w=!0}else{x=y
w=!1}}else{y=this.dx
if(y==null){y=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[N.e7,L.yy])),[N.e7,L.yy])
this.dx=y
x=y
w=!0}else{x=y
w=!1}}if(w){v=this.Jd(z)
for(y=v.length,u=0;u<v.length;v.length===y||(0,H.L)(v),++u){t=v[u]
s=x.a
if(!s.R(0,t)){r=J.n(t)
r=!!r.$isre||!!r.$isi0||!!r.$isiV}else r=!1
if(r)s.l(0,t,new L.yy(!1,this.atv(t),this.att(t)))}}y=this.cy
if(z){y=y.b
q=P.aB(y,J.k(y,b))
y=this.cy.b
p=P.ax(y,J.k(y,b))
o="v"
n=null
m=null}else{y=y.a
n=P.aB(y,J.k(y,b))
y=this.cy.a
m=P.ax(y,J.k(y,b))
o="h"
q=null
p=null}l=[]
k=N.jJ(this.r2.a9,!1)
y=k.length
s=o==="v"
h=null
g=null
u=0
while(!0){if(!(u<k.length)){j=null
i=null
break}c$0:{f=k[u]
if(!(f instanceof N.jY))break c$0
if(f.go!==!0||f.fy!==!0){g=f
break c$0}h=s?f.ao:f.ag
r=J.n(h)
if(!(!!r.$isre||!!r.$isi0||!!r.$isiV)){g=f
break c$0}if(J.au(C.a.cT(l,h),0)){g=f
break c$0}l.push(h)
y=f.cy
if(z){e=Q.b9(y,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.al(f.gd0()),e).b)
if(typeof q!=="number")return q.A()
y=H.d(new P.F(0,q-y),[null])
y=f.fr.pH([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(1>=y.length)return H.e(y,1)
j=y[1]
e=Q.b9(f.cy,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.al(f.gd0()),e).b)
if(typeof p!=="number")return p.A()
y=H.d(new P.F(0,p-y),[null])
y=f.fr.pH([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(1>=y.length)return H.e(y,1)
i=y[1]}else{e=Q.b9(y,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.al(f.gd0()),e).a)
if(typeof m!=="number")return m.A()
y=H.d(new P.F(m-y,0),[null])
y=f.fr.pH([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(0>=y.length)return H.e(y,0)
j=y[0]
e=Q.b9(f.cy,H.d(new P.F(0,0),[null]))
y=J.aL(Q.aK(J.al(f.gd0()),e).a)
if(typeof n!=="number")return n.A()
y=H.d(new P.F(n-y,0),[null])
y=f.fr.pH([J.o(y.a,C.b.G(f.cy.offsetLeft)),J.o(y.b,C.b.G(f.cy.offsetTop))])
if(0>=y.length)return H.e(y,0)
i=y[0]}if(J.S(i,j)){d=i
i=j
j=d}this.avf(h,j)
this.avd(h,i)
this.fr=!0
break}k.length===y||(0,H.L)(k);++u}if(!this.fr)return
x.a.h(0,h).sa9S(!0)
if(h!=null&&!c){y=this.r2
if(z){y.c2=j
y.c8=i
y.as1()}else{y.bz=j
y.bZ=i
y.ari()}}},
asB:function(a,b){return this.a9N(a,b,!1)},
apI:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dx
if(z==null)return
y=this.Jd(!1)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.L)(y),++u){t=y[u]
if(w.R(0,t)){this.Y6(t,J.SU(w.h(0,t)),!0)
this.Y5(t,J.ST(w.h(0,t)),!0)
if(w.h(0,t).ga9S())v=t}}this.dx=null
this.fr=this.dy!=null
x=this.r2
if(x!=null&&v!=null&&!a){x.bz=0/0
x.bZ=0/0
x.ari()}},
a7W:function(){return this.apI(!1)},
apM:function(a){var z,y,x,w,v,u,t
if(!this.fr)return
z=this.dy
if(z==null)return
y=this.Jd(!0)
for(x=y.length,w=z.a,v=null,u=0;u<y.length;y.length===x||(0,H.L)(y),++u){t=y[u]
if(w.R(0,t)){this.Y6(t,J.SU(w.h(0,t)),!0)
this.Y5(t,J.ST(w.h(0,t)),!0)
if(w.h(0,t).ga9S())v=t}}this.dy=null
this.fr=this.dx!=null||!1
x=this.r2
if(x!=null&&v!=null&&!a){x.c2=0/0
x.c8=0/0
x.as1()}},
a7X:function(){return this.apM(!1)},
asC:function(a,b,c){var z,y,x,w,v,u,t,s,r
z=J.E(a)
if(z.gkf(a)||J.av(b)){if(this.fr)if(c)this.apM(!0)
else this.apI(!0)
return}if(!this.LC(c))return
y=this.Jd(c)
$loop$0:x=0<y.length?y[0]:null
if(x==null)return
w=this.atO(x)
if(w==null)return
v=J.n(b)
if(c){u=J.k(w.GS(["0",z.aN(a)]).b,this.aaQ(w))
t=J.k(w.GS(["0",v.aN(b)]).b,this.aaQ(w))
this.cy=H.d(new P.F(50,u),[null])
this.a9N(2,J.o(t,u),!0)}else{s=J.k(w.GS([z.aN(a),"0"]).a,this.aaP(w))
r=J.k(w.GS([v.aN(b),"0"]).a,this.aaP(w))
this.cy=H.d(new P.F(s,50),[null])
this.a9N(1,J.o(r,s),!0)}},
Jd:function(a){var z,y,x,w,v,u,t
z=[]
y=N.jJ(this.r2.a9,!1)
for(x=y.length,w=null,v=0;v<y.length;y.length===x||(0,H.L)(y),++v){u=y[v]
if(!(u instanceof N.jY))continue
if(a){t=u.ao
if(t!=null&&J.S(C.a.cT(z,t),0))z.push(u.ao)}else{t=u.ag
if(t!=null&&J.S(C.a.cT(z,t),0))z.push(u.ag)}w=u}return z},
atO:function(a){var z,y,x,w,v
z=N.jJ(this.r2.a9,!1)
for(y=z.length,x=null,w=0;w<z.length;z.length===y||(0,H.L)(z),++w){v=z[w]
if(!(v instanceof N.jY))continue
if(J.a(v.ao,a)||J.a(v.ag,a))return v
x=v}return},
aaP:function(a){var z=Q.b9(a.cy,H.d(new P.F(0,0),[null]))
return J.aL(Q.aK(J.al(a.gd0()),z).a)},
aaQ:function(a){var z=Q.b9(a.cy,H.d(new P.F(0,0),[null]))
return J.aL(Q.aK(J.al(a.gd0()),z).b)},
f6:function(a,b,c,d){var z,y
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.R(0,a))z.h(0,a).jK(null)
R.p2(a,b,c,d)
return}if(!!J.n(a).$isb4){z=this.k4.a
if(!z.R(0,a))z.l(0,a,new E.bW(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
y=z.h(0,a)
y.jK(b)
y.slb(c)
y.skR(d)}},
eK:function(a,b){var z
if(typeof b==="number"&&Math.floor(b)===b){z=this.k4.a
if(z.R(0,a))z.h(0,a).jx(null)
R.tN(a,b)
return}if(!!J.n(a).$isb4){z=this.k4.a
if(!z.R(0,a))z.l(0,a,new E.bW(null,this.id,a,null,null,null,null,1,"",null,null,"",null,null))
z.h(0,a).jx(b)}},
b9U:[function(a){var z,y
z=this.r2
if(!z.c5&&!z.bT)return
z.cx.appendChild(this.go)
z=this.r2
this.is(z.Q,z.ch)
this.cy=Q.aK(this.go,J.cx(a))
this.cx=!0
z=this.fy
y=H.d(new W.ay(document,"mousemove",!1),[H.r(C.C,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gau6()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.ay(document,"mouseup",!1),[H.r(C.D,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gau7()),y.c),[H.r(y,0)])
y.t()
z.push(y)
y=H.d(new W.ay(document,"keydown",!1),[H.r(C.a2,0)])
y=H.d(new W.A(0,y.a,y.b,W.z(this.gAQ()),y.c),[H.r(y,0)])
y.t()
z.push(y)
this.db=0
this.sqB(null)},"$1","gaLW",2,0,4,4],
b6p:[function(a){var z,y
z=Q.aK(this.go,J.cx(a))
if(this.db===0)if(this.r2.c7){if(!(this.LC(!0)&&this.LC(!1))){this.GI()
return}if(J.au(J.b8(J.o(z.a,this.cy.a)),2)&&J.au(J.b8(J.o(z.b,this.cy.b)),2))this.db=3
else return}else{if(J.y(J.b8(J.o(z.b,this.cy.b)),J.b8(J.o(z.a,this.cy.a)))){if(this.LC(!0))this.db=2
else{this.GI()
return}y=2}else{if(this.LC(!1))this.db=1
else{this.GI()
return}y=1}if(y===1)if(!this.r2.c5){this.GI()
return}if(y===2)if(!this.r2.bT){this.GI()
return}}y=this.r2
if(P.bd(0,0,y.Q,y.ch,null).nR(0,z)){y=this.db
if(y===2)this.sqB(H.d(new P.F(0,J.o(z.b,this.cy.b)),[null]))
else if(y===1)this.sqB(H.d(new P.F(J.o(z.a,this.cy.a),0),[null]))
else if(y===3)this.sqB(H.d(new P.F(J.o(z.a,this.cy.a),J.o(z.b,this.cy.b)),[null]))
else this.sqB(null)}},"$1","gau6",2,0,4,4],
b6q:[function(a){var z,y
for(z=this.fy;z.length>0;)z.pop().J(0)
J.X(this.go)
this.cx=!1
this.cZ()
z=this.r1
if(z!=null){y=this.db
if(y===2||y===3)this.asB(2,z.b)
z=this.db
if(z===1||z===3)this.asB(1,this.r1.a)}else{this.a7W()
F.a7(new L.ajX(this))}},"$1","gau7",2,0,4,4],
a40:[function(a){if(Q.cN(a)===27)this.GI()},"$1","gAQ",2,0,6,4],
GI:function(){for(var z=this.fy;z.length>0;)z.pop().J(0)
J.X(this.go)
this.cx=!1
this.cZ()},
bck:[function(a){this.a7W()
F.a7(new L.ajY(this))},"$1","gakX",2,0,7,4],
aAV:function(){var z=document
z=z.createElement("div")
this.go=z
z=J.x(z)
z.n(0,"dgDisableMouse")
z.n(0,"chart-zoomer-layer")},
ah:{
ajW:function(){var z=H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.t,E.bW])),[P.t,E.bW])
z=new L.ajV(!1,null,0,null,null,!1,[],[],null,null,null,null,null,z,null,null,!1,!1,null,!0,!1,null,0,0,0,0,null,H.d(new K.a4(H.d(new H.W(0,null,null,null,null,null,0),[P.u,[P.B,P.aF]])),[P.u,[P.B,P.aF]]))
z.a=z
z.aAV()
return z}}},
ajX:{"^":"c:3;a",
$0:[function(){this.a.a7X()},null,null,0,0,null,"call"]},
ajY:{"^":"c:3;a",
$0:[function(){this.a.a7X()},null,null,0,0,null,"call"]}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[{func:1,v:true},{func:1,ret:P.ba,args:[F.w,P.u,P.ba]},{func:1,v:true,args:[[P.a_,P.u]]},{func:1,ret:Q.bL},{func:1,v:true,args:[W.cz]},{func:1,v:true,args:[P.t]},{func:1,v:true,args:[W.hj]},{func:1,v:true,args:[E.ci]},{func:1,ret:P.u,args:[N.l3]}]
init.types.push.apply(init.types,deferredTypes)
$.Rn=!1;(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["Zz","$get$Zz",function(){return P.m(["scaleType",new L.bhr(),"offsetLeft",new L.bhs(),"offsetRight",new L.bht(),"minimum",new L.bhu(),"maximum",new L.bhv(),"formatString",new L.bhx(),"showMinMaxOnly",new L.bhy(),"percentTextSize",new L.bhz(),"labelsColor",new L.bhA(),"labelsFontFamily",new L.bhB(),"labelsFontStyle",new L.bhC(),"labelsFontWeight",new L.bhD(),"labelsTextDecoration",new L.bhE(),"labelsLetterSpacing",new L.bhF(),"labelsRotation",new L.bhG(),"labelsAlign",new L.bhI(),"angleFrom",new L.bhJ(),"angleTo",new L.bhK(),"percentOriginX",new L.bhL(),"percentOriginY",new L.bhM(),"percentRadius",new L.bhN(),"majorTicksCount",new L.bhO(),"justify",new L.bhP()])},$,"ZA","$get$ZA",function(){var z=P.a1()
z.q(0,E.eO())
z.q(0,$.$get$Zz())
return z},$,"ZB","$get$ZB",function(){return P.m(["scaleType",new L.bhQ(),"ticksPlacement",new L.bhR(),"offsetLeft",new L.bhT(),"offsetRight",new L.bhU(),"majorTickStroke",new L.bhV(),"majorTickStrokeWidth",new L.bhW(),"minorTickStroke",new L.bhX(),"minorTickStrokeWidth",new L.bhY(),"angleFrom",new L.bhZ(),"angleTo",new L.bi_(),"percentOriginX",new L.bi0(),"percentOriginY",new L.bi1(),"percentRadius",new L.bi3(),"majorTicksCount",new L.bi4(),"majorTicksPercentLength",new L.bi5(),"minorTicksCount",new L.bi6(),"minorTicksPercentLength",new L.bi7(),"cutOffAngle",new L.bi8()])},$,"ZC","$get$ZC",function(){var z=P.a1()
z.q(0,E.eO())
z.q(0,$.$get$ZB())
return z},$,"ZD","$get$ZD",function(){return P.m(["scaleType",new L.bhe(),"offsetLeft",new L.bhf(),"offsetRight",new L.bhg(),"percentStartThickness",new L.bhh(),"percentEndThickness",new L.bhi(),"placement",new L.bhj(),"gradient",new L.bhk(),"angleFrom",new L.bhm(),"angleTo",new L.bhn(),"percentOriginX",new L.bho(),"percentOriginY",new L.bhp(),"percentRadius",new L.bhq()])},$,"ZE","$get$ZE",function(){var z=P.a1()
z.q(0,E.eO())
z.q(0,$.$get$ZD())
return z},$])}
$dart_deferred_initializers$["kB2SvtDdodaFCaVDTbEbFmLPLqE="]=$dart_deferred_initializers$.current

//# sourceMappingURL=main.dart.js_1.part.js.map
