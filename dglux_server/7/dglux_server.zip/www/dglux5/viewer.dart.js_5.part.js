self.$dart_deferred_initializers$=self.$dart_deferred_initializers$||Object.create(null)
$dart_deferred_initializers$.current=function($globals$,$){var A=$globals$.A
var B=$globals$.B
var C=$globals$.C
var D=$globals$.D
var E=$globals$.E
var F=$globals$.F
var G=$globals$.G
var H=$globals$.H
var J=$globals$.J
var K=$globals$.K
var L=$globals$.L
var M=$globals$.M
var N=$globals$.N
var O=$globals$.O
var P=$globals$.P
var Q=$globals$.Q
var R=$globals$.R
var S=$globals$.S
var T=$globals$.T
var U=$globals$.U
var V=$globals$.V
var W=$globals$.W
var X=$globals$.X
var Y=$globals$.Y
var Z=$globals$.Z
var init=$globals$.init
var setupProgram=$globals$.setupProgram
var I=$globals$.I
var dart=[["","",,K,{"^":"",
C0:function(a,b,c,d,e,f){var z,y,x,w,v,u,t,s,r
z=K.C(a,null)
if(z==null)return c
if(!K.Ch(z)){y=J.m(z)
y=y.j(z,1/0)||y.j(z,-1/0)}else y=!0
if(y){if(d)return J.V(z)
return c}y=J.au(e)
x=J.oL(y.aH(e,z),b)
w=C.d.dm(x,".")
if(w>=0){v=C.d.ne(x,$.$get$a1j(),w)
if(v>0)x=C.d.bt(x,0,v)
else{u=C.d.ne(x,$.$get$a1k(),w)
if(u>0){x=C.d.bt(x,0,u)
t=y.aH(e,z)
s=u-w
H.a0(10)
H.a0(s)
r=Math.pow(10,s)
x=C.d.bt(J.oL(J.E(J.bf(J.w(t,r)),r),20),0,x.length)}}if(typeof b!=="number")return H.j(b)
if(x.length-w>b)x=J.oL(y.aH(e,z),b)}w=C.d.dm(x,".")
if(f&&w>0){while(!0){if(!(C.d.h4(x,"0")&&!C.d.h4(x,".")))break
x=C.d.bt(x,0,x.length-1)}if(C.d.h4(x,"."))x=C.d.bt(x,0,x.length-1)}return x}}]]
setupProgram(dart,init.types.length)
var deferredTypes=[]
init.types.push.apply(init.types,deferredTypes);(function(a){for(var z=0;z<a.length;){var y=a[z++]
var x=a[z++]
var w=a[z++]
var v=a[z++]
I.$lazy(y,x,w,null,v)}})(["a1j","$get$a1j",function(){return P.cr("0{5,}",!0,!1)},$,"a1k","$get$a1k",function(){return P.cr("9{5,}",!0,!1)},$])}
$dart_deferred_initializers$["KCsQ2rQZXQHUcSCAF7uEkzh0UMA="]=$dart_deferred_initializers$.current

//# sourceMappingURL=viewer.dart.js_12.part.js.map
